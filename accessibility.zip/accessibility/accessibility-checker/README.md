# Accessibility Checker

This is a project for Accessibility Checker plugin.