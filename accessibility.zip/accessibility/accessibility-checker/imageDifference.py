# USAGE

# python image_diff.py --first original_01.png --second modified_01.png

#Author: Manoj

# import the necessary packages
import base64
import io

import numpy as np
from PIL import Image
from skimage.metrics import structural_similarity
import argparse
import cv2

# construct the argument parse and parse the arguments
ap = argparse.ArgumentParser()
ap.add_argument("-f", "--first", required=True,
        help="first input image")
ap.add_argument("-s", "--second", required=True,
        help="second")

args = vars(ap.parse_args())
try:
    imgdata1 = base64.b64decode(args["first"])
    imgdata2 = base64.b64decode(args["second"])


    # load the two input images
    imageA = Image.open(io.BytesIO(imgdata1))
    imageB = Image.open(io.BytesIO(imgdata2))

    # convert the images to grayscale
    grayA = cv2.cvtColor(np.array(imageA), cv2.COLOR_BGR2GRAY)
    grayB = cv2.cvtColor(np.array(imageB), cv2.COLOR_BGR2GRAY)

    (H, W) = grayA.shape
    # to resize and set the new width and height
    grayB = cv2.resize(grayB, (W, H))

    width = 357
    height =230

    # compute the Structural Similarity Index (SSIM) between the two
    # images, ensuring that the difference image is returned
    (score, diff) = structural_similarity(grayA, grayB, full=True)
    diff = (diff * 255).astype("uint8")
    print(score)
    
except Exception as e:
    print(0)