package com.cognizant.accessibilityvalidationbot.process.factory;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.Platform;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.Proxy.ProxyType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;

import com.cognizant.accessibilityvalidationbot.process.utils.Browser;

import io.github.bonigarcia.wdm.WebDriverManager;

/**
 * Factory class for creating the {@link WebDriver} object as required
 * 
 * @author Cognizant
 */
public class WebDriverFactory {

	private WebDriverFactory() {
		// To prevent external instantiation of this class
	}
	
	/**
	 * Proxy Host
	 */
	private static String proxyHost;
	
	/**
	 * Proxy Host
	 */
	private static String proxyPort;
	
	/**
	 * whther proxy is required
	 */
	private static boolean proxyRequired;

	/**
	 * Function to return the appropriate {@link WebDriver} object based on the
	 * parameters passed
	 * 
	 * @param browser The {@link Browser} to be used for the test execution
	 * @return The corresponding {@link WebDriver} object
	 */

	public static WebDriver getWebDriver(Browser browser, String deviceName) {
		WebDriver driver = null;
		try {
			switch (browser) {
			case CHROME:
				// Takes the system proxy settings automatically

				WebDriverManager.chromedriver().setup();
				ChromeOptions options = new ChromeOptions();
				options.setPageLoadStrategy(PageLoadStrategy.NONE);
				options.addArguments("--start-maximized");
				options.addArguments("--start-fullscreen");
				options.addArguments("--disable-notifications");
				driver = new ChromeDriverEx(options);
				//driver = new ChromeDriver();
				break;

			case CHROME_HEADLESS:
				WebDriverManager.chromedriver().setup();
				ChromeOptions chromeOptions = new ChromeOptions();
				chromeOptions.addArguments("--start-maximized");
				chromeOptions.addArguments("--start-fullscreen");
				chromeOptions.addArguments("--disable-notifications");
				chromeOptions.addArguments("--no-sandbox");
				chromeOptions.addArguments("--disable-dev-shm-usage");
				chromeOptions.addArguments("--headless");
				chromeOptions.addArguments("window-size=1920,1440");
				driver = new ChromeDriver(chromeOptions);
				break;

			case FIREFOX:

				WebDriverManager.firefoxdriver().setup();
				driver = new FirefoxDriver();
				break;

			case INTERNET_EXPLORER:

				WebDriverManager.iedriver().setup();
				driver = new InternetExplorerDriver();
				break;

			case EDGE:
				WebDriverManager.edgedriver().setup();
				driver = new EdgeDriver();
				break;

			case SAFARI:
				// Takes the system proxy settings automatically

				driver = new SafariDriver();
				break;

			case MOBILE:
				Map<String,String> mobileEmulator = new HashMap<String,String>();
				mobileEmulator.put("deviceName", deviceName);
				
				WebDriverManager.chromedriver().setup();
				ChromeOptions chromeOption = new ChromeOptions();
				chromeOption.setPageLoadStrategy(PageLoadStrategy.NONE);
				chromeOption.setExperimentalOption("mobileEmulation", mobileEmulator);
				driver = new ChromeDriverEx(chromeOption);
				break;
				
			default:
				throw new Exception("Unhandled browser!");
			}
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}

		return driver;
	}

	/**
	 * get proxy applied desierd capabilities
	 * @return
	 */
	private static DesiredCapabilities getProxyCapabilities() {
		String proxyUrl = proxyHost + ":" + proxyPort;

		Proxy proxy = new Proxy();
		proxy.setProxyType(ProxyType.MANUAL);
		proxy.setHttpProxy(proxyUrl);
		proxy.setFtpProxy(proxyUrl);
		proxy.setSslProxy(proxyUrl);

		DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
		desiredCapabilities.setCapability(CapabilityType.PROXY, proxy);

		return desiredCapabilities;
	}

	/**
	 * Function to return the {@link RemoteWebDriver} object based on the parameters
	 * passed
	 * 
	 * @param browser        The {@link Browser} to be used for the test execution
	 * @param browserVersion The browser version to be used for the test execution
	 * @param platform       The {@link Platform} to be used for the test execution
	 * @param remoteUrl      The URL of the remote machine to be used for the test
	 *                       execution
	 * @return The corresponding {@link RemoteWebDriver} object
	 */
	public static WebDriver getRemoteWebDriver(Browser browser, String browserVersion, Platform platform,
			String remoteUrl) {


		DesiredCapabilities desiredCapabilities = null;
		if (proxyRequired) {
			desiredCapabilities = getProxyCapabilities();
		} else {
			desiredCapabilities = new DesiredCapabilities();
		}

		desiredCapabilities.setBrowserName(browser.getValue());

		if (browserVersion != null) {
			desiredCapabilities.setVersion(browserVersion);
		}
		if (platform != null) {
			desiredCapabilities.setPlatform(platform);
		}

		desiredCapabilities.setJavascriptEnabled(true); // Pre-requisite for
														// remote execution

		URL url = getUrl(remoteUrl);

		return new RemoteWebDriver(url, desiredCapabilities);
	}

	/**
	 * fetch URL
	 * @param remoteUrl
	 * @return
	 */
	private static URL getUrl(String remoteUrl) {
		URL url = null;
		try {
			url = new URL(remoteUrl);
		} catch (MalformedURLException e) {
			e.printStackTrace();

		}
		return url;
	}

	/**
	 * Function to return the {@link RemoteWebDriver} object based on the parameters
	 * passed
	 * 
	 * @param browser   The {@link Browser} to be used for the test execution
	 * @param remoteUrl The URL of the remote machine to be used for the test
	 *                  execution
	 * @return The corresponding {@link RemoteWebDriver} object
	 */
	public static WebDriver getRemoteWebDriver(Browser browser, String remoteUrl) {
		return getRemoteWebDriver(browser, null, null, remoteUrl);
	}

}