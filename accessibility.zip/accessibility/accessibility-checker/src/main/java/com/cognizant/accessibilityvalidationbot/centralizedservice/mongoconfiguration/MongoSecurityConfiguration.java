package com.cognizant.accessibilityvalidationbot.centralizedservice.mongoconfiguration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.config.AbstractMongoClientConfiguration;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoClientDbFactory;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;


@Configuration
@EnableMongoRepositories(basePackages = 
									    {
										  "com.cognizant.accessibilityvalidationbot.*"
										})
public class MongoSecurityConfiguration extends AbstractMongoClientConfiguration{

	/** The mongo connection uri. */
	@Value("${spring.data.mongodb.uri}")
	private String mongoConnectionUri;
	
	/** The host. */
	@Value("${spring.data.mongodb.host}")
	private String  host;

	/** The port. */
	@Value("${spring.data.mongodb.port}")
	private String port;
	
	/** The database. */
	@Value("${spring.data.mongodb.database}")
	private String database;
	
	/** The username. */
	@Value("${spring.data.mongodb.username}")
	private String username;
	
	/** The password. */
	@Value("${spring.data.mongodb.password}")
	private String password;
	
	/* (non-Javadoc)
	 * @see org.springframework.data.mongodb.config.AbstractMongoConfiguration#getDatabaseName()
	 */
	@Override
	protected String getDatabaseName() {
		return this.database;
	}

	@SuppressWarnings("deprecation")
	@Bean
    public SimpleMongoClientDbFactory mongoDbFactory() {
        return new SimpleMongoClientDbFactory(mongoConnectionUri);
    }

	@Bean
	public MongoTemplate mongoTemplate() {
		MongoTemplate mongoTemplate = new MongoTemplate(mongoDbFactory());

		return mongoTemplate;

    }
}
