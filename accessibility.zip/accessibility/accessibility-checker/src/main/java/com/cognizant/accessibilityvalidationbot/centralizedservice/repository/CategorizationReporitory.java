package com.cognizant.accessibilityvalidationbot.centralizedservice.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.accessibilityvalidationbot.centralizedservice.model.CategorizationVO;

/**
 * Repository for Categorization collection
 * @author 578086
 *
 */
@Transactional
public interface CategorizationReporitory extends MongoRepository<CategorizationVO,String>{

	CategorizationVO findByRunIdentifier(String runIdentifier);
	
}
