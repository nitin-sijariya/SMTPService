package com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.model.DomainSpecificRuleBook;

/**
 * Mongo repository for domain specific rule book
 * @author 578086
 *
 */

@Transactional
public interface DomainSpecificRuleBookRepository extends MongoRepository<DomainSpecificRuleBook,String>{

	public DomainSpecificRuleBook findByPageURL(String pageURL);
	
}
