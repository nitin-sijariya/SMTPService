package com.cognizant.accessibilityvalidationbot.centralizedservice.configuration;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.Utils.Util;

@Component
public class RestFilter implements Filter{

	/** The Allowed Headers List. */
	@Value("${ui.origin.allow.headers.aslist}")
	private String allowedHeadersList;
	
	/** The allowed methods list. */
	@Value("${ui.origin.allow.methods.aslist}")
	private String allowedMethodsList;
	
	/** The allowed origins. */
	@Value("${ui.origin.uri.aslist}")
	private String allowedOrigins;

	/** The max age. */
	@Value("${ui.origin.control.maxage}")
	private String maxAge;
	
	/** The host Name. */
	@Value("${app.screenshot.url}")
	private String imgSrc;

	/* (non-Javadoc)
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest, javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {
		HttpServletResponse response = (HttpServletResponse) res;
		
		List<String> allowedOriginList = new  ArrayList<String>(Arrays.asList(allowedOrigins.split(",")));
		
		String allowedOrign = null;
		
		HttpServletRequest request = (HttpServletRequest) req;
		
		String origin = request.getHeader(HttpHeaders.ORIGIN);
		
		if(!Util.isEmpty(origin)) {
			for(String _allowedOrign: allowedOriginList) {
				if(_allowedOrign.contains(origin)) {
					allowedOrign = _allowedOrign;
				}
			}
		}
		
		
		response.setHeader("Access-Control-Allow-Origin", allowedOrign);
		response.setHeader("Access-Control-Allow-Credentials", "true");
		response.setHeader("Access-Control-Max-Age", maxAge);
		response.setHeader("Access-Control-Allow-Headers", allowedHeadersList);
		response.setHeader("Content-Security-Policy","default-src 'self'");
		response.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
		response.setHeader("Content-Security-Policy","style-src 'unsafe-inline' 'self' https://db.onlinewebfonts.com https://use.fontawesome.com; default-src 'self';script-src-elem https://cdn.jsdelivr.net default-src 'self'; "
				+ "font-src https://use.fontawesome.com default-src 'self';img-src "+imgSrc+" 'self';");
		
		/*String tenant = request.getHeader("tenant");
		
		RequestContextHolder.getRequestAttributes().setAttribute("tenantId",tenant, RequestAttributes.SCOPE_REQUEST);*/
		
		chain.doFilter(req, res);
	}

	/* (non-Javadoc)
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 */
	public void init(FilterConfig filterConfig) {}

	/* (non-Javadoc)
	 * @see javax.servlet.Filter#destroy()
	 */
	public void destroy() {}
}
