package com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.model;

import java.io.Serializable;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="domainspecificrulebook")
public class DomainSpecificRuleBook extends RuleBook  implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** Page URL for the run */
	private String pageURL;

	/**
	 * @return the pageURL
	 */
	public String getPageURL() {
		return pageURL;
	}

	/**
	 * @param pageURL the pageURL to set
	 */
	public void setPageURL(String pageURL) {
		this.pageURL = pageURL;
	}
	
	
	
}
