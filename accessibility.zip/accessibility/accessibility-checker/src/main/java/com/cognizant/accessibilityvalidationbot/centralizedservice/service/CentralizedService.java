package com.cognizant.accessibilityvalidationbot.centralizedservice.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.Base64;
import javax.crypto.spec.SecretKeySpec;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ExitCodeGenerator;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

import com.cognizant.accessibilityvalidationbot.centralizedservice.Utils.Util;
import com.cognizant.accessibilityvalidationbot.centralizedservice.model.CategorizationVO;
import com.cognizant.accessibilityvalidationbot.centralizedservice.model.Configuration;
import com.cognizant.accessibilityvalidationbot.centralizedservice.model.Process;
import com.cognizant.accessibilityvalidationbot.centralizedservice.model.ServiceRequest;
import com.cognizant.accessibilityvalidationbot.centralizedservice.model.Status;
import com.cognizant.accessibilityvalidationbot.centralizedservice.service.serviceHelper.CentralizedServiceHelper;
import com.cognizant.accessibilityvalidationbot.centralizedservice.service.serviceHelper.QueryProcessor;
import com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.model.Report;
import com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.service.serviceHelper.FalsePositiveAnalysisServiceHelper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.impl.crypto.DefaultJwtSignatureValidator;

/**
 * Service used for centralized server API calls
 * @author 578086
 *
 */
@Service
public class CentralizedService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CentralizedService.class);
	
	/**
	 * Helper class for this service
	 */
	@Autowired
	private CentralizedServiceHelper centralizedServiceHelper;
	
	/**
	 * Query Processor class for custom queries
	 */
	@Autowired
	private QueryProcessor queryProcessor;
	
	/** False psoitive service helper class*/
	@Autowired
	private FalsePositiveAnalysisServiceHelper falsePositiveAnalysisServiceHelper;
	
	/** Temporary map contains service request details*/
	@Autowired
	private Map<String,Object> temporaryServiceRequestDetailsMap; 
	
	/** Application context for the instance*/
	@Autowired
	private ApplicationContext applicationContext;
	
	/**
	 * Id to fetch configuration document from database
	 */
	@Value("${app.configuration.mongo.collection.document.id}")
	private String configurationId;
	
	/** URL to remove temporary object from map in false positive service once the validation is completed*/
	@Value("${app.falsepositiveanalysis.remove.temporaryobject.url}")
	private String falsePositiveAnalysisRemoveTemporaryObjectURL;
	
	/** Categorization Service Base URL*/
	@Value("${app.categorization.base.url}")
	private String categorizationBaseUrl;
	
	/** Update Service Request document */
	@Value("${app.update.servicerequest}")
	private String updateServiceRequestURL;
	
	/** Type of execution whether standalone or microservice*/
	@Value("${app.operation.mode}")
	private String modeOfOperation;
	
	/** URL to get the current status of execution*/
	@Value("${app.get.executionStatus.url}")
	private String getExecutionStatusURL;
	
	/** Retry count for getting execution status*/
	@Value("${app.retryCount.executionStatus}")
	private Integer retryCountForExecutionStatus;
	
	/**
	 * Secret Key
	 */
	@Value("${app.jwt.secretKey}")
	private String secretKey;
	
	/**
	 * Method used to start the process
	 * @param url
	 * @param browserName
	 * @param deviceName
	 * @param validationsRequired
	 * @param popupXpath
	 * @return
	 * @throws Exception 
	 */
	public String startProcess(String url, String browserName, String deviceName, List<String> validationsRequired, List<String> popupXpathList, List<String> accessUrlList, Map<String, Object> credentialDataObj, String jwtToken) throws Exception  {
		
		JSONObject credentialJsonObj = null;
		
		

		List<String> branch1ValidationList = new ArrayList<String>(Arrays.asList("OverLap","Alignment","OverFlow","Case Sensitive"));
		
		ServiceRequest serviceRequest = centralizedServiceHelper.createNewServiceRequect();
		
		serviceRequest.setPageURL(url);
		
		serviceRequest.setBrowser(browserName);
		
		serviceRequest.setDeviceName(deviceName);
		
		serviceRequest.setValidationsRequired(validationsRequired);
		
		serviceRequest.setPopupXpathList(popupXpathList);
		
		serviceRequest.setAccessUrlList(accessUrlList);
		
		JSONObject userDataObj = null;
		
		
		if(!Util.isEmpty(jwtToken)) {
			
			userDataObj  =  getUserManagementDataFromJWT(jwtToken);
			
		}	
		
		if(!Util.isEmpty(userDataObj)) {
			
			serviceRequest.setUsername(userDataObj.getString("userMailId"));
			
			serviceRequest.setProjectName(userDataObj.getString("projectName"));
			
			serviceRequest.setExecutionId(userDataObj.getString("executionId"));
			
		}
		
		List<String> validation1AvailableList = new ArrayList<String>();
		
		if (!Util.isEmpty(credentialDataObj)) {

			serviceRequest.setCredentialDataObj(credentialDataObj);

			credentialJsonObj = new JSONObject(credentialDataObj);

		}
		
		validation1AvailableList.addAll(validationsRequired);
		
		validation1AvailableList.retainAll(branch1ValidationList);
		
		
		String response = "Process Executed";
		
				
			//if(validationsRequired.contains("Accessibility")) {
						
			serviceRequest = centralizedServiceHelper.invokeValidationForProcess(serviceRequest, serviceRequest.get_id(), validationsRequired, popupXpathList, accessUrlList, credentialJsonObj);
						
			//}
				
			
			
			if(modeOfOperation.equals("MICROSERVICE")) {
				
				centralizedServiceHelper.insertOrUpdateServiceRequestDocument(serviceRequest);
				
			} else {
				
				Map<String,Object> requestBodyMap = new HashMap<String, Object>();
				
				requestBodyMap.put("serviceRequest", serviceRequest);
				
				JSONObject requestBodyJson = new JSONObject(requestBodyMap);
				
				String requestBody = "{\"param\":"+ requestBodyJson.toString() +"}";
				
				centralizedServiceHelper.sendRequestToMicroService(updateServiceRequestURL, requestBody);
				
				temporaryServiceRequestDetailsMap.put("runIdentifier", serviceRequest.get_id());
				
				temporaryServiceRequestDetailsMap.put("url", serviceRequest.getPageURL());
				
				triggerExecutionStatusCheck();
			}
			
		return response;
	}
	
	/**
	 * Inserting categorization document
	 * @param categorizationVO
	 */
	@SuppressWarnings("unchecked")
	public Map<String,Object> insertCategorization(Map<String,Object> categorizationJSON, String pageTitle, String runIdentifier, String url, int width, int height) {
		
		Map<String,Object> responseData = new HashMap<String, Object>();
		
		CategorizationVO categorizationVO = centralizedServiceHelper.createNewCategorizationVO();
		
		categorizationVO.setRunIdentifier(runIdentifier);
		
		categorizationVO.setUrl(url);
		
		if(categorizationJSON != null) {
			
			for(String jsonKey: categorizationJSON.keySet()) {
				
				if(jsonKey.contains("singleCardDetailsMap")) {
					
					categorizationVO.setSingleCardDetailsMap((Map<String, String>) categorizationJSON.get(jsonKey));
				}
				
				if(jsonKey.contains("repeatedSingleCardDetailsMap")) {
					categorizationVO.setRepeatedSingleCardDetailsMap((Map<String, String>) categorizationJSON.get(jsonKey));
				}
				
				if(jsonKey.contains("repeatedCardDetailsMap")) {
					categorizationVO.setRepeatedCardDetailsMap((Map<String, String>) categorizationJSON.get(jsonKey));
				}
				
				if(jsonKey.contains("horizontalMenuDetailsMap")) {
					categorizationVO.setHorizontalMenuDetailsMap((Map<String, String>) categorizationJSON.get(jsonKey));
				}
				
				if(jsonKey.contains("verticalMenuDetailsMap")) {
					categorizationVO.setVerticalMenuDetailsMap((Map<String, String>) categorizationJSON.get(jsonKey));
				}
				
				if(jsonKey.contains("carouselDetailsMap")) {
					categorizationVO.setCarouselDetailsMap((Map<String, String>) categorizationJSON.get(jsonKey));
				}
				
				if(jsonKey.contains("hoverableMenuDetailsMap")) {
					categorizationVO.setHoverableMenuDetailsMap((Map<String, String>) categorizationJSON.get(jsonKey));
				}
				
				if(jsonKey.contains("carouselPreviousNextDotDetailsMap")) {
					categorizationVO.setCarouselPreviousNextDotDetailsMap((Map<String, Map<String,String>>) categorizationJSON.get(jsonKey));
				}
				
				if(jsonKey.contains("otherDetailsMap")) {
					categorizationVO.setOtherDetailsMap((Map<String, String>) categorizationJSON.get(jsonKey));
				}
				
				if(jsonKey.contains("repeatedSingleCardKeyDetailsMap")) {
					categorizationVO.setRepeatedSingleCardKeyDetailsMap((Map<String, String>)categorizationJSON.get(jsonKey));
				}
				
				if(jsonKey.contains("hoverableMenuChildXpathDetailsMap")) {
					categorizationVO.setHoverableMenuChildXpathDetailsMap((Map<String, String>)categorizationJSON.get(jsonKey));
				}
				
				if(jsonKey.contains("carouselDotsXpathDetails")) {
					categorizationVO.setCarouselDotsXpathDetails((String)categorizationJSON.get(jsonKey));
				}
			}
		}
		
		centralizedServiceHelper.insertCategorizationDocument(categorizationVO);
		
		ServiceRequest serviceRequest = centralizedServiceHelper.getServiceRequestById(runIdentifier);
		
		serviceRequest.getStatusMap().replace(Process.CATEGORIZATION, Status.COMPLETED);
		
		Map<String,Integer> dimensionDetails = new HashMap<String, Integer>();
		
		dimensionDetails.put("width", width);
		
		dimensionDetails.put("height", height);
		
		serviceRequest.getDimensionDetails().put(url.replace("https://", "").replaceAll("\\.","_"), dimensionDetails);
		
		serviceRequest.setPageTitle(pageTitle);

		centralizedServiceHelper.insertOrUpdateServiceRequestDocument(serviceRequest);
		
		responseData.put("categorizationVO", categorizationVO);
		
		responseData.put("serviceRequest", serviceRequest);
		
		return responseData;
		
	}
	
	
	/**
	 * Method to initiate different validation branches based on runIdentifier
	 * @param runIdentifier
	 * @return
	 */
	public String startValidation(String runIdentifier, Map<String,Object> categorizedDataMap) {
		
		return centralizedServiceHelper.fetchAndSendCategorizationDataToValidation(runIdentifier, categorizedDataMap);
	}
	
	
	/**
	 * Method to fetch all the service request
	 * @return
	 */
	public List<ServiceRequest> fetchAllServiceRequest() {
		
		return centralizedServiceHelper.fetchAllServiceRequest();
		
	}
	
	/**
	 * Method to fetch report by run identifier and url
	 * @param runIdentifier
	 * @param url
	 * @return
	 */
	public Report getReportByRunIdentifierAndUrl(String runIdentifier, String url) {
		
		return queryProcessor.getReportByRunIdentifierAndUrl(runIdentifier, url);
		
	}
	
	/**
	 * Method to check and update the status in service request
	 * @param processName
	 * @param runIdentifier
	 */
	public void checkAndUpdateStatus(Process processName, String runIdentifier) {
		
		try {
			LOGGER.info("In checkAndUpdateStatus method "+ processName + "with identifier " + runIdentifier );
			
			ServiceRequest serviceRequest = centralizedServiceHelper.getServiceRequestById(runIdentifier);
			
			serviceRequest.getStatusMap().put(processName, Status.COMPLETED);
			
			if(centralizedServiceHelper.checkForEndTimeUpdateStatus(serviceRequest)) {
				
				String requestBody = "{\"param\":{\"url\":\""+ serviceRequest.getPageURL() +"\"}}";
				
				String _falsePositiveAnalysisRemoveTemporaryObjectURL = falsePositiveAnalysisRemoveTemporaryObjectURL + runIdentifier;
				
				centralizedServiceHelper.sendRequestToMicroService(_falsePositiveAnalysisRemoveTemporaryObjectURL, requestBody);
				
				serviceRequest.setEndTime(Util.getDateWithTimeAsDate());
				
			}
			
			centralizedServiceHelper.insertOrUpdateServiceRequestDocument(serviceRequest);
			
		} catch (Exception e) {
			LOGGER.error("Error Occured while updating the status for service "+ processName + "with identifier " + runIdentifier );
		}
		
	}
	
	/**
	 * Method for ignoring particular or all similar type issues in report by user
	 * @param isIgnoreAll
	 * @param runIdentifier
	 * @param url
	 * @param issueId
	 * @return
	 */
	public Report ignoreOneIssueOrAllIssuesInReport(boolean isIgnoreAll, String runIdentifier, String url, String issueId, String validationCategoryConfigurationLabel) {
		
		Report report = getReportByRunIdentifierAndUrl(runIdentifier, url);
		
		Configuration configuration = centralizedServiceHelper.fetchConfiguration(configurationId);
		
		return falsePositiveAnalysisServiceHelper.ignoreOneOrAll(isIgnoreAll, report, issueId, configuration.getConfiguration(), validationCategoryConfigurationLabel);
	}
	
	/**
	 * Method to update service request document
	 * @param requestBodyDataMap
	 */
	public void updateServiceRequestDocument(Map<String,Object> requestBodyDataMap) {
		
		ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());
		
		ServiceRequest serviceRequest = objectMapper.convertValue(requestBodyDataMap.get("serviceRequest"), ServiceRequest.class);
		
		centralizedServiceHelper.insertOrUpdateServiceRequestDocument(serviceRequest);
		
	}
	
	/**
	 * Method to find whether the execution is completed or not
	 * @param runIdentifier
	 * @return
	 */
	public boolean isExecutionCompleted(String runIdentifier, String url) {
		
		LOGGER.info("Execution Status method is called with runIdentifier:" + runIdentifier + ", URL" + url);
		
		if(modeOfOperation.equals("MICROSERVICE")) {
			
			ServiceRequest serviceRequest = centralizedServiceHelper.getServiceRequestById(runIdentifier);
			
			return centralizedServiceHelper.checkForEndTimeUpdateStatus(serviceRequest);
			
		} else {
			
			if(temporaryServiceRequestDetailsMap.containsKey("url") && temporaryServiceRequestDetailsMap.containsKey("runIdentifier")) {
				
				runIdentifier = temporaryServiceRequestDetailsMap.get("runIdentifier").toString();
				
				url = temporaryServiceRequestDetailsMap.get("url").toString();
				
				LOGGER.info("Execution Status method is called.runIdentifier:" + runIdentifier + "and URL" + url + "in temporary Map");
				
				String requestBody = "{\"param\":{\"url\":\""+ url + "\", \"runIdentifier\":\""+ runIdentifier +"\"}}";
				
				String response = centralizedServiceHelper.sendRequestToMicroService(getExecutionStatusURL, requestBody);
				
				LOGGER.info("Response from Centralized service. Response"+ response);
				
				return response.equals("true");
				
			}
			
			return false;
			
		}
		
	}
	
	/**
	 * Method will be triggered for monitoring the execution
	 *  
	 */
	public void triggerExecutionStatusCheck() {
		
		LOGGER.info("Method to check execution status is triggered..");
		
		Thread thread = new Thread(new Runnable() {

			@Override
			public void run() {
				
				checkExecutionStatusWithRetryCount(retryCountForExecutionStatus, 0, applicationContext);
			}
		});

		thread.start();
		
	}
	
	/**
	 * Recursive method for checking the execution status in a time interval of 60 seconds
	 * 
	 * @param retryCount
	 * @param counter
	 * @param context
	 * @return
	 */
	public String checkExecutionStatusWithRetryCount(int retryCount, int counter, ApplicationContext context) {
		
		if(counter > retryCount) {
			
			shutdownApplication(context);
			
			return null;
			
		}
		
		counter++;
		
		try {
			
			Thread.sleep(60000);
			
			boolean _isExecutionCompleted = isExecutionCompleted(null, null);
			
			LOGGER.info("Execution Status:" + _isExecutionCompleted + ", Retry Count:" + counter);
			
			if(_isExecutionCompleted) {
				
				shutdownApplication(context);
				
			} 
			
		}catch (Exception e) {
			
			e.printStackTrace();
			
			LOGGER.error("Error occurred while getting the execution status.Retry Count:" + counter + ", Error:" + e.getMessage());
			
		}
		
		checkExecutionStatusWithRetryCount(retryCount, counter, context);
		
		return null;
	}
	
	/**
	 * Method to shutdown the spring boot instance
	 * @param context
	 */
	public void shutdownApplication(ApplicationContext context) {
		
		LOGGER.info("Spring boot instance shutdowned..." + Util.generateDateWithTimeAsString());
		
		SpringApplication.exit(context, new ExitCodeGenerator() {
            @Override
            public int getExitCode() {
                return 0;
            }
        });
	}
	
	/**
	 * Method to decode the jwt token and retrieve userData
	 * @param jwtToken
	 * @throws Exception 
	 */
	public JSONObject getUserManagementDataFromJWT(String jwtToken) throws Exception {
		
		Base64.Decoder decoder = Base64.getDecoder();
		
		String[] chunks = jwtToken.split("\\.");
		
		SignatureAlgorithm sa = SignatureAlgorithm.HS512;
		
		SecretKeySpec secretKeySpec = new SecretKeySpec(secretKey.getBytes(), sa.getJcaName());
		
		String tokenWithoutSignature = chunks[0] + "." + chunks[1];
		
		String signature = chunks[2];
		
		DefaultJwtSignatureValidator validator = new DefaultJwtSignatureValidator(sa, secretKeySpec);

		if (!validator.isValid(tokenWithoutSignature, signature)) {
			
		    throw new Exception("Could not verify JWT token integrity with the secret key!");
		    
		}
		else {
			
			 String userData = new String(decoder.decode(chunks[1]));
			
			 JSONObject userDataObj = new JSONObject(userData);
			 
			 return userDataObj;
			
		}
		
	}
	
	/**
	 * Method to fetch  the service requests based on userName and executionID
	 * @return
	 * @throws Exception 
	 */
	public List<ServiceRequest> fetchServiceRequestBasedOnUserData(String reportToken) throws Exception {
		
		JSONObject userDataObj =  getUserManagementDataFromJWT(reportToken);
		
		return queryProcessor.fetchServiceRequestByUserData(userDataObj);
		
	}
	
}
