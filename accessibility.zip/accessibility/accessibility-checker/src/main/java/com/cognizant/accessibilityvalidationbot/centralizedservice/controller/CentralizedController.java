package com.cognizant.accessibilityvalidationbot.centralizedservice.controller;

import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.accessibilityvalidationbot.centralizedservice.Utils.Util;
import com.cognizant.accessibilityvalidationbot.centralizedservice.model.Process;
import com.cognizant.accessibilityvalidationbot.centralizedservice.model.Request;
import com.cognizant.accessibilityvalidationbot.centralizedservice.service.CentralizedService;
import com.cognizant.rtfbridge.RTFBridge;


/**
 * Main Controller to start all process
 * @author 578086
 *
 */
@RestController
@RequestMapping(value = "/api/v1/accessibility",
consumes = MediaType.APPLICATION_JSON_VALUE,
produces = MediaType.APPLICATION_JSON_VALUE)
public class CentralizedController extends CommonController{

	private static final Logger LOGGER = LoggerFactory.getLogger(CentralizedController.class);
	
	/**
	 * Service class used to execute all process
	 */
	@Autowired
	private CentralizedService centralizedService;
	
	/**
	 * API for start executing the tool
	 * @param urlRequest
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked") 
	@RequestMapping(method = RequestMethod.POST,value="centralizedservice/process")
	public ResponseEntity<?> startProecss(@RequestBody Request urlRequest) throws Exception
	{
		
		String deviceName = null;
		
		String validationRequired = null;
		
		List<String> validationsRequiredList = null;
		
		Map<String, Object> credentialDataObj = new HashMap<String, Object>();	
		
		List<String> popupXpathList = null;
		
		List<String> accessUrlList = null;
		
		String jwtToken = null;
		
		String browserName = (String) urlRequest.getParam().get("browser");
		
		if(urlRequest.getParam().containsKey("deviceName")) {
			deviceName = (String) urlRequest.getParam().get("deviceName");
		}
		
		if(urlRequest.getParam().containsKey("validationsRequired")) {
			validationRequired = (String) urlRequest.getParam().get("validationsRequired");
		}
		
		if(urlRequest.getParam().containsKey("popUpXpath")) {
			
			popupXpathList = (List<String>) urlRequest.getParam().get("popUpXpath");
			
		}
		
		if(urlRequest.getParam().containsKey("accessUrlList")) {
			
			accessUrlList = (List<String>) urlRequest.getParam().get("accessUrlList");
			
		}
		
		if(urlRequest.getParam().containsKey("multiURLArray")) {
			
			List<String> multipleURLList = (List<String>) urlRequest.getParam().get("multiURLArray");
			
			LOGGER.info("Process started for the page. Multiple URL Size:" + multipleURLList.size() + ", BrowserSelected:" + browserName + ", DeviceSelected" + deviceName);
			
			String popupXpathString = popupXpathList.stream().map( value -> String.valueOf(value)).collect(Collectors.joining(","));
			
			String accessURLListAsString = accessUrlList.stream().map( value -> String.valueOf(value)).collect(Collectors.joining(","));
			
			Map<String,String> properties = new LinkedHashMap<>();
			
			properties.put("validationRequired", "\"" + validationRequired + "\"");
			
			properties.put("popupXpath", "\"" + popupXpathString + "\"");
			
			properties.put("accessUrlList", "\"" + accessURLListAsString + "\"");
			
			if(!urlRequest.getParam().containsKey("jwtToken")) {
				
				throw new RuntimeException("Token is missing");
				
			}
			
			if(!urlRequest.getParam().containsKey("hostName")) {
				
				throw new RuntimeException("hostName is missing");
				
			}
			
			if (urlRequest.getParam().containsKey("credentialData")) {
			
				properties.putAll((Map<String, String>) urlRequest.getParam().get("credentialData"));
				
			}
			
			
			jwtToken = (String) urlRequest.getParam().get("jwtToken");
			
			String hostName = (String) urlRequest.getParam().get("hostName");
			
			RTFBridge rtfBridge = new RTFBridge();
			
			return buildSuccessResponse(rtfBridge.createAndExecuteTasks(multipleURLList, properties, jwtToken, hostName));
			
		} else {
			
			String url = (String) urlRequest.getParam().get("url");
			
			LOGGER.info("Process started for the page. URL:" + url + ", BrowserSelected:" + browserName + ", DeviceSelected" + deviceName);
			
			if(!Util.isEmpty(validationRequired)) {
				
				validationsRequiredList = Arrays.asList(validationRequired.split(","));
				
			}
			
			
			if (urlRequest.getParam().containsKey("credentialData")) {
				credentialDataObj = (Map<String, Object>) urlRequest.getParam().get("credentialData");
			}
			
			
			
			if(urlRequest.getParam().containsKey("jwtToken")) {
				
				jwtToken = (String) urlRequest.getParam().get("jwtToken");
					
			}
			

			return buildSuccessResponse(centralizedService.startProcess(url, browserName, deviceName, validationsRequiredList, popupXpathList, accessUrlList, credentialDataObj, jwtToken));
			
		}

		

	}
	
	/**
	 * API to call the validation service based on runIdentifier, after getting notification from categorization service
	 * @param runIdentifier
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST,value="centralizedservice/notifyValidation/{runIdentifier}")
	public ResponseEntity<?> startValidation(@PathVariable("runIdentifier") String runIdentifier, @RequestBody Request requestData) 
	{
		LOGGER.info("Validation invoked for the run. RunIdentifier" + runIdentifier);
		
		Map<String,Object> categorizedRequestDataMap = requestData.getParam();
		
		return buildSuccessResponse(centralizedService.startValidation(runIdentifier, categorizedRequestDataMap));
	}
	
	/**
	 * API to call the validation service based on runIdentifier, after getting notification from categorization service
	 * @param runIdentifier
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST,value="centralizedservice/report/{identifier}")
	public ResponseEntity<?> getReports(@PathVariable("identifier") String identifier, @RequestBody Request urlRequest) 
	{
		LOGGER.info("Reports fetch invoked. RunIdentifier" + identifier);
		
		String reportsToken = null;
		
		if(urlRequest.getParam().containsKey("reportsToken")) {
			
			reportsToken = (String) urlRequest.getParam().get("reportsToken");
		
		}
		
		if(identifier.toUpperCase().equals("ALL")) {
			
			if(!Util.isEmpty(reportsToken)) {
				
				try {
					
					return buildSuccessResponse(centralizedService.fetchServiceRequestBasedOnUserData(reportsToken));
				
				} catch (Exception e) {
					
					LOGGER.info("Failed in getReports method while fetching reports with user data");
					
					e.printStackTrace();
					
					return buildFailureResponse(500, e.getMessage());
				}
				
			}
			else {
				
				return buildSuccessResponse(centralizedService.fetchAllServiceRequest());
				
			}
			
		} else {
			
			String url = (String) urlRequest.getParam().get("url");
			
			return buildSuccessResponse(centralizedService.getReportByRunIdentifierAndUrl(identifier, url));
			
		}
		
	}
	
	/**
	 * API for updating the status
	 * @param runIdentifier
	 * @param processName
	 * @return
	 */
	@RequestMapping(method = RequestMethod.GET,value="centralizedservice/update/status/{runIdentifier}/{processName}")
	public ResponseEntity<?> updateStatus(@PathVariable("runIdentifier") String runIdentifier, @PathVariable("processName") Process processName) 
	{
		LOGGER.info("Update status invoked for the run. RunIdentifier" + runIdentifier);
		
		centralizedService.checkAndUpdateStatus(processName, runIdentifier);
		
		return buildSuccessResponse("Updated status Successfully");
	}
	
	/**
	 * API for ignore particular issue or all similar type issues from validated report by user
	 * @param runIdentifier
	 * @param isIgnoreAll
	 * @param issueId
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST,value="centralizedservice/report/ignore/issue/{runIdentifier}/{issueId}/{isIgnoreAll}/{validationCategoryConfigurationLabel}")
	public ResponseEntity<?> ignoreOneIssueOrAllSimilarIssuesInReport(@PathVariable("runIdentifier") String runIdentifier, @PathVariable("isIgnoreAll") boolean isIgnoreAll,
																	  @PathVariable("issueId") String issueId, @PathVariable("validationCategoryConfigurationLabel") String validationCategoryConfigurationLabel, @RequestBody Request request)
	{
		String url = (String) request.getParam().get("url");
		
		return buildSuccessResponse(centralizedService.ignoreOneIssueOrAllIssuesInReport(isIgnoreAll, runIdentifier, url, issueId, validationCategoryConfigurationLabel));
	}
	
	/**
	 * API for updating the service request
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST,value="centralizedservice/update/serviceRequest")
	public ResponseEntity<?> updateServiceRequestDocument(@RequestBody Request request) {
		
		Map<String,Object> serviceRequestMap = request.getParam();
		
		centralizedService.updateServiceRequestDocument(serviceRequestMap);
		
		return buildSuccessResponse("Successfully updated the service request");
	}
	
	/**
	 * API for getting execution status 
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST,value="centralizedservice/get/executionStatus")
	public ResponseEntity<?> getExecutionStatus(@RequestBody Request request){
		
		String url = (String) request.getParam().get("url");		
		
		String runIdentifier = 	(String) request.getParam().get("runIdentifier");
		
		return buildSuccessResponse(centralizedService.isExecutionCompleted(runIdentifier, url));
	}
}
