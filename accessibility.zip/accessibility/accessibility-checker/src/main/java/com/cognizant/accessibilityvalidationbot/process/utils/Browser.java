package com.cognizant.accessibilityvalidationbot.process.utils;

/**
 * Enumeration to represent the browser to be used for execution
 * 
 * @author Cognizant
 */
public enum Browser {
	CHROME("chrome"), FIREFOX("firefox"), GHOST_DRIVER("phantomjs"), INTERNET_EXPLORER("internet explorer"), SAFARI(
			"safari"), CHROME_HEADLESS("chrome_headless"), EDGE("edge"), MOBILE("mobile");

	private String value;

	Browser(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}
}