package com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.controller;

import java.io.IOException;
import java.util.Map;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.accessibilityvalidationbot.centralizedservice.model.Request;
import com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.service.FalsePositiveAnalysisService;

/**
 * Controller responsible for false positive analysis
 * @author 578086
 *
 */
@RestController
@RequestMapping(value = "/api/v1/accessibility",
consumes = MediaType.APPLICATION_JSON_VALUE,
produces = MediaType.APPLICATION_JSON_VALUE)
public class FalsePositiveAnalysisController extends CommonFalsePositiveAnalysisController{

	private static final Logger LOGGER = LoggerFactory.getLogger(FalsePositiveAnalysisController.class);
	
	/** Service for false positive analysis*/
	@Autowired
	private FalsePositiveAnalysisService falsePositiveAnalysisService;
	
	/**
	 * API for analyzing the validation result with rule book and other secondary validation services.
	 * @param runIdentifier
	 * @param urlRequest
	 * @return
	 * @throws IOException 
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(method = RequestMethod.POST,value="centralizedservice/falsepositiveanalysis/analyze/{runIdentifier}")
	public ResponseEntity<?> initiateFalsePositiveAnalysis(@PathVariable("runIdentifier") String runIdentifier, @RequestBody Request request) throws IOException 
	{
		LOGGER.info("False Positive Analysis Started for run Identifier:" + runIdentifier);
		
		String url = (String) request.getParam().get("url");
		
		String branch = (String) request.getParam().get("branch");
		
		String pageTitle = (String) request.getParam().get("pageTitle");
		
		Map<String,Object> accessibilityResultJson = null;
		
		int bodyWidth = 0;
		
		int bodyHeight = 0;
		
		String base64ScreenShot = null;
		
		
		
		
		if(request.getParam().containsKey("bodyWidth")) {
			
			bodyWidth = Integer.parseInt((String) request.getParam().get("bodyWidth"));
			
		}
		
		if(request.getParam().containsKey("bodyHeight")) {
			
			bodyHeight = Integer.parseInt((String) request.getParam().get("bodyHeight"));
			
		}
		
		if(request.getParam().containsKey("base64ScreenShot")) {
			
			base64ScreenShot = (String) request.getParam().get("base64ScreenShot");
			
		}
		
		if(request.getParam().containsKey("accessibilityResultJson")) {
			
			accessibilityResultJson = (Map<String,Object>)request.getParam().get("accessibilityResultJson");
			
		}
		
		
		//Map<String,Object> validationResultJson =   (Map<String,Object>) request.getParam().get("validationResultJson");
		
			
		JSONObject validationResult = new JSONObject(accessibilityResultJson);
				
		LOGGER.info("False Positive Analysis Started, run Identifier:" + runIdentifier + ", Category" + branch);
			
		falsePositiveAnalysisService.analyzeAndSendResponseToCentralizedService(runIdentifier, validationResult, branch, url, bodyWidth, bodyHeight, base64ScreenShot,pageTitle);
		
		return buildSuccessResponse("False Positive Analysis Successfully done");
	}
	
	/**
	 * API for inserting temporary object in the map for doing false positive analysis for the URL before starting the analysis.
	 * @param urlRequest
	 * @param runIdentifier
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST,value="centralizedservice/falsepositiveanalysis/temporaryObjectMap/add/{runIdentifier}")
	public ResponseEntity<?> addTemporaryObjectForUrl(@RequestBody Request request, @PathVariable("runIdentifier") String runIdentifier) 
	{
		String url = (String) request.getParam().get("url");
		
		falsePositiveAnalysisService.fetchAndSetTheObjectInTemporaryObjectMap(url, runIdentifier);
		
		return buildSuccessResponse("inserted successfully");
	}
	
	/**
	 * API for removing the temporary objects from temporary object map and temporary report map, once the analysis is completed.
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST,value="centralizedservice/falsepositiveanalysis/temporaryObjectMap/remove/{runIdentifier}")
	public ResponseEntity<?> removeTemporaryObjectForUrl(@RequestBody Request request, @PathVariable("runIdentifier") String runIdentifier) 
	{
		
		String url = (String) request.getParam().get("url");
		
		falsePositiveAnalysisService.removeTemporaryObjectFromMap(url, runIdentifier);
		
		return buildSuccessResponse("removed successfully");
	}
	
}
