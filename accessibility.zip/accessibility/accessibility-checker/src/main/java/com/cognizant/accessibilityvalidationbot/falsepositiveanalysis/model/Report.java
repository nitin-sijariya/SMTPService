package com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.model;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.jetbrains.annotations.NotNull;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * POJO Class for saving the validation report
 * @author 578086
 *
 */
@Document(collection="reportVO")
public class Report implements Serializable{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The id. */
	@Id
	@NotNull
	private String _id;
	
	/** Run identifier. mongo id of Service Request **/
	private String runIdentifier;
	
	/** Run URL */
	private String pageURL;
	
	/** consolidate  report Map for this page URL **/
	
	private Map<String,Map<String,Object>> reportObject = new HashMap<String,Map<String,Object>>();
	
	/** Date of creation **/
	private Date createdDate;
	
	/** Screen shot url */
	private String screenShotURL;
	
	/** Screen shot absolute path */
	private String screenShotAbsolutePath;
	
	/** Map for storing report meta dat*/
	private Map<String, Object> reportObjectMetaData = new HashMap<String, Object>();
	
	/** Map for storing Font meta data*/
	private Map<String,Integer> fontMetaData = new HashMap<>();
	
	/** Map for storing all text Font family Details */
	private Map<String,Object> fontFamilyDetails = new HashMap<>();

	/**
	 * @return the _id
	 */
	public String get_id() {
		return _id;
	}

	/**
	 * @param _id the _id to set
	 */
	public void set_id(String _id) {
		this._id = _id;
	}

	/**
	 * @return the runIdentifier
	 */
	public String getRunIdentifier() {
		return runIdentifier;
	}

	/**
	 * @param runIdentifier the runIdentifier to set
	 */
	public void setRunIdentifier(String runIdentifier) {
		this.runIdentifier = runIdentifier;
	}

	/**
	 * @return the url
	 */
	public String getPageURL() {
		return pageURL;
	}

	/**
	 * @param url the url to set
	 */
	public void setPageURL(String pageURL) {
		this.pageURL = pageURL;
	}

	/**
	 * @return the reportObject
	 */
	public Map<String, Map<String,Object>> getReportObject() {
		return reportObject;
	}

	/**
	 * @param reportObject the reportObject to set
	 */
	public void setReportObject(Map<String, Map<String,Object>> reportObject) {
		this.reportObject = reportObject;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the screenShotURL
	 */
	public String getScreenShotURL() {
		return screenShotURL;
	}

	/**
	 * @param screenShotURL the screenShotURL to set
	 */
	public void setScreenShotURL(String screenShotURL) {
		this.screenShotURL = screenShotURL;
	}

	/**
	 * @return the screenShotAbsolutePath
	 */
	public String getScreenShotAbsolutePath() {
		return screenShotAbsolutePath;
	}

	/**
	 * @param screenShotAbsolutePath the screenShotAbsolutePath to set
	 */
	public void setScreenShotAbsolutePath(String screenShotAbsolutePath) {
		this.screenShotAbsolutePath = screenShotAbsolutePath;
	}

	/**
	 * @return the reportObjectMetaData
	 */
	public Map<String, Object> getReportObjectMetaData() {
		return reportObjectMetaData;
	}

	/**
	 * @param reportObjectMetaData the reportObjectMetaData to set
	 */
	public void setReportObjectMetaData(Map<String, Object> reportObjectMetaData) {
		this.reportObjectMetaData = reportObjectMetaData;
	}

	/**
	 * @return the fontMetaData
	 */
	public Map<String, Integer> getFontMetaData() {
		return fontMetaData;
	}

	/**
	 * @param fontMetaData the fontMetaData to set
	 */
	public void setFontMetaData(Map<String, Integer> fontMetaData) {
		this.fontMetaData = fontMetaData;
	}

	/**
	 * @return the fontFamilyDetails
	 */
	public Map<String, Object> getFontFamilyDetails() {
		return fontFamilyDetails;
	}

	/**
	 * @param fontFamilyDetails the fontFamilyDetails to set
	 */
	public void setFontFamilyDetails(Map<String, Object> fontFamilyDetails) {
		this.fontFamilyDetails = fontFamilyDetails;
	}

}
