package com.cognizant.accessibilityvalidationbot.centralizedservice.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.accessibilityvalidationbot.centralizedservice.model.Request;
import com.cognizant.accessibilityvalidationbot.centralizedservice.service.CentralizedService;

/**
 * Controller used for database transaction
 * @author 578086
 *
 */
@RestController
@RequestMapping(value = "/api/v1/accessibility/centralizedservice/transaction",
consumes = MediaType.APPLICATION_JSON_VALUE,
produces = MediaType.APPLICATION_JSON_VALUE)

public class CentralizedTransactionController extends CommonController{

	private static final Logger LOGGER = LoggerFactory.getLogger(CentralizedTransactionController.class);
	
	/**
	 * Service class used to execute all process
	 */
	@Autowired
	private CentralizedService centralizedService;
	
	/**
	 * API for inserting the categorization result
	 * @param urlRequest
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(method = RequestMethod.POST,value="insert/categorization/document/{runIdentifier}")
	public ResponseEntity<?> insertCategorizationResult(@RequestBody Request categorizedData, @PathVariable("runIdentifier") String runIdentifier) 
	{
		
		LOGGER.info("Inserting the categorization document");
		
		Map<String,Object> param = categorizedData.getParam();
		
		Map<String,Object> categoryJson = (Map<String,Object>) param.get("categoryJson");
		
		String url = (String) param.get("url");
		
		String width = (String) param.get("width");
		
		String height = (String) param.get("height");
		
		String pageTitle = null;
		
		if(param.containsKey("pageTitle")) {
			
			pageTitle = (String) param.get("pageTitle");
			
		}
		
		return buildSuccessResponse(centralizedService.insertCategorization(categoryJson, pageTitle,runIdentifier, url, Integer.parseInt(width), Integer.parseInt(height)));
	}
}
