package com.cognizant.accessibilityvalidationbot.centralizedservice.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jetbrains.annotations.NotNull;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * Main Service Request POJO class for storing using entered values
 * 
 * @author 578086
 *
 */
@Document(collection="serviceRequest")
public class ServiceRequest implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The id. */
	@Id
	@NotNull
	private String _id;
	
	/** List for capturing validations to perform **/
	private List<String> validationsRequired = new ArrayList<String>();
	
	/** Screen Shot file path**/
	private String screenShotAbsolutePath;
	
	/** Screen Shot file URL **/
	private String screenShotURL;
	
	/** Date of creation **/
	@JsonFormat(pattern="yyyy-MM-dd'T'HH:mm:ss")
	private LocalDateTime createdDate;
	
	/** Execution start time **/
	@JsonFormat(pattern="yyyy-MM-dd'T'HH:mm:ss")
	private LocalDateTime startTime;
	
	/** Execution end time **/
	@JsonFormat(pattern="yyyy-MM-dd'T'HH:mm:ss")
	private LocalDateTime endTime;
	
	/** Execution URL **/
	private String pageURL;
	
	/** chosen browser **/
	private String browser;
	
	/** Mobile deviceName **/
	private String deviceName;
	
	/**  Page Title **/
	private String pageTitle;
	
	/** Crawled URL'S available for execution based on given URL **/
	private List<String> crawledURL;
	
	/** Pop up close button xpath*/
	private List<String> popupXpathList;
	
	/** Status Map will contains the status of the process */
	private Map<Process,Status> statusMap = new HashMap<Process, Status>();
	
	/** Map contains dimension of the page*/
	private Map<String,Map<String,Integer>> dimensionDetails = new HashMap<String,Map<String,Integer>>();

	/** List of access URL needs to be visited before executing the page **/
	private List<String> accessUrlList;
	
	/** Map contains credential information **/
	private Map<String, Object> credentialDataObj;
	
	/** User Email Id **/
	private String username;
	
	/** Project Name **/
	private String projectName;
	
	/** Execution Id **/
	private String executionId;
	
	/**
	 * @return the _id
	 */
	public String get_id() {
		return _id;
	}

	/**
	 * @param _id the _id to set
	 */
	public void set_id(String _id) {
		this._id = _id;
	}

	/**
	 * @return the validationRequired
	 */
	public List<String> getValidationsRequired() {
		return validationsRequired;
	}

	/**
	 * @param validationRequired the validationRequired to set
	 */
	public void setValidationsRequired(List<String> validationsRequired) {
		this.validationsRequired = validationsRequired;
	}

	/**
	 * @return the screenShotAbsolutePath
	 */
	public String getScreenShotAbsolutePath() {
		return screenShotAbsolutePath;
	}

	/**
	 * @param screenShotAbsolutePath the screenShotAbsolutePath to set
	 */
	public void setScreenShotAbsolutePath(String screenShotAbsolutePath) {
		this.screenShotAbsolutePath = screenShotAbsolutePath;
	}

	/**
	 * @return the screenShotURL
	 */
	public String getScreenShotURL() {
		return screenShotURL;
	}

	/**
	 * @param screenShotURL the screenShotURL to set
	 */
	public void setScreenShotURL(String screenShotURL) {
		this.screenShotURL = screenShotURL;
	}

	/**
	 * @return the createdDate
	 */
	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the startTime
	 */
	public LocalDateTime getStartTime() {
		return startTime;
	}

	/**
	 * @param startTime the startTime to set
	 */
	public void setStartTime(LocalDateTime startTime) {
		this.startTime = startTime;
	}

	/**
	 * @return the endTime
	 */
	public LocalDateTime getEndTime() {
		return endTime;
	}

	/**
	 * @param endTime the endTime to set
	 */
	public void setEndTime(LocalDateTime endTime) {
		this.endTime = endTime;
	}

	/**
	 * @return the pageURL
	 */
	public String getPageURL() {
		return pageURL;
	}

	/**
	 * @param pageURL the pageURL to set
	 */
	public void setPageURL(String pageURL) {
		this.pageURL = pageURL;
	}

	/**
	 * @return the browser
	 */
	public String getBrowser() {
		return browser;
	}

	/**
	 * @param browser the browser to set
	 */
	public void setBrowser(String browser) {
		this.browser = browser;
	}

	/**
	 * @return the deviceName
	 */
	public String getDeviceName() {
		return deviceName;
	}

	/**
	 * @param deviceName the deviceName to set
	 */
	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}

	/**
	 * @return the crawledURL
	 */
	public List<String> getCrawledURL() {
		return crawledURL;
	}

	/**
	 * @param crawledURL the crawledURL to set
	 */
	public void setCrawledURL(List<String> crawledURL) {
		this.crawledURL = crawledURL;
	}

	/**
	 * @return the popupXpathList
	 */
	public List<String> getPopupXpathList() {
		return popupXpathList;
	}

	/**
	 * @param popupXpathList the popupXpathList to set
	 */
	public void setPopupXpathList(List<String> popupXpathList) {
		this.popupXpathList = popupXpathList;
	}

	/**
	 * @return the statusMap
	 */
	public Map<Process, Status> getStatusMap() {
		return statusMap;
	}

	/**
	 * @param statusMap the statusMap to set
	 */
	public void setStatusMap(Map<Process, Status> statusMap) {
		this.statusMap = statusMap;
	}

	/**
	 * @return the dimensionDetails
	 */
	public Map<String, Map<String, Integer>> getDimensionDetails() {
		return dimensionDetails;
	}

	/**
	 * @param dimensionDetails the dimensionDetails to set
	 */
	public void setDimensionDetails(Map<String, Map<String, Integer>> dimensionDetails) {
		this.dimensionDetails = dimensionDetails;
	}
	
	/**
	 * @return the page title
	 */
	public String getPageTitle() {
		return pageTitle;
	}
	
	/**
	 * @param page title the page title to set
	 */
	public void setPageTitle(String pageTitle) {
		this.pageTitle = pageTitle;
	}

	/**
	 * @return the accessUrlList
	 */
	public List<String> getAccessUrlList() {
		return accessUrlList;
	}

	/**
	 * @param accessUrlList the accessUrlList to set
	 */
	public void setAccessUrlList(List<String> accessUrlList) {
		this.accessUrlList = accessUrlList;
	}

	/**
	 * @return the credentialDataObj
	 */
	public Map<String, Object> getCredentialDataObj() {
		return credentialDataObj;
	}

	/**
	 * @param credentialDataObj the credentialDataObj to set
	 */
	public void setCredentialDataObj(Map<String, Object> credentialDataObj) {
		this.credentialDataObj = credentialDataObj;
	}
	
	/**

	 * @return the username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * @return the projectName
	 */
	public String getProjectName() {
		return projectName;
	}

	/**
	 * @param projectName the projectName to set
	 */
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	/**
	 * @return the executionId
	 */
	public String getExecutionId() {
		return executionId;
	}

	/**
	 * @param executionId the executionId to set
	 */
	public void setExecutionId(String executionId) {
		this.executionId = executionId;
	}
	
}
