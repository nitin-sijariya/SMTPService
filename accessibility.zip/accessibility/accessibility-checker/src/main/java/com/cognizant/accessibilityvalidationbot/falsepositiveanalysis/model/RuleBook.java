package com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.model;

import java.util.HashMap;
import java.util.Map;

import org.jetbrains.annotations.NotNull;
import org.springframework.data.annotation.Id;

/**
 * Rule Book POJO class 
 * @author 578086
 *
 */
public class RuleBook {

	/** The id. */
	@Id
	@NotNull
	private String _id;
	
	/** Rule book rules */
	private Map<String,Object> rule = new HashMap<String, Object>();

	/**
	 * @return the _id
	 */
	public String get_id() {
		return _id;
	}

	/**
	 * @param _id the _id to set
	 */
	public void set_id(String _id) {
		this._id = _id;
	}
	
	/**
	 * @return the rule
	 */
	public Map<String, Object> getRule() {
		return rule;
	}

	/**
	 * @param rule the rule to set
	 */
	public void setRule(Map<String, Object> rule) {
		this.rule = rule;
	}
}
