package com.cognizant.accessibilityvalidationbot.centralizedservice.service.serviceHelper;

import java.lang.reflect.Method;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.client.utils.HttpClientUtils;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Order;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cognizant.accessibilityvalidationbot.centralizedservice.Utils.Util;
import com.cognizant.accessibilityvalidationbot.centralizedservice.model.CategorizationVO;
import com.cognizant.accessibilityvalidationbot.centralizedservice.model.Configuration;
import com.cognizant.accessibilityvalidationbot.centralizedservice.model.Process;
import com.cognizant.accessibilityvalidationbot.centralizedservice.model.ServiceRequest;
import com.cognizant.accessibilityvalidationbot.centralizedservice.model.Status;
import com.cognizant.accessibilityvalidationbot.centralizedservice.repository.CategorizationReporitory;
import com.cognizant.accessibilityvalidationbot.centralizedservice.repository.ConfigurationRepository;
import com.cognizant.accessibilityvalidationbot.centralizedservice.repository.ServiceRequestRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Service Helper class for Categorization service
 * @author 578086
 *
 */
@Service
public class CentralizedServiceHelper {

	private static final Logger LOGGER = LoggerFactory.getLogger(CentralizedServiceHelper.class);
	
	/**
	 * Repository for configuration 
	 */
	@Autowired
	private ConfigurationRepository configurationRepository;
	
	/**
	 * Repository for categorization 
	 */
	@Autowired
	private CategorizationReporitory categorizationReporitory;
	
	/**
	 * Repository for service request
	 */
	@Autowired
	private ServiceRequestRepository serviceRequestRepository;
	
	/** False Positive Analysis Service Base URL*/
	@Value("${app.falsepositiveanalysis.base.url}")
	private String falsePositiveAnalysisServiceBaseURL;
	
	/** Content Validation Service URL */
	@Value("${app.process.validation.base.url}")
	private String processValidationServiceBaseURL;
	
	/** Non Interactive Validation Service Base URL */
	@Value("${app.noninteractive.validation.base.url}")
	private String nonInteractiveValidationServiceBaseURL;
	
	/** Interactive Validation Service Base URL */
	@Value("${app.interactive.validation.base.url}")
	private String interactiveValidationServiceBaseURL;
	
	/** Font Validation Service Base URL */
	@Value("${app.font.validation.base.url}")
	private String fontValidationServiceBaseURL;
	
	/** Update Service Request document */
	@Value("${app.update.servicerequest}")
	private String updateServiceRequestURL;
	
	/** Type of execution whether standalone or microservice*/
	@Value("${app.operation.mode}")
	private String modeOfOperation;

	/** Retail Validation Service Base URL */
	@Value("${app.retail.validation.base.url}")
	private String retailValidationServiceBaseURL;
	
	/** Font Validation Service Base URL */
	@Value("${app.spell.validation.base.url}")
	private String spellValidationServiceBaseURL;
	/**
	 * Method used to send the request to other MicroService
	 * @param url
	 * @param json
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public  String sendRequestToMicroService(String url, String json){
		
		String output = null;
		
		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
		
		SSLContextBuilder sslContextBuilder = new SSLContextBuilder();
		
		CloseableHttpClient httpClient = null;
		
		RestTemplate restTemplate;
		
		Map<String,Object> result;
		
		SSLConnectionSocketFactory sslConnectionSocketFactory;
		
		try {
			sslContextBuilder.loadTrustMaterial(null, new TrustStrategy() {
				@Override
				public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException {
					return true;
				}
			});
			
			sslConnectionSocketFactory = new SSLConnectionSocketFactory(sslContextBuilder.build());
			
			httpClient = HttpClients.custom().setSSLSocketFactory(sslConnectionSocketFactory).build();
			
			requestFactory.setHttpClient(httpClient);
			
			HttpHeaders headers = new HttpHeaders();
			
			headers.add("Content-Type", "application/json");
			
			restTemplate = new RestTemplate(requestFactory);
			
			HttpEntity<String> entity = new HttpEntity<String>(json, headers);
			
			result = restTemplate.postForObject(url, entity , Map.class, " ");

			if (result != null) {
				Map<String,Object> response = (Map<String, Object>) result.get("response");
				output =  response.get("param").toString(); 
			} 
			
		} catch (NoSuchAlgorithmException | KeyStoreException | KeyManagementException e) {
			// TODO Auto-generated catch block
			LOGGER.error("Error Occured while sending response to microservice. URL:" + url + ",request:" + json);
		}finally {
			try {
				requestFactory.destroy();
				HttpClientUtils.closeQuietly(httpClient);
			} catch (Exception e) {
				// TODO Auto-generated catch block
			}
		}
		
		
		return output;
	}
	
	
	/**
	 * Method used for creating new ServiceRequest
	 * @return
	 */
	public ServiceRequest createNewServiceRequect() {
		
		ServiceRequest serviceRequest = new ServiceRequest();
		
		serviceRequest.set_id(Util.generateMongoID());
		
		serviceRequest.setCreatedDate(Util.getDateWithTimeAsDate());
		
		serviceRequest.setStartTime(Util.getDateWithTimeAsDate());
		
		return serviceRequest;
	}
	
	public ServiceRequest getServiceRequestById(String id) {
		
		Optional<ServiceRequest> serviceRequestOptional = serviceRequestRepository.findById(id);
		
		if(!Util.isEmpty(serviceRequestOptional)) {
			return serviceRequestOptional.get();
		}
		
		return null;
	}
	
	/**
	 * Method used to fetch configuration document from database
	 * @return
	 */
	public Configuration fetchConfiguration(String configurationId) {
		return configurationRepository.findById(configurationId).get();
	}
	
	/**
	 * Insert categorization document 
	 * @param categorizationVO
	 */
	public void insertCategorizationDocument(CategorizationVO categorizationVO) {
		categorizationReporitory.save(categorizationVO);
	}
	
	/**
	 * Insert or update service request document 
	 * @param categorizationVO
	 */
	public void insertOrUpdateServiceRequestDocument(ServiceRequest serviceRequest) {
		serviceRequestRepository.save(serviceRequest);
	}
	
	/**
	 * Method used for creating new CategorizationVO
	 * @return
	 */
	public CategorizationVO createNewCategorizationVO() {
		
		CategorizationVO categorizationVO = new CategorizationVO();
		
		categorizationVO.set_id(Util.generateMongoID());
		
		categorizationVO.setCreatedDate(Util.getDateWithTimeAsDate());
		
		return categorizationVO;
	}
	
	
	/**
	 * Method to fetch the categorized data and send the necessary details with that to corresponding validation service.
	 * @param runIdentifier
	 * @param validationURL
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public String fetchAndSendCategorizationDataToValidation(String runIdentifier, Map<String,Object> categorizedDataMap) {
		
		ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());
		
		CategorizationVO categorizationVO = objectMapper.convertValue(categorizedDataMap.get("categorizationVO"), CategorizationVO.class);
		
		ServiceRequest serviceRequest = objectMapper.convertValue(categorizedDataMap.get("serviceRequest"), ServiceRequest.class);
		
		Map<String,Object> fontJsonResult= (Map<String, Object>) categorizedDataMap.get("FontJsonResult");
		
		List<String> validationsRequired = serviceRequest.getValidationsRequired();
		
		List<String> popupXpathList = serviceRequest.getPopupXpathList();
		
		List<String> accessUrlList = serviceRequest.getAccessUrlList();
		
		Map<String, Object> credentialDataMap = serviceRequest.getCredentialDataObj();

		JSONObject credentialDataObj = new JSONObject(credentialDataMap);
		
		List<String> branch1ValidationList = new ArrayList<String>(Arrays.asList("OverLap","Alignment","OverFlow","Case Sensitive"));
		
		List<String> validation1AvailableList = new ArrayList<String>();
		
		validation1AvailableList.addAll(validationsRequired);
		
		validation1AvailableList.retainAll(branch1ValidationList);
			
		if(validationsRequired.contains("Carousel") || validationsRequired.contains("Menu Hover")) {
			
			serviceRequest = invokeValidationBranch3(categorizationVO, validationsRequired, serviceRequest, runIdentifier, popupXpathList, accessUrlList, credentialDataObj);
			
		} 
		
		if(validationsRequired.contains("Font")) {
			
			serviceRequest = invokeFontValidation(fontJsonResult, validationsRequired, serviceRequest, runIdentifier);
			
		}
		
		if(validationsRequired.contains("Spell")) {
			
			serviceRequest = invokeSpellValidation(fontJsonResult, validationsRequired, serviceRequest, runIdentifier);
			
		} 
		
		if(validation1AvailableList.size() > 0) {
			
			serviceRequest = invokeValidationBranch1(categorizationVO, validationsRequired, serviceRequest, runIdentifier, popupXpathList, accessUrlList, credentialDataObj);
			
		}
		
		if(validationsRequired.contains("Retail")) {
			
			serviceRequest = invokeRetailValidation(categorizationVO, validationsRequired, serviceRequest, runIdentifier, popupXpathList, accessUrlList);
			
		} 		
		
		if(modeOfOperation.equals("MICROSERVICE")) {
			
			insertOrUpdateServiceRequestDocument(serviceRequest);
			
		} else {
			
			Map<String,Object> requestBodyMap = new HashMap<String, Object>();
			
			requestBodyMap.put("serviceRequest", serviceRequest);
			
			JSONObject requestBodyJson = new JSONObject(requestBodyMap);
			
			String requestBody = "{\"param\":"+ requestBodyJson.toString() +"}";
			
			sendRequestToMicroService(updateServiceRequestURL, requestBody);
		}
		
			
		
		return "validation started successfully";
	}
	
	/**
	 * Method to invoke Validation branch 1
	 * @param categorizationVO
	 * @param validationsRequired
	 * @param serviceRequest
	 * @param runIdentifier
	 * @param validationURL
	 * @param popupXpathList
	 * @return
	 */
	private ServiceRequest invokeValidationBranch1(CategorizationVO categorizationVO, List<String> validationsRequired, ServiceRequest serviceRequest, String runIdentifier, List<String> popupXpathList, List<String> accessUrlList, JSONObject credentialDataObj) {
		
		JSONObject validationBranch1 = new JSONObject();
		
		String validationsRequiredString = validationsRequired.stream().map( value -> String.valueOf(value)).collect(Collectors.joining(","));
		
		String popupXpathListString = popupXpathList.stream().map( value -> String.valueOf(value)).collect(Collectors.joining(","));
		
		String accessUrlListString = accessUrlList.stream().map( value -> String.valueOf(value)).collect(Collectors.joining(","));
		
		validationBranch1.put("singleCardDetailsMap", categorizationVO.getSingleCardDetailsMap());
		
		validationBranch1.put("repeatedSingleCardDetailsMap", categorizationVO.getRepeatedSingleCardDetailsMap());
		
		validationBranch1.put("repeatedCardDetailsMap", categorizationVO.getRepeatedCardDetailsMap());
		
		validationBranch1.put("horizontalMenuDetailsMap", categorizationVO.getHorizontalMenuDetailsMap());
		
		validationBranch1.put("verticalMenuDetailsMap", categorizationVO.getVerticalMenuDetailsMap());
		
		validationBranch1.put("repeatedSingleCardKeyDetailsMap", categorizationVO.getRepeatedSingleCardKeyDetailsMap());
		
		validationBranch1.put("validationsRequired", validationsRequiredString);
		
		validationBranch1.put("popupXpathList", popupXpathListString);
		
		validationBranch1.put("carouselDotsXpathDetails", categorizationVO.getCarouselDotsXpathDetails());
		
		validationBranch1.put("URL", serviceRequest.getPageURL());
		
		validationBranch1.put("browserName", serviceRequest.getBrowser());
		
		validationBranch1.put("deviceName", serviceRequest.getDeviceName());
		
		validationBranch1.put("accessUrlListString", accessUrlListString);
		
		if (!Util.isEmpty(credentialDataObj)) {

			validationBranch1.put("credentialDataObjString", credentialDataObj.toString());
		}	
		
		String validationUrl = nonInteractiveValidationServiceBaseURL + runIdentifier;
				
		String requestBody = "{\"param\":"+ validationBranch1.toString() +"}";
				
		String response = sendRequestToMicroService(validationUrl, requestBody);
		
		if(!response.toLowerCase().contains("success")) {
			
			serviceRequest.getStatusMap().put(Process.NONINTERACTIVEVALIDATION, Status.FAILED);
			
		}
		
		serviceRequest.getStatusMap().put(Process.NONINTERACTIVEVALIDATION, Status.STARTED);
		
		return serviceRequest;
		
	}
	
	/**
	 * Method to start validation branch 2
	 * @param serviceRequest
	 * @param runIdentifier
	 * @param validationURL
	 * @param validationsRequired
	 * @param popupXpathList
	 * @return
	 */
	public ServiceRequest invokeValidationForProcess(ServiceRequest serviceRequest, String runIdentifier, List<String> validationsRequired, List<String> popupXpathList, List<String> accessUrlList, JSONObject credentialDataObj) {
		
		JSONObject validationBranch2 = new JSONObject();
		
		String validationsRequiredString = validationsRequired.stream().map( value -> String.valueOf(value)).collect(Collectors.joining(","));
		
		String popupXpathListString = popupXpathList.stream().map( value -> String.valueOf(value)).collect(Collectors.joining(","));
		
		String accessUrlListString = accessUrlList.stream().map( value -> String.valueOf(value)).collect(Collectors.joining(","));
		
		validationBranch2.put("URL", serviceRequest.getPageURL());
		
		validationBranch2.put("browserName", serviceRequest.getBrowser());
		
		validationBranch2.put("deviceName", serviceRequest.getDeviceName());
		
		validationBranch2.put("validationsRequired", validationsRequiredString);
		
		validationBranch2.put("popupXpathList", popupXpathListString);
		
		validationBranch2.put("accessUrlListString", accessUrlListString);
		
		if (!Util.isEmpty(credentialDataObj)) {

			validationBranch2.put("credentialDataObjString", credentialDataObj.toString());
		}
		
		String validationUrl = processValidationServiceBaseURL + runIdentifier;
		
		String requestBody = "{\"param\":"+ validationBranch2.toString() +"}";
		
		String response = sendRequestToMicroService(validationUrl, requestBody);
		
		if(!response.toLowerCase().contains("success")) {
			
			serviceRequest.getStatusMap().put(Process.ACCESSIBILITY, Status.FAILED);
			
		}
		else {
			
			serviceRequest.getStatusMap().put(Process.ACCESSIBILITY, Status.STARTED);
			
		}
		
		return serviceRequest;
		
	}
	
	/**
	 * Method to invoke Validation branch 3
	 * @param categorizationVO
	 * @param validationsRequired
	 * @param serviceRequest
	 * @param runIdentifier
	 * @param validationURL
	 * @param popupXpathList
	 * @return
	 */
	private ServiceRequest invokeValidationBranch3(CategorizationVO categorizationVO, List<String> validationsRequired, ServiceRequest serviceRequest, String runIdentifier, List<String> popupXpathList, List<String> accessUrlList, JSONObject credentialDataObj) {
		
		JSONObject validationBranch3 = new JSONObject();
		
		String validationsRequiredString = validationsRequired.stream().map( value -> String.valueOf(value)).collect(Collectors.joining(","));
		
		String popupXpathListString = popupXpathList.stream().map( value -> String.valueOf(value)).collect(Collectors.joining(","));
		
		String accessUrlListString = accessUrlList.stream().map( value -> String.valueOf(value)).collect(Collectors.joining(","));
		
		validationBranch3.put("carouselDetailsMap", categorizationVO.getCarouselDetailsMap());
		
		validationBranch3.put("carouselPreviousNextDotDetailsMap", categorizationVO.getCarouselPreviousNextDotDetailsMap());
		
		validationBranch3.put("hoverableMenuChildXpathDetailsMap",categorizationVO.getHoverableMenuChildXpathDetailsMap());
		
		validationBranch3.put("validationsRequired", validationsRequiredString);
		
		validationBranch3.put("popupXpathList", popupXpathListString);
		
		validationBranch3.put("URL", serviceRequest.getPageURL());
		
		validationBranch3.put("browserName", serviceRequest.getBrowser());
		
		validationBranch3.put("deviceName", serviceRequest.getDeviceName());
		
		validationBranch3.put("accessUrlListString", accessUrlListString);
		
		if (!Util.isEmpty(credentialDataObj)) {

			validationBranch3.put("credentialDataObjString", credentialDataObj.toString());
		}
		
		String validationUrl = interactiveValidationServiceBaseURL + runIdentifier;
				
		String requestBody = "{\"param\":"+ validationBranch3.toString() +"}";
				
		String response = sendRequestToMicroService(validationUrl, requestBody);
		
		if(!response.toLowerCase().contains("success")) {
			
			serviceRequest.getStatusMap().put(Process.INTERACTIVEVALIDATION, Status.FAILED);
			
		}
		
		serviceRequest.getStatusMap().put(Process.INTERACTIVEVALIDATION, Status.STARTED);
		
		return serviceRequest;
		
	}
	
	/**
	 * Method to add entry to temporary map in False positive service for rule book entry
	 * @param runIdentifier
	 * @param routerDetailsMap
	 * @param url
	 * @return
	 */
	public String addEntryForReportInFalsePositiveAnalysisService(String runIdentifier, String url) {
		
		String falsePositiveAnalysisURL = falsePositiveAnalysisServiceBaseURL + "temporaryObjectMap/add/" + runIdentifier;
		
		String requestBody = "{\"param\":{\"url\":\""+ url +"\"}}";
		
		String response = sendRequestToMicroService(falsePositiveAnalysisURL, requestBody);
		
		return response;
		
	}
	
	/**
	 * Method to get all service request document from data base in descending order
	 * @return
	 */
	public List<ServiceRequest> fetchAllServiceRequest(){
		
		return serviceRequestRepository.findAll(Sort.by(new Order(Sort.Direction.DESC, "createdDate")));
		
	}
	
	/**
	 * Invoke the given method dynamically inside new Thread
	 * @param method
	 * @param classInstance
	 * @param numberOfParameters
	 * @param parameter
	 */
	public void invokeMethodInsideThread(Method method, Object classInstance, int numberOfParameters, List<Object> parameter) {
		
		Thread thread = null;
		
		try {
			thread = new Thread(new Runnable() {

				@Override
				public void run() {
					try {
						
						switch (numberOfParameters) {
						case 1:
							method.invoke(classInstance, parameter.get(0));
							break;
						case 2:
							method.invoke(classInstance, parameter.get(0), parameter.get(1));
							break;
						case 3:
							method.invoke(classInstance, parameter.get(0), parameter.get(1), parameter.get(2));
							break;
						case 4:
							method.invoke(classInstance, parameter.get(0), parameter.get(1), parameter.get(2), parameter.get(3));
							break;
						case 5:
							method.invoke(classInstance, parameter.get(0), parameter.get(1), parameter.get(2), parameter.get(3), parameter.get(4));
							break;
						case 6:
							method.invoke(classInstance, parameter.get(0), parameter.get(1), parameter.get(2), parameter.get(3), parameter.get(4), parameter.get(5));
							break;
						case 7:
							method.invoke(classInstance, parameter.get(0), parameter.get(1), parameter.get(2), parameter.get(3), parameter.get(4), parameter.get(5), parameter.get(6));
							break;
						case 8:
							method.invoke(classInstance, parameter.get(0), parameter.get(1), parameter.get(2), parameter.get(3), parameter.get(4), parameter.get(5), parameter.get(6), parameter.get(7));
							break;
						default:
							break;
						}
						
					} catch (Exception e) {
						
						e.printStackTrace();
						
						LOGGER.error("Error Occured while invoking the method:" + method.getName() + "with " +  numberOfParameters + " parameters");
					}
					
				}
			});

			thread.start();
			
		} finally {
			
			
		}
	}
	
	/**
	 * Method to finalize whether the execution is completed or not
	 * @param serviceRequest
	 * @return
	 */
	public boolean checkForEndTimeUpdateStatus(ServiceRequest serviceRequest) {
		
		int totalStatusMapEntry = serviceRequest.getStatusMap().size();
		
		int completedStatusCount = 0;
		
		for(Process process : serviceRequest.getStatusMap().keySet()) {
			
			if(serviceRequest.getStatusMap().get(process).equals(Status.COMPLETED)) {
				
				completedStatusCount ++;
				
			}
		};
		
		if(completedStatusCount == totalStatusMapEntry) {
			
			return true;
			
		}
		
		return false;
	}
	
	/**
	 * Method to invoke Font Validation
	 * @param fontJsonResult
	 * @param validationsRequired
	 * @param serviceRequest
	 * @param runIdentifier
	 * @return
	 */
	private ServiceRequest invokeFontValidation(Map<String,Object> fontJsonResult, List<String> validationsRequired, ServiceRequest serviceRequest, String runIdentifier) {
		
		JSONObject fontValidation = new JSONObject();
		
		fontValidation.put("fontJsonResult",fontJsonResult);
		
		fontValidation.put("URL", serviceRequest.getPageURL());
		
		String validationUrl = fontValidationServiceBaseURL + runIdentifier;
				
		String requestBody = "{\"param\":"+ fontValidation.toString() +"}";
		
		String response = sendRequestToMicroService(validationUrl, requestBody);
		
		if(!response.toLowerCase().contains("success")) {
			
			serviceRequest.getStatusMap().put(Process.FONTVALIDATION, Status.FAILED);
			
		}
		else {
		
			serviceRequest.getStatusMap().put(Process.FONTVALIDATION, Status.STARTED);
		
		}
		
		return serviceRequest;
		
	}
	
	/**
	 * Method to invoke Retail Validation 
	 * @param categorizationVO
	 * @param validationsRequired
	 * @param serviceRequest
	 * @param runIdentifier
	 * @param validationURL
	 * @param popupXpathList
	 * @return
	 */
	private ServiceRequest invokeRetailValidation(CategorizationVO categorizationVO, List<String> validationsRequired, ServiceRequest serviceRequest, String runIdentifier, List<String> popupXpathList, List<String> accessUrlList) {
		
		JSONObject validationRetail = new JSONObject();
		
		String validationsRequiredString = validationsRequired.stream().map( value -> String.valueOf(value)).collect(Collectors.joining(","));
		
		String popupXpathListString = popupXpathList.stream().map( value -> String.valueOf(value)).collect(Collectors.joining(","));
		
		String accessUrlListString = accessUrlList.stream().map( value -> String.valueOf(value)).collect(Collectors.joining(","));
		
		validationRetail.put("singleCardDetailsMap", categorizationVO.getSingleCardDetailsMap());
		
		validationRetail.put("repeatedSingleCardDetailsMap", categorizationVO.getRepeatedSingleCardDetailsMap());
		
		validationRetail.put("repeatedCardDetailsMap", categorizationVO.getRepeatedCardDetailsMap());
		
		validationRetail.put("horizontalMenuDetailsMap", categorizationVO.getHorizontalMenuDetailsMap());
		
		validationRetail.put("verticalMenuDetailsMap", categorizationVO.getVerticalMenuDetailsMap());
		
		validationRetail.put("repeatedSingleCardKeyDetailsMap", categorizationVO.getRepeatedSingleCardKeyDetailsMap());
		
		validationRetail.put("validationsRequired", validationsRequiredString);
		
		validationRetail.put("popupXpathList", popupXpathListString);
		
		validationRetail.put("carouselDotsXpathDetails", categorizationVO.getCarouselDotsXpathDetails());						
		
		validationRetail.put("URL", serviceRequest.getPageURL());
		
		validationRetail.put("browserName", serviceRequest.getBrowser());
		
		validationRetail.put("deviceName", serviceRequest.getDeviceName());
		
		validationRetail.put("accessUrlListString", accessUrlListString);
		
		String validationUrl = retailValidationServiceBaseURL + runIdentifier;
				
		String requestBody = "{\"param\":"+ validationRetail.toString() +"}";
				
		String response = sendRequestToMicroService(validationUrl, requestBody);
		
		if(!response.toLowerCase().contains("success")) {
			
			serviceRequest.getStatusMap().put(Process.RETAILVALIDATION, Status.FAILED);
			
		}
		
		serviceRequest.getStatusMap().put(Process.RETAILVALIDATION, Status.STARTED);
		
		return serviceRequest;
		
	}
	
	
	/**
	 * Method to invoke Font Validation
	 * @param fontJsonResult
	 * @param validationsRequired
	 * @param serviceRequest
	 * @param runIdentifier
	 * @return
	 */
	private ServiceRequest invokeSpellValidation(Map<String,Object> fontJsonResult, List<String> validationsRequired, ServiceRequest serviceRequest, String runIdentifier) {
		
		JSONObject spellValidation = new JSONObject();
		
		spellValidation.put("fontJsonResult",fontJsonResult);
		
		spellValidation.put("URL", serviceRequest.getPageURL());
		
		String validationUrl = spellValidationServiceBaseURL + runIdentifier;
				
		String requestBody = "{\"param\":"+ spellValidation.toString() +"}";
		
		String response = sendRequestToMicroService(validationUrl, requestBody);
		
		if(!response.toLowerCase().contains("success")) {
			
			serviceRequest.getStatusMap().put(Process.SPELLVALIDATION, Status.FAILED);
			
		}
		else {
		
			serviceRequest.getStatusMap().put(Process.SPELLVALIDATION, Status.STARTED);
		
		}
		
		return serviceRequest;
		
	}

}
