package com.cognizant.accessibilityvalidationbot.centralizedservice.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.jetbrains.annotations.NotNull;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * Configuration POJO class is used to store the tool configuration from database
 * @author 578086
 *
 */

@Document(collection="configuration")
public class Configuration implements Serializable{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The id. */
	@Id
	@NotNull
	private String _id;
	
	/**
	 * Configuration Map
	 */
	private Map<String,Object> configuration = new HashMap<String, Object>();

	/** map used for doing routing **/
	private Map<String,Object> microServiceRouterDetailsMap = new HashMap<String, Object>();
	
	/**
	 * @return the _id
	 */
	public String get_id() {
		return _id;
	}

	/**
	 * @param _id the _id to set
	 */
	public void set_id(String _id) {
		this._id = _id;
	}

	/**
	 * @return the configuration
	 */
	public Map<String, Object> getConfiguration() {
		return configuration;
	}

	/**
	 * @param configuration the configuration to set
	 */
	public void setConfiguration(Map<String, Object> configuration) {
		this.configuration = configuration;
	}

	/**
	 * @return the microServiceRouterDetailsMap
	 */
	public Map<String, Object> getMicroServiceRouterDetailsMap() {
		return microServiceRouterDetailsMap;
	}

	/**
	 * @param microServiceRouterDetailsMap the microServiceRouterDetailsMap to set
	 */
	public void setMicroServiceRouterDetailsMap(Map<String, Object> microServiceRouterDetailsMap) {
		this.microServiceRouterDetailsMap = microServiceRouterDetailsMap;
	}
	
}
