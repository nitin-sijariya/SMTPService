package com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.model;

import java.io.Serializable;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="generalrulebook")
public class GeneralRuleBook extends RuleBook  implements Serializable{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	
}
