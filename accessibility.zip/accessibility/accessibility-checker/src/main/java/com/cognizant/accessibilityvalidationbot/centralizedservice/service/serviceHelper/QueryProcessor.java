package com.cognizant.accessibilityvalidationbot.centralizedservice.service.serviceHelper;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Order;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import com.cognizant.accessibilityvalidationbot.centralizedservice.model.ServiceRequest;
import com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.model.Report;

/**
 * Service class for custom queries
 * @author 578086
 *
 */
@Service
public class QueryProcessor {

	/** Mongo template instance for customized query execution*/
	@Autowired
	private MongoTemplate mongoTemplate;
	
	/**
	 * Get report by run identifier and url
	 * @param runIdentifier
	 * @param url
	 * @return
	 */
	public Report getReportByRunIdentifierAndUrl(String runIdentifier, String url) {
		
		Query query = new Query();
		
		query.addCriteria(Criteria.where("runIdentifier").is(runIdentifier));
		
		query.addCriteria(Criteria.where("pageURL").is(url));
		
		return mongoTemplate.findOne(query, Report.class);
	}
	
	/**
	 * Get report by run identifier and project Name
	 * @param runIdentifier
	 * @param url
	 * @return
	 */
	public List<ServiceRequest> fetchServiceRequestByUserData(JSONObject userDataObj) {
		
		Query query = new Query();
		Criteria criteria = new Criteria();
		
		List<Criteria> andCriteria = new ArrayList<>();
		
		andCriteria.add(Criteria.where("projectName").is(userDataObj.get("projectName")));
		
		andCriteria.add(Criteria.where("executionId").is(userDataObj.get("executionId")));
		
		criteria.andOperator(andCriteria.toArray(new Criteria[andCriteria.size()]));
		
		query.addCriteria(criteria);
		
		query.with(Sort.by(new Order(Sort.Direction.DESC, "createdDate")));
		
		return mongoTemplate.find(query, ServiceRequest.class);
	}
	
	
}
