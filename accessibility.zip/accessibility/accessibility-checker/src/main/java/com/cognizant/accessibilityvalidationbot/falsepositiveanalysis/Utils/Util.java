package com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.Utils;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Map;
import java.util.UUID;



/**
 * Class to encapsulate utility functions of the framework
 * 
 * @author Cognizant
 */
public class Util {
	public static String appUrl;
	
	private Util() {
		// To prevent external instantiation of this class
	}

	/**
	 * Function to get the separator string to be used for directories and files
	 * based on the current OS
	 * 
	 * @return The file separator string
	 */
	public static String getFileSeparator() {
		return System.getProperty("file.separator");
	}

	/**
	 * Function to get the Absolute Path
	 * 
	 * @return The AbsolutePath in String
	 */
	public static String getAbsolutePath() throws IOException {
		String userDIR = new File(System.getProperty("user.dir")).getCanonicalPath();
		String relativePath = new File(userDIR).getAbsolutePath();
		return relativePath;
	}

	/**
	 * Function to get the Resource Excel Path
	 * 
	 * @return The excelPath in String
	 * @throws IOException 
	 */
	public static String getExcelPath() throws IOException {

		File targetPath = new File(Util.getAbsolutePath() + Util.getFileSeparator() + "src" + Util.getFileSeparator()
		+ "test" + Util.getFileSeparator() + "resources");

		return targetPath.toString();
	}

	/**
	 * Function to get the Result Path
	 * 
	 * @return The ResultPath in String
	 * @throws IOException 
	 */
	public static String getResultsPath() throws IOException {
		File path = new File(Util.getAbsolutePath() + Util.getFileSeparator() + "Results");
		if (!path.isDirectory()) {
			path.mkdirs();
		}

		return path.toString();
	}

	/**
	 * Function to get the Target Path
	 * 
	 * @return The TargetPath in String
	 * @throws IOException 
	 */
	public static String getTargetPath() throws IOException {

		File targetPath = new File(Util.getAbsolutePath() + Util.getFileSeparator() + "target");

		return targetPath.toString();
	}

	/**
	 * Function to get the Resource Path
	 * 
	 * @return The Resource in String
	 * @throws IOException 
	 */
	public static String getResourcePath() throws IOException {

		File resourcePath = new File(Util.getAbsolutePath() + Util.getFileSeparator() + "src" + getFileSeparator()
		+ "main" + getFileSeparator() + "resources");

		return resourcePath.toString();
	}

	/**
	 * Function to return the current time
	 * 
	 * @return The current time
	 * @see #getCurrentFormattedTime(String)
	 */
	public static Date getCurrentTime() {
		Calendar calendar = Calendar.getInstance();
		return calendar.getTime();
	}

	/**
	 * Function to return the current time, formatted as per the DateFormatString
	 * setting
	 * 
	 * @param dateFormatString The date format string to be applied
	 * @return The current time, formatted as per the date format string specified
	 * @see #getCurrentTime()
	 * @see #getFormattedTime(Date, String)
	 */
	public static String getCurrentFormattedTime(String dateFormatString) {
		DateFormat dateFormat = new SimpleDateFormat(dateFormatString);
		Calendar calendar = Calendar.getInstance();
		return dateFormat.format(calendar.getTime());
	}

	/**
	 * Function to format the given time variable as specified by the
	 * DateFormatString setting
	 * 
	 * @param time             The date/time variable to be formatted
	 * @param dateFormatString The date format string to be applied
	 * @return The specified date/time, formatted as per the date format string
	 *         specified
	 * @see #getCurrentFormattedTime(String)
	 */
	public static String getFormattedTime(Date time, String dateFormatString) {
		DateFormat dateFormat = new SimpleDateFormat(dateFormatString);
		return dateFormat.format(time);
	}

	/**
	 * Function to get the time difference between 2 {@link Date} variables in
	 * minutes/seconds format
	 * 
	 * @param startTime The start time
	 * @param endTime   The end time
	 * @return The time difference in terms of hours, minutes and seconds
	 */
	public static String getTimeDifference(Date startTime, Date endTime) {
		long timeDifferenceSeconds = (endTime.getTime() - startTime.getTime()) / 1000; // to
		// convert
		// from
		// milliseconds
		// to
		// seconds
		long timeDifferenceMinutes = timeDifferenceSeconds / 60;

		String timeDifferenceDetailed;
		if (timeDifferenceMinutes >= 60) {
			long timeDifferenceHours = timeDifferenceMinutes / 60;

			timeDifferenceDetailed = Long.toString(timeDifferenceHours) + " hour(s), "
					+ Long.toString(timeDifferenceMinutes % 60) + " minute(s), "
					+ Long.toString(timeDifferenceSeconds % 60) + " second(s)";
		} else {
			timeDifferenceDetailed = Long.toString(timeDifferenceMinutes) + " minute(s), "
					+ Long.toString(timeDifferenceSeconds % 60) + " second(s)";
		}

		return timeDifferenceDetailed;
	}



	
	/**
	 * Generate mongo ID.
	 *
	 * @return the string
	 */
	public static String generateMongoID()
	{
		String _id = UUID.randomUUID().toString();
		return _id;
	}


	/**
	 * Generate date.
	 *
	 * @return the string
	 */
	public static String generateDateWithoutTime()
	{
		String date = generateDateWithTimeAsString();
		date = date.substring(0,10).trim();
		return date;
	}


	/**
	 * Generate date with time as string.
	 *
	 * @return the string
	 */
	public static String generateDateWithTimeAsString() 
	{
		SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy hh:mm a");
		return sdf.format(new Date());	
	}
	
	/**
	 * Gets the date with time as date.
	 *
	 * @return the date with time as date
	 * @throws DcrowdException the dcrowd exception
	 */
	public static Date getDateWithTimeAsDate() {
		return new Date();
	}
	
	/**
	 * Returns true if the given value is null or is empty.
	 *
	 * @param value the value
	 * @return true, if is empty
	 */

	public static boolean isEmpty(Object value) {
		if (value == null) {
			return true;
		} else if (value instanceof String) {
			if(((String) value).trim().equals("''")) {
				return true;
			}
			return ((String) value).trim().length() == 0;
		} else if (value instanceof Object[]) {
			return ((Object[]) value).length == 0;
		} else if (value instanceof Collection<?>) {
			return ((Collection<?>) value).size() == 0;
		} else if (value instanceof Map<?, ?>) {
			return ((Map<?, ?>) value).size() == 0;
		} else {
			return value.toString() == null
					|| value.toString().trim().length() == 0;
		}
	}
}
