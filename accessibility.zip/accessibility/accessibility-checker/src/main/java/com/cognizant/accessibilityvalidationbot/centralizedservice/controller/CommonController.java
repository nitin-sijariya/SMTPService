package com.cognizant.accessibilityvalidationbot.centralizedservice.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.accessibilityvalidationbot.centralizedservice.model.Response;



// TODO: Auto-generated Javadoc
/**
 * The Class CommonController.
 */
@RestController("CentralizedService")
public class CommonController {


	/** The response. */
	Map <String,Response> response ;

	/**
	 * Builds the success response.
	 *
	 * @param param the param
	 * @return the response entity
	 */
	public ResponseEntity<?> buildSuccessResponse(Object param)
	{
		response = new HashMap<>();
		response.put("response", new Response("true", param));
		return ResponseEntity.ok(response);
	}

	/**
	 * Builds the failure response.
	 *
	 * @param errorCode the error code
	 * @param errorMsg the error msg
	 * @return the response entity
	 */
	public ResponseEntity<?> buildFailureResponse( int errorCode, String errorMsg)
	{
		response = new HashMap<>();
		response.put("CrowdResponse", new Response("false",String.valueOf(errorCode), errorMsg));
		return ResponseEntity.status(errorCode).body(response);

	}

}
