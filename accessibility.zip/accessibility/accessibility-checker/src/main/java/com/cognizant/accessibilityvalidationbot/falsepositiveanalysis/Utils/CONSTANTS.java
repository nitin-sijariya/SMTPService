package com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.Utils;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Constant class file for getting values
 * @author 578086
 *
 */
public class CONSTANTS {

public static List<String> ignoreClassNames = Stream.of("row", "container").collect(Collectors.toList());
	
	public static final String OVERLAP = "overlap";
	
	public static final String CASESENSITIVE = "casesensitive";
	
	public static final String ISFALSEPOSITIVE = "isFalsePositive";
	
	public static final String ISUSERREMOVED = "isUserRemoved";

	public static final String TEXT = "Text";
	
	public static final String CASE = "CaseType";
	
	public static final String LABELS = "labels";
	
	public static final String IGNOREALL = "IgnoreAll";
	
	public static final String IGNORE = "Ignore";

	public static final String TEXTONIMAGE = "text on img";
	
	public static final String TEXTONTEXT = "text on text";
	
	public static final String TEXTONICON = "text on icon";
	
	public static final String IMAGEONTEXT = "img on text";	
	
	public static final String ICONONTEXT = "icon on text";

	public static final String ELEMENTCATEGORY = "ElementCategory";
	
	public static final String EMPTYSTRINGWITHSPACE = " ";
	
	public static final String EMPTYSTRING = "";
	
	public static final String BROKENLINK = "linknotworking";
	
	public static final String CONFIGBROKENLINK = "linkNotWorking";
	
	public static final String BROKENLINK_FIELD = "URL";
	
	public static final String OVERFLOW = "overflow";
	
	public static final String POSITION_ALIGNMENTL = "position alignment error";
	
	public static final String HORIZONTALMENU_ALIGNMENT = "horizontalmenu";
	
	public static final String VERTICALMENU_ALIGNMENT = "verticalmenu";
	
	public static final String POSITION_ALIGNMENT_HORIZONTAL = "positionAlignmentHorizontal";
	
	public static final String POSITION_ALIGNMENT_VERTICAL = "positionAlignmentVertical";
	
	public static final String IMAGENOTLOADED = "image-notloaded";
	
	public static final String CONFIGIMAGENOTLOADED = "imageNotLoaded";
	
	public static final String  IMAGELOWQUALITY= "lowquality";	
	
	public static final String  CONFIGIMAGELOWQUALITY= "imageLowQuality";	
	
	public static final String IMAGEASPECTRATIO = "aspectratio";
	
	public static final String  CONFIGIMAGEASPECTRATIO= "imageAspectRatio";
	
	public static final String  IMAGEBROKENLINK= "image-brokenlink";
	
	public static final String  CONFIGIMAGEBROKENLINK= "imageBrokenLink";
	
	public static final String  CONFIGVIDEO= "video";
	
	public static final String  VIDEO= "videoplayissue";
	
	public static final String  CONFIGCAROUSEL= "carousel";
	
	public static final String  CAROUSEL= "carouselissue";
	
	public static final String  CONFIGMENUHOVER= "menuHovering";
	
	public static final String  MENUHOVER= "interactivemenu";
	
	public static final String  CONFIGPATTERNDIFF= "patternDifference";
	
	public static final String  PATTERNDIFF= "sizedifference";
	
	public static final String LESSWIDTHANDHEIGHTTOCROP = "WIDTHANDHEIGHISLESSTHANTOLERANCERANGE";
	
	public static final String PNG_EXTENSION = ".png"; 
	
	public static final String  SPELLCHECKER= "spellError";
	
	public static final String  CONFIGSPELLCHECKER= "spellValidation";
	
	public static final String  FONTVALIDATION= "FontValidation";
	
	public static final String  CONFIGFONTVALIDATION = "FontValidation";
}
