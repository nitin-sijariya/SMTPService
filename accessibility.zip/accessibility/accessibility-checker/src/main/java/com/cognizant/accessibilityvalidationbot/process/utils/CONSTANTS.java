package com.cognizant.accessibilityvalidationbot.process.utils;

public class CONSTANTS {

	public static final String BROKEN_LINK = "Broken Link";
	
	public static final String IMAGE_VALIDATION = "Image Validation";
	
	public static final String VIDEO_VALIDATION = "Video";
	
	public static final String DOWNLOAD_VALIDATION = "Download";
	
	public static final String SYSTEM_TEMP_PATH = "java.io.tmpdir";
	
	public static final String DOWNLOAD_URL_KEY = "href";
	
	public static final String DOWNLOAD_VERIFICATION_KEY = "isDownloaded";
	
	public static final String PYTHON_ENV_PRIMARY_KEY = "python";
	
	public static final String PYTHON_ENV_SECONDARY_KEY = "scripts";
	
	public static final String PYTHON_EXECUTABLE = "python";
	
	public static final String LINK_CHECKER_EXECUTABLE = "linkchecker";
	
	public static final String LINK_CHECKER_LINK_KEY = "realUrl";
	
	public static final String LINK_CHECKER_STATUS_KEY = "status";
	
	public static final String LINK_CHECKER_LINK_DETAIL_SEPERATOR = ";";
	
	public static final String COMMA_SEPERATOR = ",";
	
	public static final String IMAGE_DIFFERENCE_PY_FILE = "imageDifference.pyc";
	
	public static final String IMAGE_DIFFERENCE_DEFAULT_STATUS_CODE = "0";
	
	public static final String ACCESSIBILITY = "Accessibility";
	
	public static final String  BORDER_NONE = "arguments[0].style.border = 'none';";
	
	public static final String WINDOWSCROLL = "window.scrollTo(0,0)";
	
	public static final String BASE64SCREENSHOT = "base64Screenshot"; 
	
	public static final String PNG_EXTENSION = ".png"; 
	
	public static final String ERRORCAPTION = "ErrorCaption";
	
}
