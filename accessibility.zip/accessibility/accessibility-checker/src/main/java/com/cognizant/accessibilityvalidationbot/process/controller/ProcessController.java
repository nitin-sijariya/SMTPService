package com.cognizant.accessibilityvalidationbot.process.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.accessibilityvalidationbot.process.model.Request;
import com.cognizant.accessibilityvalidationbot.process.service.ProcessService;
import com.cognizant.accessibilityvalidationbot.process.utils.Util;


@RestController
@RequestMapping(value = "/api/v1/accessibility",
consumes = MediaType.APPLICATION_JSON_VALUE,
produces = MediaType.APPLICATION_JSON_VALUE)
public class ProcessController extends CommonController{

	
	private static final Logger LOGGER = LoggerFactory.getLogger(ProcessController.class);
		
	@Autowired
	private ProcessService processService;
	
	/**
	 * API for starting process validation
	 * @param categorizedData
	 * @param runIdentifier
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST,value="processValidationService/{runIdentifier}")
	public ResponseEntity<?> startProcessValidation(@RequestBody Request categorizedData, @PathVariable("runIdentifier") String runIdentifier){
		
		Map<String,Object> param = categorizedData.getParam();
		
		String URL = (String) param.get("URL");
		
		String browserName = (String) param.get("browserName");
		
		String deviceName = (String) param.get("deviceName");
		
		String credentialDataObj = null;

		JSONObject credentialDataJsonObj = null;
		
		Map<String, Object> credentialDataMap = null;

		if (param.containsKey("credentialDataObjString")) {

			credentialDataObj = (String) param.get("credentialDataObjString");

			credentialDataJsonObj = new JSONObject(credentialDataObj);
			
			credentialDataMap = credentialDataJsonObj.toMap();

		}

		
		List<String> validationsRequired = Arrays.asList(param.get("validationsRequired").toString().split(","));
		
		List<String> popupXpathList = new ArrayList<String>();
		
		List<String> accessUrlList = new ArrayList<String>();
		
		if(!Util.isEmpty(param.get("popupXpathList"))) {
			
			popupXpathList = Arrays.asList(param.get("popupXpathList").toString().split(","));
			
		}
		
		if(!Util.isEmpty(param.get("accessUrlListString"))) {
			
			accessUrlList = Arrays.asList(param.get("accessUrlListString").toString().split(","));
			
		}
		
		LOGGER.info("Process validation process triggered with following parameter. URL:" + URL + ", Browser:" + browserName + ", DeviceName:" + deviceName + ", RunIdentifier:" + runIdentifier);
		
		try {
			
			return buildSuccessResponse(processService.initiateProcessValidation(runIdentifier, URL, browserName, deviceName, popupXpathList, validationsRequired, accessUrlList, credentialDataMap));
			
		} catch (NoSuchMethodException | SecurityException e) {
			
			LOGGER.error("Process validation process failed with following parameter. URL:" + URL + ", Browser:" + browserName + ", DeviceName:" + deviceName + ", RunIdentifier:" + runIdentifier + ". Error Message :"+ e.getMessage());
			
			return buildFailureResponse(500, e.getMessage());
		}
		
	}
	
}
