package com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.configuration;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.model.Report;


@Configuration
public class FalsePositiveAnalysisConfiguration {

	/**
	 * Map for maintaining all temporary objects
	 * @return
	 */
	@Bean
	public Map<String,Object> temporaryObjectMap(){
		return new HashMap<String, Object>();
	}
	
	/**
	 * Temporary Map to store report object
	 * @return
	 */
	@Bean
	public Map<String,Report> temporaryReportObjectMap(){
		return new HashMap<String, Report>();
	}
}
