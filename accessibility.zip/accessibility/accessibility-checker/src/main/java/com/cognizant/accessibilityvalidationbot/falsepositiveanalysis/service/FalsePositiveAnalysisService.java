package com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cognizant.accessibilityvalidationbot.centralizedservice.model.ServiceRequest;
import com.cognizant.accessibilityvalidationbot.centralizedservice.service.serviceHelper.CentralizedServiceHelper;
import com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.Utils.CONSTANTS;
import com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.Utils.Util;
import com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.model.Report;
import com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.service.serviceHelper.FalsePositiveAnalysisServiceHelper;

/**
 * Service class for false positive analysis
 * @author 578086
 *
 */
@Service
public class FalsePositiveAnalysisService {
	
	/**
	 * Helper class for this service
	 */
	@Autowired
	private CentralizedServiceHelper centralizedServiceHelper;
	
	/** false positive service helper class */
	@Autowired
	private FalsePositiveAnalysisServiceHelper falsePositiveAnalysisServiceHelper;
	
	/** URL to update the status of validation in centralized service */
	@Value("${app.update.status.centralized.service.url}")
	private String checkAndUpdateStatusInCentralizedServiceURL;
	
	/** Splitter for validation category name from issue id*/
	@Value("${app.report.validation.categoryname.splitter}")
	private String validationCategoryNameSplitter;

	/**
	 * Method used for analyzing the false positive on validation result.
	 * @param runIdentifier
	 * @param validationResult
	 * @param category
	 * @param url
	 * @throws IOException 
	 */
	@SuppressWarnings("unchecked")
	public void analyzeAndSendResponseToCentralizedService(String runIdentifier, JSONObject validationResult, String branch, String url, int bodyWidth, int bodyHeight, String base64ScreenShot,String pageTitle) throws IOException {
			
			Report report = falsePositiveAnalysisServiceHelper.fetchOrCreateReportObjectFromTemporaryReportMap(url, runIdentifier);
			
			boolean addReportToDB = false;
			JSONObject issuesCountObj = null;
		
		if(!Util.isEmpty(base64ScreenShot)) {
			
			falsePositiveAnalysisServiceHelper.saveBase64ScreenShot(base64ScreenShot, runIdentifier);
			
			addReportToDB= true;
			
		}
		
		ServiceRequest serviceRequest = centralizedServiceHelper.getServiceRequestById(runIdentifier);
		
		serviceRequest.setPageTitle(pageTitle);
		
		centralizedServiceHelper.insertOrUpdateServiceRequestDocument(serviceRequest);
		
		Map<String, Object> reportMap = new HashMap<String, Object>();
		
		Map<String, Object> reportMetaDataMap = new HashMap<String, Object>();
		
		if(!Util.isEmpty(validationResult)) {
			
			JSONObject validationReportObj = validationResult.getJSONObject("issues");
				
			issuesCountObj = (JSONObject) validationResult.get("issuesCount");
				
			for(String key: validationReportObj.keySet()) {
				
				JSONArray validationReportArray = validationReportObj.getJSONArray(key);
				
				for (int i = 0; i < validationReportArray.length(); i++) {
					
					try {
						
						JSONObject validationJsonObj = validationReportArray.getJSONObject(i);
						
						validationJsonObj.put("ErrorCaption", key);
						
						if(!validationJsonObj.has(CONSTANTS.ISFALSEPOSITIVE)) {
							validationJsonObj.put(CONSTANTS.ISFALSEPOSITIVE, false);
						}
						
						if(!validationJsonObj.has(CONSTANTS.ISUSERREMOVED)) {
							validationJsonObj.put(CONSTANTS.ISUSERREMOVED, false);
						}
						
						if(validationJsonObj.has("ErrorCaption")) {							
														
							String errorCaption = validationJsonObj.getString("ErrorCaption");
							
							String issueId = "";
							
							
							issueId = errorCaption.replaceAll("\\s+","") + validationCategoryNameSplitter + "issues" + validationCategoryNameSplitter + i;
						
														
							validationJsonObj = falsePositiveAnalysisServiceHelper.initiateFalsePositiveAnalysis(validationJsonObj, errorCaption , url, runIdentifier);

							
							reportMap.put(issueId, validationJsonObj.toMap());
							
							String errorCaptionWithoutSpace = errorCaption.replaceAll("\\s+","");
							
							List<String> issuesIdList = null;
							
							if(reportMetaDataMap.containsKey(errorCaptionWithoutSpace)){
								
								issuesIdList = (List<String>) reportMetaDataMap.get(errorCaptionWithoutSpace);
								
							} else {
								
								issuesIdList = new ArrayList<String>();
							}
							
							issuesIdList.add(issueId);
							
							reportMetaDataMap.put(errorCaptionWithoutSpace, issuesIdList);
							
						}
						
					} catch (Exception e) {
						
					}

				
				}
				
			}
			
			if(report.getReportObject().containsKey("page" + runIdentifier)) {
				
				report.getReportObject().get("page" + runIdentifier).putAll(reportMap);
				
			} else {
				
				report.getReportObject().put("page" + runIdentifier, reportMap);
			}
			
			report.getReportObjectMetaData().putAll(reportMetaDataMap);
			
			addReportToDB = true;
			
		}
		
		if(addReportToDB) {
			
			falsePositiveAnalysisServiceHelper.addReportToDB(url, report,issuesCountObj);
			
		}
		
		if(!Util.isEmpty(branch)) {
			
			String checkAndUpdateStatusInCentralizedServiceURLWithIdentifier = checkAndUpdateStatusInCentralizedServiceURL + runIdentifier + "/" + branch;
			
			falsePositiveAnalysisServiceHelper.sendResponseToMicroService(checkAndUpdateStatusInCentralizedServiceURLWithIdentifier, null, RequestMethod.GET);
			
		}
		
	}
	
	/**
	 * Method for fetch and set the temporary object in map based on the page URL. This method will be called before starting the analysis.
	 * @param url
	 * @param runIdentifier
	 */
	public void fetchAndSetTheObjectInTemporaryObjectMap(String url, String runIdentifier) {
		
		falsePositiveAnalysisServiceHelper.fetchAndAddTemporaryObject(url, runIdentifier);
	}
	
	/**
	 * Method used to remove the temporary object from temporary object map and temporary report map based on page URL. 
	 * @param url
	 */
	public void removeTemporaryObjectFromMap(String url, String runIdentifier) {
		
		falsePositiveAnalysisServiceHelper.removeObjectFromTemporaryObjectMap(url, runIdentifier);
		
	}
	
}
