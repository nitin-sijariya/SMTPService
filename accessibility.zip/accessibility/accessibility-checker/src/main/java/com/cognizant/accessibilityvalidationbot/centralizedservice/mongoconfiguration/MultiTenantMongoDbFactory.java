package com.cognizant.accessibilityvalidationbot.centralizedservice.mongoconfiguration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.SimpleMongoClientDatabaseFactory;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import com.cognizant.accessibilityvalidationbot.centralizedservice.Utils.Util;
import com.mongodb.client.MongoDatabase;

public class MultiTenantMongoDbFactory extends SimpleMongoClientDatabaseFactory {

	/** The database. */
	@Value("${spring.data.mongodb.database}")
	private String database;
	
	protected String getDatabaseName() {
		return this.database;
	}
	
	
	public MultiTenantMongoDbFactory(String uri)  {
        super(uri);
    }
	
	@Override
	protected MongoDatabase doGetMongoDatabase(String dbName) {
		
		 Object tenant = getDatabaseName();
	        
        if(!Util.isEmpty(RequestContextHolder.getRequestAttributes())) {
        	tenant = RequestContextHolder.getRequestAttributes().getAttribute("tenantId", RequestAttributes.SCOPE_REQUEST);
        }
        
        if (tenant instanceof String)
        {
            return super.doGetMongoDatabase(tenant.toString());
        }
        
		return super.doGetMongoDatabase(getDatabaseName());
	}

}
