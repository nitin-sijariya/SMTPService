package com.cognizant.accessibilityvalidationbot.process.model;

import org.openqa.selenium.WebDriver;

/**
 * POJO class for setting selenium driver object
 * @author 578086
 *
 */
public class Driver {

	/** Web driver created by selenium**/
	private WebDriver driver;

	/**
	 * @return the driver
	 */
	public WebDriver getDriver() {
		return driver;
	}

	/**
	 * @param driver the driver to set
	 */
	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}
	
}
