package com.cognizant.accessibilityvalidationbot.process.service;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.json.JSONObject;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.cognizant.accessibilityvalidationbot.process.factory.DriverManager;
import com.cognizant.accessibilityvalidationbot.process.model.Driver;
import com.cognizant.accessibilityvalidationbot.process.service.serviceHelper.ProcessServiceHelper;
import com.cognizant.accessibilityvalidationbot.process.utils.CONSTANTS;
import com.cognizant.accessibilityvalidationbot.process.utils.Util;

/**
 * Service class for Process Validation
 * @author 578086
 *
 */
@Service
public class ProcessService {

	private static final Logger LOGGER = LoggerFactory.getLogger(ProcessService.class);
	
	/** Process Validation Service Helper class object*/
	@Autowired
	private ProcessServiceHelper processServiceHelper;
	
	/** URL for analyze false positive service*/
	@Value("${app.falsepositiveanalysis.analyse.url}")
	private String falsePositiveAnalysisURL;
	
	/** validation js URL for process*/
	@Value("${app.processvalidationjs.url}")
	private String validationJSURL;
	
	/**
	 * Method for initiating the Process validation in parallel thread and return the success response immediately
	 * 
	 * @param runIdentifier
	 * @param URL
	 * @param browserName
	 * @param deviceName
	 * @param popupXpathList
	 * @param validationsRequired
	 * @return
	 * @throws NoSuchMethodException
	 * @throws SecurityException
	 */
	public String initiateProcessValidation(String runIdentifier, String URL, String browserName, String deviceName, List<String> popupXpathList, List<String> validationsRequired, List<String> accessUrlList, Map<String, Object> credentialDataMap) throws NoSuchMethodException, SecurityException {
		
		LOGGER.info("Process validation initiated for RunIdentifier:"+runIdentifier + " ,URL:" + URL + ", browserName:"+ browserName + ", deviceName:"+ deviceName);
		
		Class<?>[] parameterTypes = new Class[8];
		
		List<Object> parameters = new LinkedList<>();

		parameterTypes[0] = String.class;

		parameterTypes[1] = String.class;

		parameterTypes[2] = String.class;
		
		parameterTypes[3] = String.class;
		
		parameterTypes[4] = List.class; 
		
		parameterTypes[5] = List.class; 
		
		parameterTypes[6] = List.class;
		
		parameterTypes[7] = Map.class;
		
		parameters.add(runIdentifier);

		parameters.add(URL);
		
		parameters.add(browserName);
		
		parameters.add(deviceName);
		
		parameters.add(popupXpathList);
		
		parameters.add(validationsRequired);
		
		parameters.add(accessUrlList);
		
		parameters.add(credentialDataMap);	
		
		processServiceHelper.invokeMethodInsideThread(
				ProcessService.class.getMethod("startProcessValidation", parameterTypes), this, parameters.size(), parameters);
		 
		return "Validation Started Successfully";
		
	}
	
	/**
	 * Method to start Process validation by opening new browser
	 * 
	 * @param runIdentifier
	 * @param url
	 * @param browserName
	 * @param deviceName
	 * @param popupXpathList
	 * @param validationsRequired
	 */
	public void startProcessValidation(String runIdentifier, String url, String browserName, String deviceName, List<String> popupXpathList, List<String> validationsRequired, List<String> accessUrlList, Map<String, Object> credentialDataMap) {
		
		LOGGER.info("Validation started for RunIdentifier:"+runIdentifier+ ", URL:" + url + ", deviceName:" + deviceName);
		
		String falsePositiveAnalysisURLWithIdentifier = falsePositiveAnalysisURL + runIdentifier;
		
		Driver seleniumDriver = new Driver();
		
		try {
			
			seleniumDriver.setDriver(processServiceHelper.getWebDriver(browserName, deviceName));
			
			DriverManager.setWebDriver(seleniumDriver.getDriver());
			
			String osName = System.getProperty("os.name");
			
			if(osName.equals("Linux")) {
				
				System.setProperty("java.awt.headless", "true");
				
			} else {
				
				System.setProperty("java.awt.headless", "false");
				
			}
			
			seleniumDriver.getDriver().manage().timeouts().setScriptTimeout(20, TimeUnit.MINUTES);
			
			processServiceHelper.openNewTab(seleniumDriver.getDriver());
			
			processServiceHelper.switchToNewTab(seleniumDriver.getDriver());
			
			if(!Util.isEmpty(accessUrlList)) {
				
				processServiceHelper.getAccessUsingAccessUrlList(accessUrlList, seleniumDriver.getDriver(), credentialDataMap);
				
			}
			
			processServiceHelper.getAccessUsingLogInCredentials(seleniumDriver.getDriver(), credentialDataMap, popupXpathList, url, runIdentifier);
			
			Thread.sleep(4000);
			
			seleniumDriver.getDriver().get(url);
			
			Thread.sleep(8000);
			
			processServiceHelper.injectJSToTheBrowser(seleniumDriver.getDriver(), validationJSURL, false);
			
			Thread.sleep(10000);
			
			Util.reachBottomOfPage(seleniumDriver.getDriver());
			
			String function = "JSON.stringify(getProperWidthAndHeightForScreenShot())";
			
			String bodyRect= 
					  (String)((JavascriptExecutor) seleniumDriver.getDriver()).executeScript(
					  "return "+function+";");
			
			org.json.JSONObject documentReCtJson = new org.json.JSONObject(bodyRect);
			
			Thread.sleep(500);
			
			String pageTitle = seleniumDriver.getDriver().getTitle();
			
			int width = documentReCtJson.getInt("width");
			
			int height = documentReCtJson.getInt("height");
			
			if(browserName.equalsIgnoreCase("MOBILE")) {
				
				seleniumDriver.getDriver().manage().window().setSize(new Dimension(width + 1, height + 1));
			}
			
			Thread.sleep(10000);
			
			((JavascriptExecutor) seleniumDriver.getDriver())
			.executeScript("window.scrollTo(0,0)");
			
			processServiceHelper.popUpHandler(seleniumDriver.getDriver(), popupXpathList, url, runIdentifier);
			
			Thread.sleep(4000);
			
			String base64ScreenShot =null;
			
			if(browserName.equalsIgnoreCase("MOBILE") || browserName.equalsIgnoreCase("CHROME")) {
				
				base64ScreenShot = processServiceHelper.takeMobileScreenShot(width, height, browserName, seleniumDriver.getDriver());
				
			}
			
			Thread.sleep(1000);
			
			boolean isJavaScriptInjected = Util.isJavaScriptLoadedInWebPageWithRetryCount("isJavaScriptLoaded()", seleniumDriver.getDriver(), 5, 0);
			
			LOGGER.info("Is Javascript loaded:"+ isJavaScriptInjected + ", runIdentifier:" + runIdentifier + ", URL:"+ url);
			
			if(isJavaScriptInjected) {
				
				//if(validationsRequired.contains(CONSTANTS.ACCESSIBILITY)) {

					//String pageTitle = seleniumDriver.getDriver().getTitle();

					processServiceHelper.invokeJSFunction(seleniumDriver.getDriver(), "DOMtoString()");

					String accessibilityJSON = Util.recurrsive("checkAndReturnAccessibilityJson()", 6000);
					
					JSONObject accessibilityObj = new JSONObject(accessibilityJSON);
					
					processServiceHelper.takeEachIssueScreenshot(seleniumDriver, accessibilityObj, runIdentifier);
					
					processServiceHelper.updateScreenShotToFalsePositiveAnalysisService(url, falsePositiveAnalysisURLWithIdentifier, base64ScreenShot,accessibilityObj,pageTitle); // we need to pass the result json which we recieved from js
				//}
				
				
				
			} else {
				
				LOGGER.info("In start Process validation closing the browser for RunIdentifier:"+runIdentifier + ", URL:" + url);
				
				Util.closeDriver(seleniumDriver.getDriver());
				
			}
		} catch (Exception e) {
			
			e.printStackTrace();
			
			LOGGER.error("Exception occured while processing the validation in startProcessValidation methood for RunIdentifier:"+runIdentifier + ", URL:" + url + ". Error message:\n" + e.getMessage());
			
			Util.closeDriver(seleniumDriver.getDriver());
			
		} finally {
			
			Util.closeDriver(seleniumDriver.getDriver());
			
		}
		
		LOGGER.info("Process validation completed for RunIdentifier:"+runIdentifier + ", URL:" + url);
		
	}

}
