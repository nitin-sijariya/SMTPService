package com.cognizant.accessibilityvalidationbot.centralizedservice.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.accessibilityvalidationbot.centralizedservice.model.Configuration;

/**
 * Repository for Configuration collection
 * @author 578086
 *
 */
@Transactional
public interface ConfigurationRepository extends MongoRepository<Configuration,String>{

}
