package com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.service.serviceHelper;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.imageio.ImageIO;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.utils.HttpClientUtils;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;

import com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.Utils.CONSTANTS;
import com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.Utils.Util;
import com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.model.DomainSpecificRuleBook;
import com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.model.GeneralRuleBook;
import com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.model.Report;
import com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.model.RuleBook;
import com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.repository.DomainSpecificRuleBookRepository;
import com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.repository.GeneralRuleBookRepository;
import com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.repository.ReportRepository;


@Service
public class FalsePositiveAnalysisServiceHelper {

	private static final Logger LOGGER = LoggerFactory.getLogger(FalsePositiveAnalysisServiceHelper.class);
	
	/**
	 * using generalRuleBookRepository we can able to fetch general rule book from mongo db
	 */
	@Autowired
	private GeneralRuleBookRepository generalRuleBookRepository;

	/**
	 * using domainSpecificRuleBookRepository we can able to fetch domain specific rule book from mongo db
	 */
	@Autowired
	private DomainSpecificRuleBookRepository domainSpecificRuleBookRepository;
	
	/** Mongo reporitory for Report collection*/
	@Autowired
	private ReportRepository reportRepository;

	/**
	 * General rule book mongo id 
	 */
	@Value("${app.general.rule.book.mongo.collection.document.id}")
	private String generalRuleBookId;
	
	/** Screen Shot base URL*/
	@Value("${app.screenshot.url}")
	private String screenShotURL;
	
	/** Screen Shot base directory */
	@Value("${app.screenshot.dir}")
	private String screenShotBaseDir;
	
	/** Screen shot file dir path */
	@Value("${app.screenshot.path}")
	private String screenShotPath;
	
	/** OCR Service URL*/
	@Value("${app.ocr.service.url}")
	private String ocrServiceURL;
	
	/** User ignore type available in false positive elimination*/
	@Value("${app.falsepositive.user.ignore.issue.type}")
	private String userIgnoreIssueType;
	
	/** Static key for page object in report object*/
	@Value("${app.report.pageobject.static.key}")
	private String reportPageObjectStaticKey;
	
	/** Static key for config object in report object*/
	@Value("${app.report.configobject.static.key}")
	private String reportConfigObjectStaticKey;
	
	/** Splitter for validation category name from issue id*/
	@Value("${app.report.validation.categoryname.splitter}")
	private String validationCategoryNameSplitter;
	
	/** Cropped image width needs to be greater than this width*/
	@Value("${app.cropped.image.minimum.width}")
	private String croppedImageMinimumWidth;
	
	/** Cropped image height needs to be greater than this height*/
	@Value("${app.cropped.image.minimum.height}")
	private String croppedImageMinimumHeight;

	/** Temporary Object Map for storing temporary objects*/
	@Autowired
	private Map<String,Object> temporaryObjectMap;

	/** Temporary Reprort Object Map for storing report object temporarily*/
	@Autowired
	private Map<String,Report> temporaryReportObjectMap;

	/**
	 * Get General rule book using Mongo ID
	 * @param id
	 * @return
	 */
	public GeneralRuleBook getGeneralRuleBook(String id) {

		return generalRuleBookRepository.findById(id).get();
	}
	
	/**
	 * Get Domain Specific rule book using Mongo ID
	 * @param domain
	 * @return
	 */

	public DomainSpecificRuleBook getDomainSpecificRuleBook(String url) {

		return domainSpecificRuleBookRepository.findByPageURL(url);
	}
	
	/**
	 * Method to fetch and add temporary objects to map based on page URL.
	 * @param url
	 * @param runIdentifier
	 */
	public void fetchAndAddTemporaryObject(String url, String runIdentifier) {
		
		Map<String,Object> ruleBookObjectMap = new HashMap<String, Object>();
		
		URI uri = null;
		
		String domainName = "";
		
		try {
			
			uri = new URI(url);
			
			domainName = uri.getHost();
			
		} catch (URISyntaxException e) {
			
			domainName = url;
			
		}
		
		DomainSpecificRuleBook domainSpecificRuleBook  = getDomainSpecificRuleBook(domainName);
		
		GeneralRuleBook generalRuleBook = getGeneralRuleBook(generalRuleBookId);

		ruleBookObjectMap.putAll(addTemporaryObjectForGeneralRuleBook(ruleBookObjectMap, generalRuleBook));
		
		ruleBookObjectMap.putAll(addTemporaryObjectForDomainSpecificRuleBook(ruleBookObjectMap, domainSpecificRuleBook));
		
		ruleBookObjectMap.put("domainSpecificRuleBook",domainSpecificRuleBook);
		
		ruleBookObjectMap.put("generalRuleBook", generalRuleBook);
		
		temporaryObjectMap.put(url + runIdentifier, ruleBookObjectMap);
	}
	
	/**
	 * Method to add general rule book temporary objects
	 * @param ruleBookObjectMap
	 * @param generalRuleBook
	 * @return
	 */
	private Map<String,Object> addTemporaryObjectForGeneralRuleBook(Map<String,Object> ruleBookObjectMap, GeneralRuleBook generalRuleBook){
		
		Map<String,Set<String>> overLapGeneralRuleElementMap = null, overFlowGeneralRuleElementMap = null, 
								positionHorizontalGeneralRuleElementMap = null, positionVerticalGeneralRuleElementMap = null, 
								imageNotLoadedGeneralRuleElementMap = null, imageLowQualityGeneralRuleElementMap = null, imageAspectRatioGeneralRuleElementMap = null,
								brokenLinkGeneralRuleElementMap = null, imageBrokenLinkGeneralRuleElementMap = null, videoGeneralRuleElementMap = null, 
								carouselGeneralRuleElementMap = null, menuHoverGeneralRuleElementMap = null, patternDiffGeneralRuleElementMap = null,
							    fontValidationGeneralRuleElementMap =null;
		
		if(generalRuleBook != null) {
			
			if(generalRuleBook.getRule().containsKey(CONSTANTS.OVERLAP)) {
				
				overLapGeneralRuleElementMap = createElementMap(new HashMap<String, Set<String>>(), generalRuleBook, CONSTANTS.OVERLAP);
				
			}
			
			if(generalRuleBook.getRule().containsKey(CONSTANTS.OVERFLOW)) {
				
				overFlowGeneralRuleElementMap = createElementMap(new HashMap<String, Set<String>>(), generalRuleBook, CONSTANTS.OVERFLOW);
			}
			
			if(generalRuleBook.getRule().containsKey(CONSTANTS.POSITION_ALIGNMENT_HORIZONTAL)) {
				
				positionHorizontalGeneralRuleElementMap = createElementMap(new HashMap<String, Set<String>>(), generalRuleBook, CONSTANTS.POSITION_ALIGNMENT_HORIZONTAL);
				
			}
			
			if(generalRuleBook.getRule().containsKey(CONSTANTS.POSITION_ALIGNMENT_VERTICAL)) {
				
				positionVerticalGeneralRuleElementMap = createElementMap(new HashMap<String, Set<String>>(), generalRuleBook, CONSTANTS.POSITION_ALIGNMENT_VERTICAL);
			}
			
			if(generalRuleBook.getRule().containsKey(CONSTANTS.CONFIGIMAGENOTLOADED)) {
					
				imageNotLoadedGeneralRuleElementMap = createElementMap(new HashMap<String, Set<String>>(), generalRuleBook, CONSTANTS.CONFIGIMAGENOTLOADED);
				
			}
			
			if(generalRuleBook.getRule().containsKey(CONSTANTS.CONFIGIMAGELOWQUALITY)) {
				
				imageLowQualityGeneralRuleElementMap = createElementMap(new HashMap<String, Set<String>>(), generalRuleBook, CONSTANTS.CONFIGIMAGELOWQUALITY);
				
			}
			
			if(generalRuleBook.getRule().containsKey(CONSTANTS.CONFIGIMAGEASPECTRATIO)) {
				
				imageAspectRatioGeneralRuleElementMap = createElementMap(new HashMap<String, Set<String>>(), generalRuleBook, CONSTANTS.CONFIGIMAGEASPECTRATIO);
				
			}
			
			if(generalRuleBook.getRule().containsKey(CONSTANTS.CONFIGBROKENLINK)) {
				
				brokenLinkGeneralRuleElementMap = createElementMap(new HashMap<String, Set<String>>(), generalRuleBook, CONSTANTS.CONFIGBROKENLINK);
				
			}
			
			if(generalRuleBook.getRule().containsKey(CONSTANTS.CONFIGIMAGEBROKENLINK)) {
				
				imageBrokenLinkGeneralRuleElementMap = createElementMap(new HashMap<String, Set<String>>(), generalRuleBook, CONSTANTS.CONFIGIMAGEBROKENLINK);
				
			}
			
			if(generalRuleBook.getRule().containsKey(CONSTANTS.CONFIGVIDEO)) {
				
				videoGeneralRuleElementMap = createElementMap(new HashMap<String, Set<String>>(), generalRuleBook, CONSTANTS.CONFIGVIDEO);
				
			}
			
			if(generalRuleBook.getRule().containsKey(CONSTANTS.CONFIGCAROUSEL)) {
				
				carouselGeneralRuleElementMap = createElementMap(new HashMap<String, Set<String>>(), generalRuleBook, CONSTANTS.CONFIGCAROUSEL);
				
			}
			
			if(generalRuleBook.getRule().containsKey(CONSTANTS.CONFIGMENUHOVER)) {
				
				menuHoverGeneralRuleElementMap = createElementMap(new HashMap<String, Set<String>>(), generalRuleBook, CONSTANTS.CONFIGMENUHOVER);
				
			}
			
			if(generalRuleBook.getRule().containsKey(CONSTANTS.CONFIGPATTERNDIFF)) {
				
				patternDiffGeneralRuleElementMap = createElementMap(new HashMap<String, Set<String>>(), generalRuleBook, CONSTANTS.CONFIGPATTERNDIFF); 
			}
			
			if(generalRuleBook.getRule().containsKey(CONSTANTS.CONFIGFONTVALIDATION)) {
				
				fontValidationGeneralRuleElementMap = createElementMap(new HashMap<String, Set<String>>(), generalRuleBook, CONSTANTS.CONFIGFONTVALIDATION); 
			}
			
			ruleBookObjectMap.put("overLapGeneralRuleElementMap", overLapGeneralRuleElementMap);
			
			ruleBookObjectMap.put("overFlowGeneralRuleElementMap", overFlowGeneralRuleElementMap);
			
			ruleBookObjectMap.put("positionHorizontalGeneralRuleElementMap", positionHorizontalGeneralRuleElementMap);
			
			ruleBookObjectMap.put("positionVerticalGeneralRuleElementMap", positionVerticalGeneralRuleElementMap);
			
			ruleBookObjectMap.put("imageNotLoadedGeneralRuleElementMap", imageNotLoadedGeneralRuleElementMap);
			
			ruleBookObjectMap.put("imageLowQualityGeneralRuleElementMap", imageLowQualityGeneralRuleElementMap);
			
			ruleBookObjectMap.put("imageAspectRatioGeneralRuleElementMap", imageAspectRatioGeneralRuleElementMap);
			
			ruleBookObjectMap.put("brokenLinkGeneralRuleElementMap", brokenLinkGeneralRuleElementMap);
			
			ruleBookObjectMap.put("imageBrokenLinkGeneralRuleElementMap", imageBrokenLinkGeneralRuleElementMap);
			
			ruleBookObjectMap.put("videoGeneralRuleElementMap", videoGeneralRuleElementMap);
			
			ruleBookObjectMap.put("carouselGeneralRuleElementMap", carouselGeneralRuleElementMap);
			
			ruleBookObjectMap.put("menuHoverGeneralRuleElementMap", menuHoverGeneralRuleElementMap);
			
			ruleBookObjectMap.put("patternDiffGeneralRuleElementMap", patternDiffGeneralRuleElementMap);
			
			ruleBookObjectMap.put("fontValidationGeneralRuleElementMap", fontValidationGeneralRuleElementMap);

		}
		
		return ruleBookObjectMap;
	}
	
	/**
	 *  Method to add domain specific rule book temporary objects
	 * @param ruleBookObjectMap
	 * @param domainSpecificRuleBook
	 * @return
	 */
	private Map<String,Object> addTemporaryObjectForDomainSpecificRuleBook(Map<String,Object> ruleBookObjectMap, DomainSpecificRuleBook domainSpecificRuleBook){
		
		Map<String,Set<String>> overLapDomainRuleElementMap = null, overFlowDomainRuleElementMap = null, positionHorizontalDomainRuleElementMap = null,
				positionVerticalDomainRuleElementMap = null, imageNotLoadedDomainRuleElementMap = null, imageLowQualityDomainRuleElementMap = null,
				imageAspectRatioDomainRuleElementMap = null, brokenLinkDomainRuleElementMap = null, imageBrokenLinkDomainRuleElementMap = null,
				videoDomainRuleElementMap = null, carouselDomainRuleElementMap = null, menuHoverDomainRuleElementMap = null,
				patternDiffDomainRuleElementMap = null,fontValidationDomainRuleElementMap =null, spellCheckerDomainRuleElementMap =null;
		
		if(domainSpecificRuleBook != null) {

			if(domainSpecificRuleBook.getRule().containsKey(CONSTANTS.OVERLAP)) {
				
				overLapDomainRuleElementMap = createElementMap(new HashMap<String, Set<String>>(), domainSpecificRuleBook, CONSTANTS.OVERLAP);
				
			}
			
			if(domainSpecificRuleBook.getRule().containsKey(CONSTANTS.OVERFLOW)) {
				
				overFlowDomainRuleElementMap = createElementMap(new HashMap<String, Set<String>>(), domainSpecificRuleBook, CONSTANTS.OVERFLOW);
				
			}
			
			if(domainSpecificRuleBook.getRule().containsKey(CONSTANTS.POSITION_ALIGNMENT_HORIZONTAL)) {
				
				positionHorizontalDomainRuleElementMap = createElementMap(new HashMap<String, Set<String>>(), domainSpecificRuleBook, CONSTANTS.POSITION_ALIGNMENT_HORIZONTAL);
				
			}
			
			if(domainSpecificRuleBook.getRule().containsKey(CONSTANTS.POSITION_ALIGNMENT_VERTICAL)) {
				
				positionVerticalDomainRuleElementMap = createElementMap(new HashMap<String, Set<String>>(), domainSpecificRuleBook, CONSTANTS.POSITION_ALIGNMENT_VERTICAL);
				
			}
			
			if(domainSpecificRuleBook.getRule().containsKey(CONSTANTS.CONFIGIMAGENOTLOADED)) {
						
				imageNotLoadedDomainRuleElementMap = createElementMap(new HashMap<String, Set<String>>(), domainSpecificRuleBook, CONSTANTS.CONFIGIMAGENOTLOADED);
				
			}
			
			if(domainSpecificRuleBook.getRule().containsKey(CONSTANTS.CONFIGIMAGELOWQUALITY)) {
				
				imageLowQualityDomainRuleElementMap = createElementMap(new HashMap<String, Set<String>>(), domainSpecificRuleBook, CONSTANTS.CONFIGIMAGELOWQUALITY);
				
			}
			
			if(domainSpecificRuleBook.getRule().containsKey(CONSTANTS.CONFIGIMAGEASPECTRATIO)) {
				
				imageAspectRatioDomainRuleElementMap = createElementMap(new HashMap<String, Set<String>>(), domainSpecificRuleBook, CONSTANTS.CONFIGIMAGEASPECTRATIO);
				
			}
			
			if(domainSpecificRuleBook.getRule().containsKey(CONSTANTS.CONFIGBROKENLINK)) {
				
				brokenLinkDomainRuleElementMap = createElementMap(new HashMap<String, Set<String>>(), domainSpecificRuleBook, CONSTANTS.CONFIGBROKENLINK);
				
			}
			
			if(domainSpecificRuleBook.getRule().containsKey(CONSTANTS.CONFIGIMAGEBROKENLINK)) {
				
				imageBrokenLinkDomainRuleElementMap = createElementMap(new HashMap<String, Set<String>>(), domainSpecificRuleBook, CONSTANTS.CONFIGIMAGEBROKENLINK);
				
			}
			
			if(domainSpecificRuleBook.getRule().containsKey(CONSTANTS.CONFIGVIDEO)) {
				
				videoDomainRuleElementMap = createElementMap(new HashMap<String, Set<String>>(), domainSpecificRuleBook, CONSTANTS.CONFIGVIDEO);
				
			}
			
			if(domainSpecificRuleBook.getRule().containsKey(CONSTANTS.CONFIGCAROUSEL)) {
				
				carouselDomainRuleElementMap = createElementMap(new HashMap<String, Set<String>>(), domainSpecificRuleBook, CONSTANTS.CONFIGCAROUSEL);
				
			}
			
			if(domainSpecificRuleBook.getRule().containsKey(CONSTANTS.CONFIGMENUHOVER)) {
				
				menuHoverDomainRuleElementMap = createElementMap(new HashMap<String, Set<String>>(), domainSpecificRuleBook, CONSTANTS.CONFIGMENUHOVER);
				
			}
			
			if(domainSpecificRuleBook.getRule().containsKey(CONSTANTS.CONFIGPATTERNDIFF)) {
				
				patternDiffDomainRuleElementMap = createElementMap(new HashMap<String, Set<String>>(), domainSpecificRuleBook, CONSTANTS.CONFIGPATTERNDIFF);
				
			}
			
			if(domainSpecificRuleBook.getRule().containsKey(CONSTANTS.CONFIGFONTVALIDATION)) {
				
				fontValidationDomainRuleElementMap = createElementMap(new HashMap<String, Set<String>>(), domainSpecificRuleBook, CONSTANTS.CONFIGFONTVALIDATION);
				
			}
			
			if(domainSpecificRuleBook.getRule().containsKey(CONSTANTS.CONFIGSPELLCHECKER)) {
				
				spellCheckerDomainRuleElementMap = createElementMap(new HashMap<String, Set<String>>(), domainSpecificRuleBook, CONSTANTS.CONFIGSPELLCHECKER);
				
			}

		}
		
		ruleBookObjectMap.put("overLapDomainRuleElementMap", overLapDomainRuleElementMap);
		
		ruleBookObjectMap.put("overFlowDomainRuleElementMap", overFlowDomainRuleElementMap);
		
		ruleBookObjectMap.put("positionHorizontalDomainRuleElementMap", positionHorizontalDomainRuleElementMap);
		
		ruleBookObjectMap.put("positionVerticalDomainRuleElementMap", positionVerticalDomainRuleElementMap);
		
		ruleBookObjectMap.put("imageNotLoadedDomainRuleElementMap", imageNotLoadedDomainRuleElementMap);
		
		ruleBookObjectMap.put("imageLowQualityDomainRuleElementMap", imageLowQualityDomainRuleElementMap);
		
		ruleBookObjectMap.put("imageAspectRatioDomainRuleElementMap", imageAspectRatioDomainRuleElementMap);
		
		ruleBookObjectMap.put("brokenLinkDomainRuleElementMap", brokenLinkDomainRuleElementMap);
		
		ruleBookObjectMap.put("imageBrokenLinkDomainRuleElementMap", imageBrokenLinkDomainRuleElementMap);
		
		ruleBookObjectMap.put("videoDomainRuleElementMap", videoDomainRuleElementMap);
		
		ruleBookObjectMap.put("carouselDomainRuleElementMap", carouselDomainRuleElementMap);
		
		ruleBookObjectMap.put("menuHoverDomainRuleElementMap", menuHoverDomainRuleElementMap);
		
		ruleBookObjectMap.put("patternDiffDomainRuleElementMap", patternDiffDomainRuleElementMap);
		
		ruleBookObjectMap.put("fontValidationDomainRuleElementMap", fontValidationDomainRuleElementMap);
		
		ruleBookObjectMap.put("spellCheckerDomainRuleElementMap", spellCheckerDomainRuleElementMap);
		
		
		return ruleBookObjectMap;
	}
	
	/**
	 * Method used to do false positive analysis for validation result
	 * @param reportJsonObject
	 * @param errorCaption
	 * @param url
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public JSONObject initiateFalsePositiveAnalysis(JSONObject reportJsonObject, String errorCaption, String url, String runIdentifier) {

		Map<String,Object> generalRule = null;

		Map<String,Object> domainRule = null;

		List<Map<String,String>> overLapGeneralRules = null;
		
		List<Map<String,String>> overLapDomainRules = null;
		
		List<String> generalCaseSensitiveRuleList = null;

		List<String> domainCaseSensitiveList = null;
		
		List<Map<String,String>> overFlowGeneralRules = null;

		List<Map<String,String>> overFlowDomainRules = null;
		
		List<Map<String,String>> positionHorizontalGeneralRules = null;
		
		List<Map<String,String>> positionHorizontalDomainRules = null;
		
		List<Map<String,String>> positionVerticalGeneralRules = null;

		List<Map<String,String>> positionVerticalDomainRules = null;
		
		List<Map<String,String>> imageNotLoadedGeneralRules = null;

		List<Map<String,String>> imageNotLoadedDomainRules = null;
		
		List<Map<String,String>> imageLowQualityGeneralRules = null;

		List<Map<String,String>> imageLowQualityDomainRules = null;
		
		List<Map<String,String>> imageAspectRatioGeneralRules = null;

		List<Map<String,String>> imageAspectRatioDomainRules = null;
		
		List<Map<String,String>> brokenLinkGeneralRules = null;

		List<Map<String,String>> brokenLinkDomainRules = null;
		
		List<Map<String,String>> imageBrokenLinkGeneralRules = null;

		List<Map<String,String>> imageBrokenLinkDomainRules = null;
		
		List<Map<String,String>> videoGeneralRules = null;

		List<Map<String,String>> videoDomainRules = null;
		
		List<Map<String,String>> carouselGeneralRules = null;

		List<Map<String,String>> carouselDomainRules = null;
		
		List<Map<String,String>> menuHoverGeneralRules = null;

		List<Map<String,String>> menuHoverDomainRules = null;
		
		List<Map<String,String>> patternDiffGeneralRules = null;

		List<Map<String,String>> patternDiffDomainRules = null;		

		List<Map<String,String>> spellCheckerDomainRules = null;
		
		List<Map<String,String>> spellCheckerGeneralRules = null;
		
		List<Map<String,String>> fontValidationGeneralRules = null;
		
		List<Map<String,String>> fontValidationDomainRules = null;
		
		GeneralRuleBook generalRuleBook = (GeneralRuleBook) fetchAndReturnObjectFromTemporaryObjectMap(url, "generalRuleBook", runIdentifier);
		
		DomainSpecificRuleBook domainSpecificRuleBook = (DomainSpecificRuleBook) fetchAndReturnObjectFromTemporaryObjectMap(url, "domainSpecificRuleBook", runIdentifier);

		if(generalRuleBook != null) {

			generalRule = generalRuleBook.getRule();

			overLapGeneralRules = (List<Map<String, String>>) generalRule.get(CONSTANTS.OVERLAP);

			generalCaseSensitiveRuleList = (List<String>) generalRuleBook.getRule().get(CONSTANTS.CASESENSITIVE);
			
			overFlowGeneralRules = (List<Map<String, String>>) generalRule.get(CONSTANTS.OVERFLOW);
			
			positionHorizontalGeneralRules = (List<Map<String, String>>) generalRule.get(CONSTANTS.POSITION_ALIGNMENT_HORIZONTAL);
			
			positionVerticalGeneralRules = (List<Map<String, String>>) generalRule.get(CONSTANTS.POSITION_ALIGNMENT_VERTICAL);
			
			imageNotLoadedGeneralRules = (List<Map<String, String>>) generalRule.get(CONSTANTS.CONFIGIMAGENOTLOADED);
			
			imageAspectRatioGeneralRules = (List<Map<String, String>>) generalRule.get(CONSTANTS.CONFIGIMAGEASPECTRATIO);
			
			imageLowQualityGeneralRules = (List<Map<String, String>>) generalRule.get(CONSTANTS.CONFIGIMAGELOWQUALITY);
			
			brokenLinkGeneralRules = (List<Map<String, String>>) generalRule.get(CONSTANTS.CONFIGBROKENLINK);
			
			imageBrokenLinkGeneralRules = (List<Map<String, String>>) generalRule.get(CONSTANTS.CONFIGIMAGEBROKENLINK);
			
			videoGeneralRules = (List<Map<String, String>>) generalRule.get(CONSTANTS.CONFIGVIDEO);
			
			carouselGeneralRules = (List<Map<String, String>>) generalRule.get(CONSTANTS.CONFIGCAROUSEL);
			
			menuHoverGeneralRules = (List<Map<String, String>>) generalRule.get(CONSTANTS.CONFIGMENUHOVER);
			
			patternDiffGeneralRules = (List<Map<String, String>>) generalRule.get(CONSTANTS.CONFIGPATTERNDIFF);
			
			fontValidationGeneralRules = (List<Map<String, String>>) generalRule.get(CONSTANTS.CONFIGFONTVALIDATION);
			
			spellCheckerGeneralRules = (List<Map<String, String>>) generalRule.get(CONSTANTS.CONFIGSPELLCHECKER);

		}

		if(domainSpecificRuleBook != null) {

			domainRule = domainSpecificRuleBook.getRule();

			overLapDomainRules = (List<Map<String, String>>) domainRule.get(CONSTANTS.OVERLAP);

			domainCaseSensitiveList = (List<String>) domainSpecificRuleBook.getRule().get(CONSTANTS.CASESENSITIVE);
			
			overFlowDomainRules = (List<Map<String, String>>) domainRule.get(CONSTANTS.OVERFLOW);
			
			positionHorizontalDomainRules = (List<Map<String, String>>) domainRule.get(CONSTANTS.POSITION_ALIGNMENT_HORIZONTAL);
			
			positionVerticalDomainRules = (List<Map<String, String>>) domainRule.get(CONSTANTS.POSITION_ALIGNMENT_VERTICAL);
			
			imageNotLoadedDomainRules = (List<Map<String, String>>) domainRule.get(CONSTANTS.CONFIGIMAGENOTLOADED);
			
			imageLowQualityDomainRules = (List<Map<String, String>>) domainRule.get(CONSTANTS.CONFIGIMAGELOWQUALITY);
			
			imageAspectRatioDomainRules = (List<Map<String, String>>) domainRule.get(CONSTANTS.CONFIGIMAGEASPECTRATIO);
			
			brokenLinkDomainRules = (List<Map<String, String>>) domainRule.get(CONSTANTS.CONFIGBROKENLINK);
			
			imageBrokenLinkDomainRules = (List<Map<String, String>>) domainRule.get(CONSTANTS.CONFIGIMAGEBROKENLINK);
			
			videoDomainRules = (List<Map<String, String>>) domainRule.get(CONSTANTS.CONFIGVIDEO);
			
			carouselDomainRules = (List<Map<String, String>>) domainRule.get(CONSTANTS.CONFIGCAROUSEL);
			
			menuHoverDomainRules = (List<Map<String, String>>) domainRule.get(CONSTANTS.CONFIGMENUHOVER);
			
			patternDiffDomainRules = (List<Map<String, String>>) domainRule.get(CONSTANTS.CONFIGPATTERNDIFF); 
			
			spellCheckerDomainRules = (List<Map<String, String>>) domainRule.get(CONSTANTS.CONFIGSPELLCHECKER);
			
			fontValidationDomainRules = (List<Map<String, String>>) domainRule.get(CONSTANTS.CONFIGFONTVALIDATION);
		}

		if(generalRuleBook != null || domainSpecificRuleBook != null) {

			if(errorCaption.toLowerCase().contains(CONSTANTS.OVERLAP)) {

				boolean isFalsePositiveOverlapGeneralRule = false;

				boolean isFalsePositiveOverlapDomainRule = false;

				Map<String,Set<String>> overLapGeneralRuleElementMap = (Map<String, Set<String>>) fetchAndReturnObjectFromTemporaryObjectMap(url, "overLapGeneralRuleElementMap", runIdentifier);
				
				Map<String,Set<String>> overLapDomainRuleElementMap = (Map<String, Set<String>>) fetchAndReturnObjectFromTemporaryObjectMap(url, "overLapDomainRuleElementMap", runIdentifier);
				
				if(generalRuleBook != null && generalRule.containsKey(CONSTANTS.OVERLAP) && overLapGeneralRuleElementMap.size() > 0 && overLapGeneralRules != null) {
					isFalsePositiveOverlapGeneralRule = isFalsePositive(overLapGeneralRules, overLapGeneralRuleElementMap, reportJsonObject);
				}

				if(domainSpecificRuleBook != null && domainRule.containsKey(CONSTANTS.OVERLAP) && overLapDomainRuleElementMap.size() > 0 && overLapDomainRules != null) {
					isFalsePositiveOverlapDomainRule = isFalsePositive(overLapDomainRules, overLapDomainRuleElementMap, reportJsonObject);
				}

				if(isFalsePositiveOverlapGeneralRule || isFalsePositiveOverlapDomainRule) {
					reportJsonObject.remove(CONSTANTS.ISFALSEPOSITIVE);
					reportJsonObject.put(CONSTANTS.ISFALSEPOSITIVE, true);
				}

			}
			
			if(errorCaption.toLowerCase().replaceAll(CONSTANTS.EMPTYSTRINGWITHSPACE, CONSTANTS.EMPTYSTRING).contains(CONSTANTS.CASESENSITIVE)) {

				boolean isFalsePositiveCasesensitiveGeneralRule = false;

				boolean isFalsePositiveCasesensitiveDomainRule = false;

				if (reportJsonObject.has(CONSTANTS.TEXT)) {

					String text = reportJsonObject.get(CONSTANTS.TEXT).toString(); 

					if(generalRuleBook != null && generalRule.containsKey(CONSTANTS.CASESENSITIVE) && generalCaseSensitiveRuleList != null) {
						isFalsePositiveCasesensitiveGeneralRule = generalCaseSensitiveRuleList.contains(text);
					}

					if(domainSpecificRuleBook != null && domainRule.containsKey(CONSTANTS.CASESENSITIVE) && domainCaseSensitiveList != null) {
						isFalsePositiveCasesensitiveDomainRule = domainCaseSensitiveList.contains(text);
					}

					if (isFalsePositiveCasesensitiveGeneralRule || isFalsePositiveCasesensitiveDomainRule) {
						reportJsonObject.remove(CONSTANTS.ISFALSEPOSITIVE);
						reportJsonObject.put(CONSTANTS.ISFALSEPOSITIVE, true);				
					} 

				}				
			}

			if(errorCaption.toLowerCase().replaceAll(CONSTANTS.EMPTYSTRINGWITHSPACE, CONSTANTS.EMPTYSTRING).contains(CONSTANTS.BROKENLINK)) {

				boolean isFalsePositiveBrokenLinkGeneralRule = false;

				boolean isFalsePositiveBrokenLinkDomainRule = false;

				Map<String,Set<String>> brokenLinkGeneralRuleElementMap = (Map<String, Set<String>>) fetchAndReturnObjectFromTemporaryObjectMap(url, "brokenLinkGeneralRuleElementMap", runIdentifier);
				
				Map<String,Set<String>> brokenLinkDomainRuleElementMap = (Map<String, Set<String>>) fetchAndReturnObjectFromTemporaryObjectMap(url, "brokenLinkDomainRuleElementMap", runIdentifier);
				
				if(generalRuleBook != null && generalRule.containsKey(CONSTANTS.CONFIGBROKENLINK) && brokenLinkGeneralRuleElementMap.size() > 0 && brokenLinkGeneralRules != null) {
					isFalsePositiveBrokenLinkGeneralRule = isFalsePositive(brokenLinkGeneralRules, brokenLinkGeneralRuleElementMap, reportJsonObject);
				}

				if(domainSpecificRuleBook != null && domainRule.containsKey(CONSTANTS.CONFIGBROKENLINK) && brokenLinkDomainRuleElementMap.size() > 0 && brokenLinkDomainRules != null) {
					isFalsePositiveBrokenLinkDomainRule = isFalsePositive(brokenLinkDomainRules, brokenLinkDomainRuleElementMap, reportJsonObject);
				}

				if(isFalsePositiveBrokenLinkGeneralRule || isFalsePositiveBrokenLinkDomainRule) {
					reportJsonObject.remove(CONSTANTS.ISFALSEPOSITIVE);
					reportJsonObject.put(CONSTANTS.ISFALSEPOSITIVE, true);
				}
			}
			
			if(errorCaption.toLowerCase().contains(CONSTANTS.OVERFLOW)) {

				boolean isFalsePositiveOverflowGeneralRule = false;

				boolean isFalsePositiveOverflowDomainRule = false;
				
				Map<String,Set<String>> overFlowGeneralRuleElementMap = (Map<String, Set<String>>) fetchAndReturnObjectFromTemporaryObjectMap(url, "overFlowGeneralRuleElementMap", runIdentifier);
				
				Map<String,Set<String>> overFlowDomainRuleElementMap = (Map<String, Set<String>>) fetchAndReturnObjectFromTemporaryObjectMap(url, "overFlowDomainRuleElementMap", runIdentifier);

				if(generalRuleBook != null && generalRule.containsKey(CONSTANTS.OVERFLOW) && overFlowGeneralRuleElementMap.size() > 0 && overFlowGeneralRules != null) {
					isFalsePositiveOverflowGeneralRule = isFalsePositive(overFlowGeneralRules, overFlowGeneralRuleElementMap, reportJsonObject);
				}

				if(domainSpecificRuleBook != null && domainRule.containsKey(CONSTANTS.OVERFLOW) && overFlowDomainRuleElementMap.size() > 0 && overFlowDomainRules != null) {
					isFalsePositiveOverflowDomainRule = isFalsePositive(overFlowDomainRules, overFlowDomainRuleElementMap, reportJsonObject);
				}

				if(isFalsePositiveOverflowGeneralRule || isFalsePositiveOverflowDomainRule) {
					reportJsonObject.remove(CONSTANTS.ISFALSEPOSITIVE);
					reportJsonObject.put(CONSTANTS.ISFALSEPOSITIVE, true);
				}

			}
			
			if(errorCaption.toLowerCase().contains(CONSTANTS.HORIZONTALMENU_ALIGNMENT)) {
				
				boolean isFalsePositivePositionHorizontalGeneralRule = false;

				boolean isFalsePositivePositionHorizontalDomainRule = false;

				Map<String,Set<String>> positionHorizontalGeneralRuleElementMap = (Map<String, Set<String>>) fetchAndReturnObjectFromTemporaryObjectMap(url, "positionHorizontalGeneralRuleElementMap", runIdentifier);
				
				Map<String,Set<String>> positionHorizontalDomainRuleElementMap = (Map<String, Set<String>>) fetchAndReturnObjectFromTemporaryObjectMap(url, "positionHorizontalDomainRuleElementMap", runIdentifier);
				
				if(generalRuleBook != null && generalRule.containsKey(CONSTANTS.POSITION_ALIGNMENT_HORIZONTAL) && positionHorizontalGeneralRuleElementMap.size() > 0 && positionHorizontalGeneralRules != null) {
					isFalsePositivePositionHorizontalGeneralRule = isFalsePositive(positionHorizontalGeneralRules, positionHorizontalGeneralRuleElementMap, reportJsonObject);
				}

				if(domainSpecificRuleBook != null && domainRule.containsKey(CONSTANTS.POSITION_ALIGNMENT_HORIZONTAL) && positionHorizontalDomainRuleElementMap.size() > 0 && positionHorizontalDomainRules != null) {
					isFalsePositivePositionHorizontalDomainRule = isFalsePositive(positionHorizontalDomainRules, positionHorizontalDomainRuleElementMap, reportJsonObject);
				}

				if(isFalsePositivePositionHorizontalGeneralRule || isFalsePositivePositionHorizontalDomainRule) {
					reportJsonObject.remove(CONSTANTS.ISFALSEPOSITIVE);
					reportJsonObject.put(CONSTANTS.ISFALSEPOSITIVE, true);
				}

			}
			
			if(errorCaption.toLowerCase().contains(CONSTANTS.VERTICALMENU_ALIGNMENT)) {

				boolean isFalsePositivePositionVerticalGeneralRule = false;

				boolean isFalsePositivePositionVerticalDomainRule = false;

				Map<String,Set<String>> positionVerticalGeneralRuleElementMap = (Map<String, Set<String>>) fetchAndReturnObjectFromTemporaryObjectMap(url, "positionVerticalGeneralRuleElementMap", runIdentifier);
				
				Map<String,Set<String>> positionVerticalDomainRuleElementMap = (Map<String, Set<String>>) fetchAndReturnObjectFromTemporaryObjectMap(url, "positionVerticalDomainRuleElementMap", runIdentifier);
				
				if(generalRuleBook != null && generalRule.containsKey(CONSTANTS.POSITION_ALIGNMENT_VERTICAL) && positionVerticalGeneralRuleElementMap.size() > 0 && positionVerticalGeneralRules != null) {
					isFalsePositivePositionVerticalGeneralRule = isFalsePositive(positionVerticalGeneralRules, positionVerticalGeneralRuleElementMap, reportJsonObject);
				}

				if(domainSpecificRuleBook != null && domainRule.containsKey(CONSTANTS.POSITION_ALIGNMENT_VERTICAL) && positionVerticalDomainRuleElementMap.size() > 0 && positionVerticalDomainRules != null) {
					isFalsePositivePositionVerticalDomainRule = isFalsePositive(positionVerticalDomainRules, positionVerticalDomainRuleElementMap, reportJsonObject);
				}

				if(isFalsePositivePositionVerticalGeneralRule || isFalsePositivePositionVerticalDomainRule) {
					reportJsonObject.remove(CONSTANTS.ISFALSEPOSITIVE);
					reportJsonObject.put(CONSTANTS.ISFALSEPOSITIVE, true);
				}

			}
			
			if(errorCaption.toLowerCase().contains(CONSTANTS.IMAGENOTLOADED)) {

				boolean isFalsePositiveImageNotLoadedGeneralRule = false;

				boolean isFalsePositiveImageNotLoadedDomainRule = false;

				Map<String,Set<String>> imageNotLoadedGeneralRuleElementMap = (Map<String, Set<String>>) fetchAndReturnObjectFromTemporaryObjectMap(url, "imageNotLoadedGeneralRuleElementMap", runIdentifier);
				
				Map<String,Set<String>> imageNotLoadedDomainRuleElementMap = (Map<String, Set<String>>) fetchAndReturnObjectFromTemporaryObjectMap(url, "imageNotLoadedDomainRuleElementMap", runIdentifier);
				
				if(generalRuleBook != null && generalRule.containsKey(CONSTANTS.CONFIGIMAGENOTLOADED) && imageNotLoadedGeneralRuleElementMap.size() > 0 && imageNotLoadedGeneralRules != null) {
					isFalsePositiveImageNotLoadedGeneralRule = isFalsePositive(imageNotLoadedGeneralRules, imageNotLoadedGeneralRuleElementMap, reportJsonObject);
				}

				if(domainSpecificRuleBook != null && domainRule.containsKey(CONSTANTS.CONFIGIMAGENOTLOADED) && imageNotLoadedDomainRuleElementMap.size() > 0 && imageNotLoadedDomainRules != null) {
					isFalsePositiveImageNotLoadedDomainRule = isFalsePositive(imageNotLoadedDomainRules, imageNotLoadedDomainRuleElementMap, reportJsonObject);
				}

				if(isFalsePositiveImageNotLoadedGeneralRule || isFalsePositiveImageNotLoadedDomainRule) {
					reportJsonObject.remove(CONSTANTS.ISFALSEPOSITIVE);
					reportJsonObject.put(CONSTANTS.ISFALSEPOSITIVE, true);
				}

			}
			
			if(errorCaption.toLowerCase().contains(CONSTANTS.IMAGELOWQUALITY)) {

				boolean isFalsePositiveImageLowQualityGeneralRule = false;

				boolean isFalsePositiveImageLowQualityDomainRule = false;

				Map<String,Set<String>> imageLowQualityGeneralRuleElementMap = (Map<String, Set<String>>) fetchAndReturnObjectFromTemporaryObjectMap(url, "imageLowQualityGeneralRuleElementMap", runIdentifier);
				
				Map<String,Set<String>> imageLowQualityDomainRuleElementMap = (Map<String, Set<String>>) fetchAndReturnObjectFromTemporaryObjectMap(url, "imageLowQualityDomainRuleElementMap", runIdentifier);
				
				if(generalRuleBook != null && generalRule.containsKey(CONSTANTS.CONFIGIMAGELOWQUALITY) && imageLowQualityGeneralRuleElementMap.size() > 0 && imageLowQualityGeneralRules != null) {
					isFalsePositiveImageLowQualityGeneralRule = isFalsePositive(imageLowQualityGeneralRules, imageLowQualityGeneralRuleElementMap, reportJsonObject);
				}

				if(domainSpecificRuleBook != null && domainRule.containsKey(CONSTANTS.CONFIGIMAGELOWQUALITY) && imageLowQualityDomainRuleElementMap.size() > 0 && imageLowQualityDomainRules != null) {
					isFalsePositiveImageLowQualityDomainRule = isFalsePositive(imageLowQualityDomainRules, imageLowQualityDomainRuleElementMap, reportJsonObject);
				}

				if(isFalsePositiveImageLowQualityGeneralRule || isFalsePositiveImageLowQualityDomainRule) {
					reportJsonObject.remove(CONSTANTS.ISFALSEPOSITIVE);
					reportJsonObject.put(CONSTANTS.ISFALSEPOSITIVE, true);
				}

			}
			
			if(errorCaption.toLowerCase().contains(CONSTANTS.IMAGEASPECTRATIO)) {

				boolean isFalsePositiveImageAspectRatioGeneralRule = false;

				boolean isFalsePositiveImageAspectRatioDomainRule = false;
				
				Map<String,Set<String>> imageAspectRatioGeneralRuleElementMap = (Map<String, Set<String>>) fetchAndReturnObjectFromTemporaryObjectMap(url, "imageAspectRatioGeneralRuleElementMap", runIdentifier);
				
				Map<String,Set<String>> imageAspectRatioDomainRuleElementMap = (Map<String, Set<String>>) fetchAndReturnObjectFromTemporaryObjectMap(url, "imageAspectRatioDomainRuleElementMap", runIdentifier);

				if(generalRuleBook != null && generalRule.containsKey(CONSTANTS.CONFIGIMAGEASPECTRATIO) && imageAspectRatioGeneralRuleElementMap.size() > 0 && imageAspectRatioGeneralRules != null) {
					isFalsePositiveImageAspectRatioGeneralRule = isFalsePositive(imageAspectRatioGeneralRules, imageAspectRatioGeneralRuleElementMap, reportJsonObject);
				}

				if(domainSpecificRuleBook != null && domainRule.containsKey(CONSTANTS.CONFIGIMAGEASPECTRATIO) && imageAspectRatioDomainRuleElementMap.size() > 0 && imageAspectRatioDomainRules != null) {
					isFalsePositiveImageAspectRatioDomainRule = isFalsePositive(imageAspectRatioDomainRules, imageAspectRatioDomainRuleElementMap, reportJsonObject);
				}

				if(isFalsePositiveImageAspectRatioGeneralRule || isFalsePositiveImageAspectRatioDomainRule) {
					reportJsonObject.remove(CONSTANTS.ISFALSEPOSITIVE);
					reportJsonObject.put(CONSTANTS.ISFALSEPOSITIVE, true);
				}

			}
			
			if(errorCaption.toLowerCase().replaceAll(CONSTANTS.EMPTYSTRINGWITHSPACE, CONSTANTS.EMPTYSTRING).contains(CONSTANTS.IMAGEBROKENLINK)) {

				boolean isFalsePositiveImageBrokenLinkGeneralRule = false;

				boolean isFalsePositiveImageBrokenLinkDomainRule = false;

				Map<String,Set<String>> imageBrokenLinkGeneralRuleElementMap = (Map<String, Set<String>>) fetchAndReturnObjectFromTemporaryObjectMap(url, "imageBrokenLinkGeneralRuleElementMap", runIdentifier);
				
				Map<String,Set<String>> imageBrokenLinkDomainRuleElementMap = (Map<String, Set<String>>) fetchAndReturnObjectFromTemporaryObjectMap(url, "imageBrokenLinkDomainRuleElementMap", runIdentifier);
				
				if(generalRuleBook != null && generalRule.containsKey(CONSTANTS.CONFIGIMAGEBROKENLINK) && imageBrokenLinkGeneralRuleElementMap.size() > 0 && imageBrokenLinkGeneralRules != null) {
					isFalsePositiveImageBrokenLinkGeneralRule = isFalsePositive(imageBrokenLinkGeneralRules, imageBrokenLinkGeneralRuleElementMap, reportJsonObject);
				}

				if(domainSpecificRuleBook != null && domainRule.containsKey(CONSTANTS.CONFIGIMAGEBROKENLINK) && imageBrokenLinkDomainRuleElementMap.size() > 0 && imageBrokenLinkDomainRules != null) {
					isFalsePositiveImageBrokenLinkDomainRule = isFalsePositive(imageBrokenLinkDomainRules, imageBrokenLinkDomainRuleElementMap, reportJsonObject);
				}

				if(isFalsePositiveImageBrokenLinkGeneralRule || isFalsePositiveImageBrokenLinkDomainRule) {
					reportJsonObject.remove(CONSTANTS.ISFALSEPOSITIVE);
					reportJsonObject.put(CONSTANTS.ISFALSEPOSITIVE, true);
				}
			}
			
			if(errorCaption.toLowerCase().replaceAll(CONSTANTS.EMPTYSTRINGWITHSPACE, CONSTANTS.EMPTYSTRING).contains(CONSTANTS.VIDEO)) {

				boolean isFalsePositiveVideoGeneralRule = false;

				boolean isFalsePositiveVideoDomainRule = false;

				Map<String,Set<String>> videoGeneralRuleElementMap = (Map<String, Set<String>>) fetchAndReturnObjectFromTemporaryObjectMap(url, "videoGeneralRuleElementMap", runIdentifier);
				
				Map<String,Set<String>> videoDomainRuleElementMap = (Map<String, Set<String>>) fetchAndReturnObjectFromTemporaryObjectMap(url, "videoDomainRuleElementMap", runIdentifier);
				
				if(generalRuleBook != null && generalRule.containsKey(CONSTANTS.CONFIGVIDEO) && videoGeneralRuleElementMap.size() > 0 && videoGeneralRules != null) {
					isFalsePositiveVideoGeneralRule = isFalsePositive(videoGeneralRules, videoGeneralRuleElementMap, reportJsonObject);
				}

				if(domainSpecificRuleBook != null && domainRule.containsKey(CONSTANTS.CONFIGVIDEO) && videoDomainRuleElementMap.size() > 0 && videoDomainRules != null) {
					isFalsePositiveVideoDomainRule = isFalsePositive(videoDomainRules, videoDomainRuleElementMap, reportJsonObject);
				}

				if(isFalsePositiveVideoGeneralRule || isFalsePositiveVideoDomainRule) {
					reportJsonObject.remove(CONSTANTS.ISFALSEPOSITIVE);
					reportJsonObject.put(CONSTANTS.ISFALSEPOSITIVE, true);
				}
			}
			
			if(errorCaption.toLowerCase().replaceAll(CONSTANTS.EMPTYSTRINGWITHSPACE, CONSTANTS.EMPTYSTRING).contains(CONSTANTS.CAROUSEL)) {

				boolean isFalsePositiveCarouselGeneralRule = false;

				boolean isFalsePositiveCarouselDomainRule = false;
				
				Map<String,Set<String>> carouselGeneralRuleElementMap = (Map<String, Set<String>>) fetchAndReturnObjectFromTemporaryObjectMap(url, "carouselGeneralRuleElementMap", runIdentifier);
				
				Map<String,Set<String>> carouselDomainRuleElementMap = (Map<String, Set<String>>) fetchAndReturnObjectFromTemporaryObjectMap(url, "carouselDomainRuleElementMap", runIdentifier);

				if(generalRuleBook != null && generalRule.containsKey(CONSTANTS.CONFIGCAROUSEL) && carouselGeneralRuleElementMap.size() > 0 && carouselGeneralRules != null) {
					isFalsePositiveCarouselGeneralRule = isFalsePositive(carouselGeneralRules, carouselGeneralRuleElementMap, reportJsonObject);
				}

				if(domainSpecificRuleBook != null && domainRule.containsKey(CONSTANTS.CONFIGCAROUSEL) && carouselDomainRuleElementMap.size() > 0 && carouselDomainRules != null) {
					isFalsePositiveCarouselDomainRule = isFalsePositive(carouselDomainRules, carouselDomainRuleElementMap, reportJsonObject);
				}

				if(isFalsePositiveCarouselGeneralRule || isFalsePositiveCarouselDomainRule) {
					reportJsonObject.remove(CONSTANTS.ISFALSEPOSITIVE);
					reportJsonObject.put(CONSTANTS.ISFALSEPOSITIVE, true);
				}
			}
			
			if(errorCaption.toLowerCase().replaceAll(CONSTANTS.EMPTYSTRINGWITHSPACE, CONSTANTS.EMPTYSTRING).contains(CONSTANTS.MENUHOVER)) {

				boolean isFalsePositiveMenuHoverGeneralRule = false;

				boolean isFalsePositiveMenuHoverDomainRule = false;

				Map<String,Set<String>> menuHoverGeneralRuleElementMap = (Map<String, Set<String>>) fetchAndReturnObjectFromTemporaryObjectMap(url, "menuHoverGeneralRuleElementMap", runIdentifier);
				
				Map<String,Set<String>> menuHoverDomainRuleElementMap = (Map<String, Set<String>>) fetchAndReturnObjectFromTemporaryObjectMap(url, "menuHoverDomainRuleElementMap", runIdentifier);
				
				if(generalRuleBook != null && generalRule.containsKey(CONSTANTS.CONFIGMENUHOVER) && menuHoverGeneralRuleElementMap.size() > 0 && menuHoverGeneralRules != null) {
					isFalsePositiveMenuHoverGeneralRule = isFalsePositive(menuHoverGeneralRules, menuHoverGeneralRuleElementMap, reportJsonObject);
				}

				if(domainSpecificRuleBook != null && domainRule.containsKey(CONSTANTS.CONFIGMENUHOVER) && menuHoverDomainRuleElementMap.size() > 0 && menuHoverDomainRules != null) {
					isFalsePositiveMenuHoverDomainRule = isFalsePositive(menuHoverDomainRules, menuHoverDomainRuleElementMap, reportJsonObject);
				}

				if(isFalsePositiveMenuHoverGeneralRule || isFalsePositiveMenuHoverDomainRule) {
					reportJsonObject.remove(CONSTANTS.ISFALSEPOSITIVE);
					reportJsonObject.put(CONSTANTS.ISFALSEPOSITIVE, true);
				}
			}
			
			if(errorCaption.toLowerCase().replaceAll(CONSTANTS.EMPTYSTRINGWITHSPACE, CONSTANTS.EMPTYSTRING).contains(CONSTANTS.PATTERNDIFF)) {

				boolean isFalsePositivePatternDiffGeneralRule = false;

				boolean isFalsePositivePatternDiffDomainRule = false;

				Map<String,Set<String>> patternDiffGeneralRuleElementMap = (Map<String, Set<String>>) fetchAndReturnObjectFromTemporaryObjectMap(url, "patternDiffGeneralRuleElementMap", runIdentifier);
				
				Map<String,Set<String>> patternDiffDomainRuleElementMap = (Map<String, Set<String>>) fetchAndReturnObjectFromTemporaryObjectMap(url, "patternDiffDomainRuleElementMap", runIdentifier);
				
				if(generalRuleBook != null && generalRule.containsKey(CONSTANTS.CONFIGPATTERNDIFF) && patternDiffGeneralRuleElementMap.size() > 0 && patternDiffGeneralRules != null) {
					isFalsePositivePatternDiffGeneralRule = isFalsePositive(patternDiffGeneralRules, patternDiffGeneralRuleElementMap, reportJsonObject);
				}

				if(domainSpecificRuleBook != null && domainRule.containsKey(CONSTANTS.CONFIGPATTERNDIFF) && patternDiffDomainRuleElementMap.size() > 0 && patternDiffDomainRules != null) {
					isFalsePositivePatternDiffDomainRule = isFalsePositive(patternDiffDomainRules, patternDiffDomainRuleElementMap, reportJsonObject);
				}

				if(isFalsePositivePatternDiffGeneralRule || isFalsePositivePatternDiffDomainRule) {
					reportJsonObject.remove(CONSTANTS.ISFALSEPOSITIVE);
					reportJsonObject.put(CONSTANTS.ISFALSEPOSITIVE, true);
				}
			}
			
			if(errorCaption.replaceAll(CONSTANTS.EMPTYSTRINGWITHSPACE, CONSTANTS.EMPTYSTRING).contains(CONSTANTS.FONTVALIDATION)) {

				boolean isFalsePositiveFontValidationGeneralRule = false;

				boolean isFalsePositiveFontValidationDomainRule = false;

				Map<String,Set<String>> fontValidationGeneralRuleElementMap = (Map<String, Set<String>>) fetchAndReturnObjectFromTemporaryObjectMap(url, "fontValidationGeneralRuleElementMap", runIdentifier);
				
				Map<String,Set<String>> fontValidationDomainRuleElementMap = (Map<String, Set<String>>) fetchAndReturnObjectFromTemporaryObjectMap(url, "fontValidationDomainRuleElementMap", runIdentifier);
				
				if(generalRuleBook != null && generalRule.containsKey(CONSTANTS.FONTVALIDATION) && fontValidationGeneralRuleElementMap.size() > 0 && fontValidationGeneralRules != null) {
					isFalsePositiveFontValidationGeneralRule = isFalsePositive(fontValidationGeneralRules, fontValidationGeneralRuleElementMap, reportJsonObject);
				}

				if(domainSpecificRuleBook != null && domainRule.containsKey(CONSTANTS.CONFIGFONTVALIDATION) && fontValidationDomainRuleElementMap.size() > 0 && fontValidationDomainRules != null) {
					isFalsePositiveFontValidationDomainRule = isFalsePositive(fontValidationDomainRules, fontValidationDomainRuleElementMap, reportJsonObject);
				}

				if(isFalsePositiveFontValidationGeneralRule || isFalsePositiveFontValidationDomainRule) {
					reportJsonObject.remove(CONSTANTS.ISFALSEPOSITIVE);
					reportJsonObject.put(CONSTANTS.ISFALSEPOSITIVE, true);
				}
			}
			
			if(errorCaption.replaceAll(CONSTANTS.EMPTYSTRINGWITHSPACE, CONSTANTS.EMPTYSTRING).contains(CONSTANTS.SPELLCHECKER)) {

				boolean isFalsePositiveSpellCheckerGeneralRule = false;

				boolean isFalsePositiveSpellCheckerDomainRule = false;

				Map<String,Set<String>> spellCheckerGeneralRuleElementMap = (Map<String, Set<String>>) fetchAndReturnObjectFromTemporaryObjectMap(url, "spellCheckerGeneralRuleElementMap", runIdentifier);
				
				Map<String,Set<String>> spellCheckerDomainRuleElementMap = (Map<String, Set<String>>) fetchAndReturnObjectFromTemporaryObjectMap(url, "spellCheckerDomainRuleElementMap", runIdentifier);
				
				if(generalRuleBook != null && generalRule.containsKey(CONSTANTS.CONFIGSPELLCHECKER) && spellCheckerGeneralRuleElementMap.size() > 0 && spellCheckerGeneralRules != null) {
					isFalsePositiveSpellCheckerGeneralRule = isFalsePositive(spellCheckerGeneralRules, spellCheckerGeneralRuleElementMap, reportJsonObject);
				}

				if(domainSpecificRuleBook != null && domainRule.containsKey(CONSTANTS.CONFIGSPELLCHECKER) && spellCheckerDomainRuleElementMap.size() > 0 && spellCheckerDomainRules != null) {
					isFalsePositiveSpellCheckerDomainRule = isFalsePositive(spellCheckerDomainRules, spellCheckerDomainRuleElementMap, reportJsonObject);
				}

				if(isFalsePositiveSpellCheckerGeneralRule || isFalsePositiveSpellCheckerDomainRule) {
					reportJsonObject.remove(CONSTANTS.ISFALSEPOSITIVE);
					reportJsonObject.put(CONSTANTS.ISFALSEPOSITIVE, true);
				}
			}

		}

		return reportJsonObject;
	}
	
	/**
	 *  Method to add domain specific rule book temporary objects
	 * @param generalRules
	 * @param ruleElementMap
	 * @param errorObject
	 * @return
	 */
	private boolean isFalsePositive(List<Map<String,String>> generalRules, Map<String,Set<String>> ruleElementMap, JSONObject errorObject) {

		int index = 0;

		for(Map<String,String> rule : generalRules) {

			int matchedElementCount = 0;

			Set<String> ruleElementArray = ruleElementMap.get(String.valueOf(index));

			for(String ruleElement: ruleElementArray) {

				if((errorObject.has(ruleElement) && rule.containsKey(ruleElement)) && 
						(errorObject.get(ruleElement).equals(rule.get(ruleElement)))) {
					matchedElementCount++;
				}
			}

			if(matchedElementCount == rule.size()) {
				return true;
			}

			index++;
		}

		return false;
	}
	
	/**
	 * Method used to fetch temporary object from map 
	 * @param url
	 * @param keyIdentifier
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private Object fetchAndReturnObjectFromTemporaryObjectMap(String url, String keyIdentifier, String runIdentifier) {
		
		try {
			
			Map<String, Object> temporayDomainObject = (Map<String, Object>) temporaryObjectMap.get(url + runIdentifier);
			
			return temporayDomainObject.get(keyIdentifier);
			
		} catch (Exception e) {
			LOGGER.error("Error Occured while fetching temporary object for false positive analysis service. URL"+ url + "with identifier " + runIdentifier + ", Key Identifier" + keyIdentifier);
			return null;
			
		}
		
	}
	
	
	/**
	 * Method used to create Report Object and save it in temporary map
	 * @param url
	 * @param runIdentifier
	 * @return
	 */
	public Report fetchOrCreateReportObjectFromTemporaryReportMap(String url, String runIdentifier) {
		
		Report report = null;
		
		if(temporaryReportObjectMap.containsKey(url + runIdentifier)) {
			
			report = temporaryReportObjectMap.get(url + runIdentifier);
			
		} else {
			
			report = reportRepository.findByRunIdentifier(runIdentifier);
			
			if(Util.isEmpty(report)) {
				
				report = createNewReportObject(url, runIdentifier);
				
			} 
			
			temporaryReportObjectMap.put(url + runIdentifier, report);
			
		}
		
		return report;
	}
	
	/**
	 * Adding report object to temporary report map
	 * @param url
	 * @param report
	 */
	private void addReportToTemporaryReportMap(String url, Report report) {
		
		temporaryReportObjectMap.put(url + report.getRunIdentifier(), report);
	}
	
	
	/**
	 * Method used to create new report object
	 * @param url
	 * @param runIdentifier
	 * @return
	 */
	private Report createNewReportObject(String url, String runIdentifier) {
		
		Report report = new Report();
		
		report.set_id(Util.generateMongoID());
		
		report.setCreatedDate(Util.getDateWithTimeAsDate());
		
		report.setPageURL(url);
		
		report.setRunIdentifier(runIdentifier);
		
		return report;
	}
	
	
	/**
	 * Method used to remove objects after validation is completed
	 * @param url
	 */
	public void removeObjectFromTemporaryObjectMap(String url, String runIdentidier) {
		
		temporaryObjectMap.remove(url + runIdentidier);
		
		temporaryReportObjectMap.remove(url + runIdentidier);
		
	}
	
	
	/**
	 * Adding Report to DB
	 * @param url
	 */
	public void addReportToDB(String url, Report report, JSONObject issuesCountObj) {
		
		report = accessibilityFormConfigValuesFromPageJsonAndAddItToReport(report,issuesCountObj);
		
		if(Util.isEmpty(report.getScreenShotURL())) {
			
			String _screenShotURL = screenShotURL + "/" + screenShotBaseDir + "/" + report.getRunIdentifier() + ".png"; 
			
			/** String _screenShotURL = "C:/apache-tomcat-10.0.2/webapps/aqavScreenshots" + "/" + report.getRunIdentifier() + ".png"; */
			
			String screenShotAbsPath = screenShotPath + "\\" + report.getRunIdentifier() + ".png";
			
			report.setScreenShotAbsolutePath(screenShotAbsPath);
			
			report.setScreenShotURL(_screenShotURL);
			
		}
		
		addReportToTemporaryReportMap(url, report);
		
		insertOrUpdateReportObject(report);
		
	}
	
	/**
	 * Method for creating element label map from rule book
	 * @param elementMap
	 * @param ruleBook
	 * @param errorName
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private Map<String,Set<String>> createElementMap(Map<String,Set<String>> elementMap, RuleBook ruleBook, String errorName){
		
		int index = 0;
		
		for(Map<String, String> positionHorizontalGeneralRule : (List<Map<String, String>>) ruleBook.getRule().get(errorName)) {
			elementMap.put(String.valueOf(index), positionHorizontalGeneralRule.keySet());
			index++;
		}
		
		return elementMap;
	}
	
	/**
	 * Method used to form config values of the report
	 * @param report
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private Report formConfigValuesFromPageJsonAndAddItToReport(Report report) {
		
		List<String> errorNames = new ArrayList<String>();
		
		List<String> falsePositiveErrorNames = new ArrayList<String>();
		
		Map<String,Object> configObjMap = new HashMap<String, Object>();
		
		Map<String, Object> pageObject = report.getReportObject().get("page"+ report.getRunIdentifier());
		
		for(String key : pageObject.keySet()) {
			
			Map<String,Object> reportValueMap = (Map<String, Object>) pageObject.get(key);
			
			if((Boolean) reportValueMap.get(CONSTANTS.ISFALSEPOSITIVE)) {
				
				falsePositiveErrorNames.add(key.split("__")[0]);
				
			} else {//nr
				errorNames.add(key.split("__")[0]);
			}
		}
		
		Map<String, Integer> occurrencesMap=getConfigurationErrorDetails(errorNames);
		
		Map<String, Integer> falsePositiveOccurrencesMap = getConfigurationErrorDetails(falsePositiveErrorNames);
		
		if(!occurrencesMap.isEmpty()) {

			int sum = occurrencesMap.values().stream().reduce(0, Integer::sum);
			
			Map<String,Integer> falsePositiveErrorCountDetailsMap = new HashMap<String, Integer>();
			
			configObjMap.put("Error Count", sum);
			
			configObjMap.put("pageUrl", report.getPageURL());
			
			for(Entry<String, Integer> obj : occurrencesMap.entrySet()) {//nr
				
				configObjMap.put(obj.getKey().replaceAll("\\s",""), obj.getValue());

			}
			
			for(Entry<String, Integer> obj : falsePositiveOccurrencesMap.entrySet()) {
				
				falsePositiveErrorCountDetailsMap.put(obj.getKey().replaceAll("\\s",""), obj.getValue());
				
			}
			
			configObjMap.put("falsePositiveErrorCounts", falsePositiveErrorCountDetailsMap);
		}
		
		if(!Util.isEmpty(configObjMap)) {
			report.getReportObject().put("Conf_page" + report.getRunIdentifier(), configObjMap);
		}
		return report;
	}
	
	/**
	 * Method use to insert or update the report collection
	 * @param report
	 */
	private void insertOrUpdateReportObject(Report report) {
		
		reportRepository.save(report);
	}
	
	
	/**
	 * Method used to find the occurrence of the value
	 * @param objErrorNameConfiguration
	 * @return
	 */
	private static Map<String, Integer> getConfigurationErrorDetails(List<String> objErrorNameConfiguration) {

		Map<String, Integer> occurrences = new HashMap<String, Integer>();

		if(!objErrorNameConfiguration.isEmpty())
		{
			for ( String word : objErrorNameConfiguration ) {
				Integer oldCount = occurrences.get(word);
				if ( oldCount == null ) {
					oldCount = 0;
				}
				occurrences.put(word, oldCount + 1);
			}
		}
		
		return occurrences;
	}
	
	/**
	 * Method used to send the categorization response to centralized server
	 * @param url
	 * @param json
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public  String sendResponseToMicroService(String url, String json, RequestMethod requestMethod){
		
		String output = null;
		
		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
		
		SSLContextBuilder sslContextBuilder = new SSLContextBuilder();
		
		CloseableHttpClient httpClient = null;
		
		RestTemplate restTemplate;
		
		Map<String,Object> result;
		
		SSLConnectionSocketFactory sslConnectionSocketFactory;
		
		try {
			sslContextBuilder.loadTrustMaterial(null, new TrustStrategy() {
				@Override
				public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException {
					return true;
				}
			});
			
			sslConnectionSocketFactory = new SSLConnectionSocketFactory(sslContextBuilder.build());
			
			httpClient = HttpClients.custom().setSSLSocketFactory(sslConnectionSocketFactory).build();
			
			requestFactory.setHttpClient(httpClient);
			
			HttpHeaders headers = new HttpHeaders();
			
			headers.add("Content-Type", "application/json");
			
			restTemplate = new RestTemplate(requestFactory);
			
			HttpEntity<String> entity = new HttpEntity<String>(json, headers);
			
			if(requestMethod.equals(RequestMethod.POST)) {
				
				result = restTemplate.postForObject(url, entity , Map.class, " ");
				
			} else {
				result = restTemplate.exchange(url, HttpMethod.GET, entity, Map.class).getBody();
			}

			if (!Util.isEmpty(result)) {
				Map<String,Object> response = (Map<String, Object>) result.get("response");
				output =  (String) response.get("param"); 
			} 
			
			if(Util.isEmpty(output)) {
				LOGGER.error("Response is empty for the validation. URL:"+ url + ", request:"+ json);
			}
			
		} catch (NoSuchAlgorithmException | KeyStoreException | KeyManagementException e) {
			
			LOGGER.error("Error Occured while sending response to microservice. URL: "+ url + ", Request: " + json );
			return null;
			
		}finally {
			try {
				requestFactory.destroy();
				HttpClientUtils.closeQuietly(httpClient);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				LOGGER.error("Error Occured while closing the http client in sendResponseToMicroservice. URL: "+ url + ", Request: " + json );
			}
		}
		
		
		return output;
	}
	
	/**
	 * Method to crop and send base 64 image to OCR for secondary validation
	 * 
	 * @param validationJsonObj
	 * @param bodyWidth
	 * @param bodyHeight
	 * @param runIdentifier
	 * @param url
	 * @return
	 */
	public JSONObject cropAndSendBase64ImageToOCRService(JSONObject validationJsonObj, int bodyWidth, int bodyHeight, String runIdentifier, String url, String issueId) {
		
		String screenShotAbsPath = screenShotPath + File.separator + runIdentifier + ".png";
		
		int cropX = requiredValueFromValidationJson(validationJsonObj, "X");
		int cropY = requiredValueFromValidationJson(validationJsonObj, "Y");
		int cropWidth = requiredValueFromValidationJson(validationJsonObj, "Width");
		int cropHeight = requiredValueFromValidationJson(validationJsonObj, "Height");
		
		String ocrCategoryFromReportJson = getOCRCategoryFromReportJson(validationJsonObj);
		
		String base64Image = cropImageAndSendBase64Image(screenShotAbsPath, bodyWidth, bodyHeight, cropX, cropY, cropWidth, cropHeight, ocrCategoryFromReportJson);
		
		if(!Util.isEmpty(base64Image)) {
			
			if(!base64Image.equals(CONSTANTS.LESSWIDTHANDHEIGHTTOCROP)) {
				
				String requestBody = "{\"image\":\""+ base64Image +"\"}";
				
				String ocrResponse = sendResponseToMicroService(ocrServiceURL, requestBody, RequestMethod.POST);
				
				validationJsonObj = analyseOCRResultWithActualContent(validationJsonObj, ocrResponse, runIdentifier, url);
				
			} else {
				
				LOGGER.info("Image CROP width and height is less than tolerance. RunIdentifier" + runIdentifier + ", Issue ID" + issueId + ", URL" + url);
				
			}

		}
		
		return validationJsonObj;
		
	}
	
	
	/**
	 * Crop the image and return base64 string
	 * @param srcFilePath
	 * @param scaledWidth
	 * @param scaledHeight
	 * @param cropX
	 * @param cropY
	 * @param cropWidth
	 * @param cropHeight
	 * @return
	 */
	public String cropImageAndSendBase64Image(String srcFilePath, int scaledWidth, int scaledHeight, int cropX, int cropY, int cropWidth, int cropHeight, String ocrCategoryFromReportJson) {
		
		final ByteArrayOutputStream os = new ByteArrayOutputStream();
		
		File srcFile = new File(srcFilePath);
		
		boolean needToCropImage = true;
		
		String response = null;
		
		try {
			
			BufferedImage primaryImage = ImageIO.read(srcFile);
			
			String osName = System.getProperty("os.name");
			
			if(osName.equals("Linux")) {
				
				System.setProperty("java.awt.headless", "true");
				
			} else {
				
				System.setProperty("java.awt.headless", "false");
				
			}
			
			BufferedImage croppedImage = primaryImage.getSubimage(cropX, cropY, cropWidth, cropHeight);
			
			int croppedImageWidth = croppedImage.getWidth();
			
			int croppedImageHeight = croppedImage.getHeight();
		
			if(!Util.isEmpty(ocrCategoryFromReportJson)) {
				
				if(ocrCategoryFromReportJson.equals(CONSTANTS.IMAGEONTEXT)) {
					
					if((croppedImageWidth < Integer.parseInt(croppedImageMinimumWidth)) 
					&& (croppedImageHeight < Integer.parseInt(croppedImageMinimumHeight))) {
						
						needToCropImage = false;
						
						response = CONSTANTS.LESSWIDTHANDHEIGHTTOCROP;
					}
				}
			}
			
			if(needToCropImage) {
				
				ImageIO.write(croppedImage, "PNG", os);
				
				return Base64.getEncoder().encodeToString(os.toByteArray());
				
			}
			
		} catch (Exception e) {
			
			e.printStackTrace();
			
			LOGGER.error("Exception happend while croping the image.Image srcPath:"+ srcFilePath + ". exception :" + e.getMessage());
		}
		
		return response;
	}
	
	/**
	 * Method to get required value from validation JSON based on category whether it is image on text or text on text 
	 * @param validationJson
	 * @param valueNeeded
	 * @return
	 */
	public int requiredValueFromValidationJson(JSONObject validationJson, String valueNeeded) {
		
		String[] words = {"icon", "img", "text"};
		
	    List<String> ignoreList = Arrays.asList(words);
	    
	    int value = 0;
	    
		if(validationJson.get(CONSTANTS.ELEMENTCATEGORY).toString().equals(CONSTANTS.TEXTONIMAGE)  
				||  validationJson.get(CONSTANTS.ELEMENTCATEGORY).toString().equals(CONSTANTS.IMAGEONTEXT) 
				|| validationJson.get(CONSTANTS.ELEMENTCATEGORY).toString().equals(CONSTANTS.ICONONTEXT)
				|| validationJson.get(CONSTANTS.ELEMENTCATEGORY).toString().equals(CONSTANTS.TEXTONICON) 
				|| !ignoreList.contains(validationJson.get("Element1TagName").toString())
				|| (!ignoreList.contains(validationJson.get("Element2TagName").toString()) )){
			
			value = Math.round(Math.abs(Float.parseFloat(validationJson.get("IntersectionValue" + valueNeeded).toString() )));

		}
		
		else if((validationJson.get(CONSTANTS.ELEMENTCATEGORY).toString().equals(CONSTANTS.TEXTONTEXT)) 
				|| (validationJson.get("Element1Text").toString() !="EmptyString" 
				&& validationJson.get("Element2Text").toString()!= "EmptyString") ){
			
			value = Math.round(Math.abs(Float.parseFloat(validationJson.get("UnionValue" + valueNeeded).toString())));
		}
		
		return value;
		
	}
	
	/**
	 * Method will returns the OCR category from Report JSON. It will return null if category is not found.
	 * @param validationJson
	 * @return
	 */
	private String getOCRCategoryFromReportJson(JSONObject validationJson) {
		
		if(validationJson.get(CONSTANTS.ELEMENTCATEGORY).toString().equals(CONSTANTS.TEXTONIMAGE)  
				|| validationJson.get(CONSTANTS.ELEMENTCATEGORY).toString().equals(CONSTANTS.IMAGEONTEXT) 
				|| validationJson.get(CONSTANTS.ELEMENTCATEGORY).toString().equals(CONSTANTS.ICONONTEXT)
				|| validationJson.get(CONSTANTS.ELEMENTCATEGORY).toString().equals(CONSTANTS.TEXTONICON) 
				|| (validationJson.get("Element1Text").toString() =="EmptyString" && validationJson.get("Element2Text").toString()!= "EmptyString") 
				|| (validationJson.get("Element1Text").toString() !="EmptyString" && validationJson.get("Element2Text").toString() == "EmptyString")) {
			
			return CONSTANTS.IMAGEONTEXT;
			
		}
		
		if((validationJson.get(CONSTANTS.ELEMENTCATEGORY).toString().equals(CONSTANTS.TEXTONTEXT)) 
				|| (validationJson.get("Element1Text").toString() !="EmptyString" && validationJson.get("Element2Text").toString()!= "EmptyString") ){
			
			return CONSTANTS.TEXTONTEXT;
		}
		
		return null;
	}
	
	/**
	 * Method to analyze the OCR result with actual result
	 * @param validationJson
	 * @param ocrTextList
	 * @param runIdentifier
	 * @param url
	 * @return
	 */
	private JSONObject analyseOCRResultWithActualContent(JSONObject validationJson, String ocrText, String runIdentifier, String url) {
		
		String ocrCategoryFromReportJson = getOCRCategoryFromReportJson(validationJson);
		
		if(!Util.isEmpty(ocrCategoryFromReportJson)) {
			
			if(ocrCategoryFromReportJson.equals(CONSTANTS.IMAGEONTEXT)) {
				
				validationJson = imageOnText(validationJson, ocrText, runIdentifier, url);
				
			} 
			
			if(ocrCategoryFromReportJson.equals(CONSTANTS.TEXTONTEXT)){
				
				validationJson = textOnText(validationJson, ocrText, runIdentifier, url);
				
			}
		}
		
		return validationJson;
	}
	
	/**
	 * Support method for analyzing image on text category
	 * @param validationJson
	 * @param ocrTextList
	 * @param runIdentifier
	 * @param url
	 * @return
	 */
	@SuppressWarnings("deprecation")
	private JSONObject imageOnText(JSONObject validationJson, String ocrText, String runIdentifier, String url) {
		
		if(!Util.isEmpty(ocrText) ){
			
			String element1Text = validationJson.get("Element1Text").toString();
			
			String element2Text = validationJson.get("Element2Text").toString();
			
			String locator = null;
			
			if(validationJson.has("locator")) {
				locator = validationJson.getString("locator");
			}
			
			double thresh=0.90;
			
			double distance1 = StringUtils.getJaroWinklerDistance(element1Text.toLowerCase(), ocrText.toLowerCase());
			double distance2 = StringUtils.getJaroWinklerDistance(element2Text.toLowerCase(), ocrText.toLowerCase());
			
			if(!element1Text.isEmpty() && !element1Text.equals("EmptyString")) {

				if(distance1 >= thresh) {

					validationJson.remove(CONSTANTS.ISFALSEPOSITIVE);
					validationJson.put(CONSTANTS.ISFALSEPOSITIVE, true);
					LOGGER.info("INFO: OCR --Text on Image --Not Marked as Error. Run Identifier"+ runIdentifier + ", URL:" + url + ",Locator:" + locator + ", OCR Text" + ocrText);
				} else {
					//element is not  false positive i.e error

					LOGGER.info("INFO: OCR --Text on Image --Marked as Error. Run Identifier"+ runIdentifier + ", URL:" + url + ",Locator:" + locator + ", OCR Text" + ocrText);
				}

			} else if(!element2Text.isEmpty() && !element2Text.equals("EmptyString")) {

				if(distance2 >= thresh) {

					validationJson.remove(CONSTANTS.ISFALSEPOSITIVE);
					validationJson.put(CONSTANTS.ISFALSEPOSITIVE, true);
					LOGGER.info("INFO: OCR --Text on Image --Not Marked as Error. Run Identifier"+ runIdentifier + ", URL:" + url + ",Locator:" + locator + ", OCR Text" + ocrText);
				} else {
					//element is not  false positive i.e error
					LOGGER.info("INFO: OCR --Text on Image --Marked as Error. Run Identifier"+ runIdentifier + ", URL:" + url + ",Locator:" + locator + ", OCR Text" + ocrText);
				}

			}
		}
		
		return validationJson;
	}
	
	/**
	 * Support method for analyzing text on text category
	 * @param validationJson
	 * @param ocrTextList
	 * @param runIdentifier
	 * @param url
	 * @return
	 */
	@SuppressWarnings("deprecation")
	private JSONObject textOnText(JSONObject validationJson, String ocrText, String runIdentifier, String url) {
		
		String locator = null;
		
		if(validationJson.has("locator")) {
			locator = validationJson.getString("locator");
		}
		
		if(!ocrText.contains("--Exception--") && !Util.isEmpty(ocrText)) {
			
			String element1Text = validationJson.get("Element1Text").toString();
			
			String element2Text = validationJson.get("Element2Text").toString();	

			double thresh=0.90;

			String replaceOCRText = new String(ocrText);
			
			//check text ratio
			replaceOCRText.replace(element1Text, "");		

			replaceOCRText.replace(element2Text, "");

			int ocrTextLength = replaceOCRText.length();

			String combinedElementText = element1Text + " "+ element2Text;
			
			double combinedTextRatio = (combinedElementText.length() * 20)/ 100;
			
			int combinedTextlenghth = (int) (combinedElementText.length() + combinedTextRatio);
			
			if(!Util.isEmpty(element1Text) && !Util.isEmpty(element2Text)) {
				
				if(ocrTextLength < combinedTextlenghth) {
	
					String combinedText=element1Text+" "+element2Text;
					
					double distance1 = StringUtils.getJaroWinklerDistance(combinedText.toLowerCase(), ocrText.toLowerCase());
					
					if(distance1 >= thresh){

						validationJson.remove(CONSTANTS.ISFALSEPOSITIVE);
						
						validationJson.put(CONSTANTS.ISFALSEPOSITIVE, true);
						
						LOGGER.info("INFO: OCR --Text on Text 3 --Not Marked as Error. Run Identifier"+ runIdentifier + ", URL:" + url + ",Locator:" + locator + ", OCR Text" + ocrText);

					} else {
						// mark it as error 

						LOGGER.info("INFO: OCR --Text on Text --Marked  as Error. Run Identifier"+ runIdentifier + ", URL:" + url + ",Locator:" + locator + ", OCR Text" + ocrText);
					}
					
				} else {
					//mark Fp to true 
					LOGGER.info("INFO: OCR -- Sentence Case. Run Identifier"+ runIdentifier + ", URL:" + url + ",Locator:" + locator + ", OCR Text" + ocrText);
					
					validationJson.remove(CONSTANTS.ISFALSEPOSITIVE);
					
					validationJson.put(CONSTANTS.ISFALSEPOSITIVE, true);
				}
				
			} else {
				
				LOGGER.error("INFO: OCR -- One of the Text is missing . Run Identifier"+ runIdentifier + ", URL:" + url + ",Locator:" + locator + ", Text 1" + element1Text + ", Text 2" + element2Text);
				
			}	
			
		} else {
			//mark Fp to true 
			LOGGER.info("INFO:Empty OCR --. OCR --Text on Text --OCR FAIL . Run Identifier"+ runIdentifier + ", URL:" + url + ",Locator:" + locator + ", OCR Text" + ocrText);
			
		}
		
		return validationJson;
	}
	
	/**
	 * Method to ignore particular issue or all similar type issue from validated report by user 
	 * @param isIgnoreAll
	 * @param report
	 * @param issueId
	 * @param configuration
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public Report ignoreOneOrAll(boolean isIgnoreAll, Report report, String issueId, Map<String,Object> configuration, String validationCategoryConfigurationLabel) {
		
		String pageObjectKey = reportPageObjectStaticKey + report.getRunIdentifier();
		
		String configObjectKey = reportConfigObjectStaticKey + pageObjectKey;
		
		String validationCategoryName = issueId.split(validationCategoryNameSplitter)[0];		
		
		Map<String,Object> reportPageObject = report.getReportObject().get(pageObjectKey);	
					
		Map<String,Object> reportConfigObject = report.getReportObject().get(configObjectKey);
		
		Map<String, Object> labelsObject = (Map<String, Object>) configuration.get(CONSTANTS.LABELS);
		
		Map<String, Object> issueCheckLabelsMapInConfiguration = (Map<String, Object>) labelsObject.get(validationCategoryConfigurationLabel);
		
		List<String> issueCheckLabelsInConfiguration = null;
		
		if(isIgnoreAll) {
			
			issueCheckLabelsInConfiguration = (List<String>) issueCheckLabelsMapInConfiguration.get(CONSTANTS.IGNOREALL);
			
			List<String> issueIdList = (List<String>) report.getReportObjectMetaData().get(validationCategoryName);
			
			report = ignoreAllSimilarIssue(reportPageObject, reportConfigObject, issueIdList, issueCheckLabelsInConfiguration, issueId, report, pageObjectKey, configObjectKey, validationCategoryName, configuration, validationCategoryConfigurationLabel);
			
		} else {
			
			report = ignoreParticularIssue(reportPageObject, reportConfigObject, report, pageObjectKey, configObjectKey, validationCategoryName, issueId, configuration, validationCategoryConfigurationLabel);
		}
		
		insertOrUpdateReportObject(report);
		
		return report;
	}
	
	/**
	 * Support method to ignore all similar issues from validated report by user
	 * @param reportPageObject
	 * @param reportConfigObject
	 * @param issueIdList
	 * @param issueCheckLabelsInConfiguration
	 * @param userIgnoredIssueId
	 * @param report
	 * @param pageObjectKey
	 * @param configObjectKey
	 * @param validationCategoryName
	 * @param configuration
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private Report ignoreAllSimilarIssue(Map<String, Object> reportPageObject, Map<String,Object> reportConfigObject,
										List<String> issueIdList, List<String> issueCheckLabelsInConfiguration,
										String userIgnoredIssueId, Report report, String pageObjectKey, String configObjectKey,
										String validationCategoryName, Map<String,Object> configuration, String validationCategoryConfigurationLabel) {
		
		Map<String, Object> _reportPageObject = new HashMap<String, Object>(reportPageObject);
		
		Map<String, Object> referenceReportIssueObject = (Map<String, Object>) _reportPageObject.get(userIgnoredIssueId);
		
		int similarIssueCount = 0;
		
		for(String issueIdinList: issueIdList) {
			
			Map<String, Object> reportIssueObject =  (Map<String, Object>) _reportPageObject.get(issueIdinList);
			
			boolean isSameTypeOfIssue = isSameTypeOfIssue(referenceReportIssueObject, reportIssueObject, issueCheckLabelsInConfiguration);
			
			if(isSameTypeOfIssue) {
				
				reportPageObject = addFalsePositiveFlagToReportJSON(reportIssueObject, reportPageObject, issueIdinList);
				
				similarIssueCount ++;
			}
		}
		
		report.getReportObject().remove(pageObjectKey);
		
		report.getReportObject().put(pageObjectKey,reportPageObject);
		
		reportConfigObject = updateIgnoreCountInReportConfig(reportConfigObject, validationCategoryName, similarIssueCount);
		
		report.getReportObject().remove(configObjectKey);
		
		report.getReportObject().put(configObjectKey, reportConfigObject);
		
		addRuleToDomainSpecificRuleBook(report.getPageURL(), referenceReportIssueObject, userIgnoredIssueId, true, configuration, validationCategoryConfigurationLabel);
		
		return report;
	}
	
	/**
	 * Support method to ignore particular issue from validated report by user
	 * @param reportPageObject
	 * @param reportConfigObject
	 * @param report
	 * @param pageObjectKey
	 * @param configObjectKey
	 * @param validationCategoryName
	 * @param issueId
	 * @param configuration
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private Report ignoreParticularIssue(Map<String, Object> reportPageObject, Map<String, Object> reportConfigObject,
			Report report, String pageObjectKey, String configObjectKey, String validationCategoryName, String issueId,
			Map<String, Object> configuration, String validationCategoryConfigurationLabel) {

		Map<String, Object> reportIssueObject = (Map<String, Object>) reportPageObject.get(issueId);

		reportPageObject = addFalsePositiveFlagToReportJSON(reportIssueObject, reportPageObject, issueId);

		report.getReportObject().remove(pageObjectKey);

		report.getReportObject().put(pageObjectKey, reportPageObject);

		reportConfigObject = updateIgnoreCountInReportConfig(reportConfigObject, validationCategoryName, 1);

		report.getReportObject().remove(configObjectKey);

		report.getReportObject().put(configObjectKey, reportConfigObject);

		addRuleToDomainSpecificRuleBook(report.getPageURL(), reportIssueObject, issueId, false, configuration,
				validationCategoryConfigurationLabel);

		return report;
	}
	
	/**
	 * Method to check whether the passed issue object is same as reference issue object with configured labels
	 * 
	 * This is the support method for ignoreAllParticular issue method
	 *  
	 * @param referenceReportIssueObject
	 * @param reportIssueObject
	 * @param issueCheckLabelsInConfiguration
	 * @return
	 */
	private boolean isSameTypeOfIssue(Map<String, Object> referenceReportIssueObject,
									  Map<String, Object> reportIssueObject, List<String> issueCheckLabelsInConfiguration) {

		boolean isSimilarObject = false;

		for (String label : issueCheckLabelsInConfiguration) {

			String referenceLabel = (referenceReportIssueObject.get(label) != null)
					? referenceReportIssueObject.get(label).toString()
					: "0";

			String objectLabel = (reportIssueObject.get(label) != null) ? reportIssueObject.get(label).toString() : "0";

			if (!objectLabel.equals(referenceLabel)) {

				isSimilarObject = false;

				break;

			}

			else {

				isSimilarObject = true;

			}
		}

		return isSimilarObject;
	}
	
	/**
	 * Method to add falsePositive flag to true whenever user is ignoring the issue
	 * @param validatedResultReportValue
	 * @param reportPageObject
	 * @param issueId
	 * @return
	 */
	private Map<String,Object> addFalsePositiveFlagToReportJSON(Map<String,Object> validatedResultReportValue, Map<String,Object> reportPageObject, String issueId) {
		
		validatedResultReportValue.remove(CONSTANTS.ISFALSEPOSITIVE);

		validatedResultReportValue.put(CONSTANTS.ISFALSEPOSITIVE, true);

		validatedResultReportValue.remove(CONSTANTS.ISUSERREMOVED);

		validatedResultReportValue.put(CONSTANTS.ISUSERREMOVED, true);

		reportPageObject.remove(issueId);

		reportPageObject.put(issueId, validatedResultReportValue);
		
		return reportPageObject;
	}
	
	/**
	 * Method to updating the ignored count in configuration object
	 * @param reportConfigObject
	 * @param validationCategoryName
	 * @param ignoredCount
	 * @return
	 */
	private Map<String,Object> updateIgnoreCountInReportConfig(Map<String,Object> reportConfigObject, String validationCategoryName, Integer ignoredCount){
		
		Integer newValidationCategoryCount =  Integer.parseInt(reportConfigObject.get(validationCategoryName).toString()) - ignoredCount;
		
		reportConfigObject.remove(validationCategoryName);
		
		if(newValidationCategoryCount > 0) {
			
			reportConfigObject.put(validationCategoryName, newValidationCategoryCount);
			
		} 
		
		reportConfigObject = updateIgnoreFalsePositveErrorCountInConfigObject(reportConfigObject, validationCategoryName);
		
		return reportConfigObject;
	}
	
	
	/**
	 * Method to update user ignore issue count in user configuration object under configuration object
	 * @param reportConfigObject
	 * @param validationCategoryName
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private Map<String,Object> updateIgnoreFalsePositveErrorCountInConfigObject(Map<String,Object> reportConfigObject, String validationCategoryName){
		
		Map<String,Integer> userIgnoreErrorCountDetailsMap = new HashMap<String, Integer>();
		
		if(reportConfigObject.containsKey(userIgnoreIssueType)) {
			
			userIgnoreErrorCountDetailsMap =  (Map<String, Integer>) reportConfigObject.get(userIgnoreIssueType);		
			
			if(userIgnoreErrorCountDetailsMap.containsKey(validationCategoryName)) {
				
				Integer updatedErrorCount = userIgnoreErrorCountDetailsMap.get(validationCategoryName) + 1;
				
				userIgnoreErrorCountDetailsMap.remove(validationCategoryName);
				
				userIgnoreErrorCountDetailsMap.put(validationCategoryName, updatedErrorCount);
				
			} else {
				
				userIgnoreErrorCountDetailsMap.put(validationCategoryName, 1);
				
			}
			
			reportConfigObject.remove(userIgnoreIssueType);
			
		} else {
			
			userIgnoreErrorCountDetailsMap.put(validationCategoryName, 1);
			
		}
		
		reportConfigObject.put(userIgnoreIssueType, userIgnoreErrorCountDetailsMap);
		
		
		return reportConfigObject;
	}
	
	
	/**
	 * Method to add new rule to domain speciifc rule book
	 * @param url
	 * @param issueObject
	 * @param issueId
	 * @param isIgnoreAll
	 * @param configuration
	 */
	private void addRuleToDomainSpecificRuleBook(String url, Map<String, Object> issueObject, String issueId,
												 Boolean isIgnoreAll, Map<String,Object> configuration,
												 String validationCategoryConfigurationLabel) {
		
		Map<String, Object> rule = null;
		
		boolean isNewDocumnet = false;
		
		URI uri = null;
		
		String domainName = "";
		
		try {
			
			uri = new URI(url);
			
			domainName = uri.getHost();
			
		} catch (URISyntaxException e) {
			
			domainName = url;
		}
		
		DomainSpecificRuleBook domainSpecificRuleBook = getDomainSpecificRuleBook(domainName);
		
		if (Util.isEmpty(domainSpecificRuleBook)) {

			domainSpecificRuleBook = new DomainSpecificRuleBook();

			domainSpecificRuleBook.set_id(Util.generateMongoID());

			domainSpecificRuleBook.setPageURL(domainName);

			isNewDocumnet = true;

		} else {

			rule = domainSpecificRuleBook.getRule();

		}
		
		if (issueId.toLowerCase().contains(CONSTANTS.CASESENSITIVE)) {
			
			domainSpecificRuleBook = updateCaseSensitiveRuleToDomesticRuleBook(isNewDocumnet, rule, issueObject, domainSpecificRuleBook);
			
		} else {
			
			domainSpecificRuleBook = updateRuleToDomesticRuleBook(configuration, validationCategoryConfigurationLabel, isIgnoreAll, isNewDocumnet, rule, issueObject, domainSpecificRuleBook);
		}
		
		if(!Util.isEmpty(domainSpecificRuleBook)) {
			
			domainSpecificRuleBookRepository.save(domainSpecificRuleBook);
			
		}
	}
	
	/**
	 * Special method to update case sensitive rule in domain specific rule book
	 * @param isNewDocumnet
	 * @param rule
	 * @param issueObject
	 * @param domainSpecificRuleBook
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private DomainSpecificRuleBook updateCaseSensitiveRuleToDomesticRuleBook(boolean isNewDocumnet, Map<String, Object> rule,
																			 Map<String, Object> issueObject, DomainSpecificRuleBook domainSpecificRuleBook) {
		
		List<String> caseSensitiveKeyWords = new ArrayList<String>();
		
		String text = null;
		
		boolean updateDocument = true;
		
		if (!isNewDocumnet && rule.containsKey(CONSTANTS.CASESENSITIVE)) {

			caseSensitiveKeyWords = (List<String>) rule.get(CONSTANTS.CASESENSITIVE);

			text = issueObject.get(CONSTANTS.TEXT).toString();

			if (!caseSensitiveKeyWords.contains(text)) {

				caseSensitiveKeyWords.add(text);

			} else {

				updateDocument = false;

			}

		} else {

			caseSensitiveKeyWords = new ArrayList<String>();

			text = issueObject.get(CONSTANTS.TEXT).toString();

			caseSensitiveKeyWords.add(text);

		}

		if(updateDocument) {
			
			domainSpecificRuleBook.getRule().put(CONSTANTS.CASESENSITIVE, caseSensitiveKeyWords);
			
			return domainSpecificRuleBook;
			
		} 
		
		return null;
		
	}
	
	
	/**
	 * Method to update all type of rule to domain specific rule book except case sensitive issue
	 * @param configuration
	 * @param validationCategoryConfigurationLabel
	 * @param isIgnoreAll
	 * @param isNewDocumnet
	 * @param rule
	 * @param issueObject
	 * @param domainSpecificRuleBook
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private DomainSpecificRuleBook updateRuleToDomesticRuleBook(Map<String,Object> configuration, String validationCategoryConfigurationLabel, 
															   boolean isIgnoreAll, boolean isNewDocumnet, Map<String, Object> rule,
															   Map<String, Object> issueObject, DomainSpecificRuleBook domainSpecificRuleBook) {
		
 		List<String> configurationLabelsList = new ArrayList<String>();
		
		Map<String, Set<String>> domainLabelsMap = new HashMap<String, Set<String>>();
		
		int index = 0;
		
		boolean updateDocument = false;
		
		Map<String, Object> validationConfigurationlabelsMap = (Map<String, Object>) configuration.get(CONSTANTS.LABELS);
		
		Map<String, Object> validationCategoryLabelMap = (Map<String, Object>) validationConfigurationlabelsMap.get(validationCategoryConfigurationLabel);
		
		configurationLabelsList = isIgnoreAll ? (List<String>) validationCategoryLabelMap.get(CONSTANTS.IGNOREALL)
				: (List<String>) validationCategoryLabelMap.get(CONSTANTS.IGNORE);
		
		List<Map<String, String>> validationCategoryRule = new ArrayList<Map<String, String>>();
		
		if (!isNewDocumnet && rule.containsKey(validationCategoryConfigurationLabel)) {
			
			validationCategoryRule = (List<Map<String, String>>) rule.get(validationCategoryConfigurationLabel);
			
			// creating a map that contains the domain categoryRule list
			for (Map<String, String> domainRule : validationCategoryRule) {
				
				domainLabelsMap.put(String.valueOf(index), domainRule.keySet());
				
				index++;
				
			}
		}
			
		Map<String, String> newValidationCategoryRule = new HashMap<String, String>();
		
		for (String label : configurationLabelsList) {
			
			// check for null
			String value = (issueObject.get(label) != null) ? issueObject.get(label).toString() : "0";
			
			newValidationCategoryRule.put(label, value);
			
		}
		
		// converting map to json
		JSONObject newValidationCategoryRuleJson = new JSONObject(newValidationCategoryRule);
		
		boolean isAlreadyAddedInDomainSpecificRuleBook = isFalsePositive(validationCategoryRule, domainLabelsMap, newValidationCategoryRuleJson);
		
		// add on data if not exists already
		if(!isAlreadyAddedInDomainSpecificRuleBook) {
			
			validationCategoryRule.add(newValidationCategoryRule);
			
			updateDocument = true;
		}
		
		if(updateDocument) {
			
			domainSpecificRuleBook.getRule().put(validationCategoryConfigurationLabel, validationCategoryRule);
			
			return domainSpecificRuleBook;
			
		}
			
			
		return null;
	}
	
	/**
	 * Method to save base64 image in file server 
	 * @param base64Image
	 * @param screenShotName
	 * @throws IOException 
	 */
	public void saveBase64ScreenShot(String base64Image, String screenShotName) throws IOException{		
		
		String finalScreenShotPath =  new File(screenShotPath + File.separator + screenShotName + CONSTANTS.PNG_EXTENSION).getCanonicalPath();
		
		
		try {
			
			BufferedImage image = null;
			
			byte[] imageByte = Base64.getDecoder().decode(base64Image);
			
			ByteArrayInputStream bis = new ByteArrayInputStream(imageByte);
			
			image = ImageIO.read(bis);
			
			bis.close();
	
			File outputfile = new File(finalScreenShotPath);
			
			File canonicalOutputFile = outputfile.getCanonicalFile();
		
			ImageIO.write(image, "png", canonicalOutputFile);
			
		} catch (Exception e) {
			
			LOGGER.error("Exception occured while saving the base64 image. Screen Shot Name: "+ screenShotName +",Base64 Image:\n"+ base64Image);
		}
		
		if(new File(finalScreenShotPath).getCanonicalFile().exists()) {
			
			LOGGER.info("Base64 image Successfully saved. Screen " + finalScreenShotPath);
			
		}
		
	}
	
	/**
	 * Method used to form config values of the report
	 * @param report
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private Report accessibilityFormConfigValuesFromPageJsonAndAddItToReport(Report report,JSONObject issuesCountObj) {
		
		List<String> errorNames = new ArrayList<String>();
		
		List<String> falsePositiveErrorNames = new ArrayList<String>();
		
		Map<String,Object> configObjMap = new HashMap<String, Object>();
		
		Map<String, Object> pageObject = report.getReportObject().get("page"+ report.getRunIdentifier());
		
		for(String key : pageObject.keySet()) {
			
			Map<String,Object> reportValueMap = (Map<String, Object>) pageObject.get(key);
			
			if((Boolean) reportValueMap.get(CONSTANTS.ISFALSEPOSITIVE)) {
				
				falsePositiveErrorNames.add(key.split("__")[0]);
				
			} 
		}
		
		//Map<String, Integer> occurrencesMap=getConfigurationErrorDetails(errorNames);
		
		Map<String, Integer> falsePositiveOccurrencesMap = getConfigurationErrorDetails(falsePositiveErrorNames);
		
		//if(!occurrencesMap.isEmpty()) {
			
			Map<String,Integer> falsePositiveErrorCountDetailsMap = new HashMap<String, Integer>();
			
			configObjMap.put("pageUrl", report.getPageURL());
			
			Iterator<String> issuesKeys = issuesCountObj.keys();
			
			while(issuesKeys.hasNext()) {
				
			    String key = issuesKeys.next();
			    
			    if(key == "totalIssue") {
			    	
			    	configObjMap.put("Error Count", issuesCountObj.get(key));
			    	
			    }
			    else {
			    	
			    configObjMap.put(key,issuesCountObj.get(key));
			    
			    }
			    
			}
			
			/*configObjMap.put("High", issuesCountObj.get("High"));
			
			configObjMap.put("Low", issuesCountObj.get("Low"));
			
			configObjMap.put("Medium", issuesCountObj.get("Medium"));
			for(Entry<String, Integer> obj : occurrencesMap.entrySet()) {//nr
				
				configObjMap.put(obj.getKey().replaceAll("\\s",""), obj.getValue());

			}*/
			
			for(Entry<String, Integer> obj : falsePositiveOccurrencesMap.entrySet()) {
				
				falsePositiveErrorCountDetailsMap.put(obj.getKey().replaceAll("\\s",""), obj.getValue());
				
			}
			
			configObjMap.put("falsePositiveErrorCounts", falsePositiveErrorCountDetailsMap);
		//}
		
		if(!Util.isEmpty(configObjMap)) {
			report.getReportObject().put("Conf_page" + report.getRunIdentifier(), configObjMap);
		}
		return report;
	}
}
