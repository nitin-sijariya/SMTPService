package com.cognizant.accessibilityvalidationbot.centralizedservice.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import org.jetbrains.annotations.NotNull;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * POJO Class to store categorization response
 * @author 578086
 *
 */
@Document(collection="categorizationVO")
public class CategorizationVO implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The id. */
	@Id
	@NotNull
	private String _id;
	
	/** Run identifier. mongo id of Service Request **/
	private String runIdentifier;
	
	/** Contains single card xpath and css selector **/
	private Map<String,String> singleCardDetailsMap = new HashMap<String, String>();
	
	/** Contains repeated single card xpath and css selector **/
	private Map<String,String> repeatedSingleCardDetailsMap = new HashMap<String, String>();
	
	/** Contains repeated card xpath and css selector **/
	private Map<String,String> repeatedCardDetailsMap = new HashMap<String, String>();
	
	/** Contains horizontal menu xpath and css selector **/
	private Map<String,String> horizontalMenuDetailsMap = new HashMap<String, String>();
	
	/** Contains vertical menu xpath and css selector **/
	private Map<String,String> verticalMenuDetailsMap = new HashMap<String, String>();
	
	/** Contains carousel xpath and css selector **/
	private Map<String,String> carouselDetailsMap = new HashMap<String, String>();
	
	/** Contains hoverable menu xpath and css selector **/
	private Map<String,String> hoverableMenuDetailsMap = new HashMap<String, String>();
	
	/** Contains hoverable menu li xpath **/
	private Map<String,String> hoverableMenuChildXpathDetailsMap = new HashMap<String, String>();
	
	/** Contains carousel's previous and next xpath and css selector **/
	private Map<String,Map<String,String>> carouselPreviousNextDotDetailsMap = new HashMap<String, Map<String,String>>();
	
	/** Contains all other categories xpath and css selector **/
	private Map<String,String> otherDetailsMap = new HashMap<String, String>();
	
	/** Contains key details of the repeated single card **/
	private Map<String,String> repeatedSingleCardKeyDetailsMap = new HashMap<String, String>();
	
	/** Contains carousel dots xpath */
	private String carouselDotsXpathDetails = new String();

	/** Date of creation **/
	private LocalDateTime createdDate;
	
	/** URL for which categorization taken place */
	private String url;
	
	/**
	 * @return the _id
	 */
	public String get_id() {
		return _id;
	}

	/**
	 * @param _id the _id to set
	 */
	public void set_id(String _id) {
		this._id = _id;
	}

	/**
	 * @return the runIdentifier
	 */
	public String getRunIdentifier() {
		return runIdentifier;
	}

	/**
	 * @param runIdentifier the runIdentifier to set
	 */
	public void setRunIdentifier(String runIdentifier) {
		this.runIdentifier = runIdentifier;
	}

	/**
	 * @return the singleCardDetailsMap
	 */
	public Map<String, String> getSingleCardDetailsMap() {
		return singleCardDetailsMap;
	}

	/**
	 * @param singleCardDetailsMap the singleCardDetailsMap to set
	 */
	public void setSingleCardDetailsMap(Map<String, String> singleCardDetailsMap) {
		this.singleCardDetailsMap = singleCardDetailsMap;
	}

	/**
	 * @return the repeatedSingleCardDetailsMap
	 */
	public Map<String, String> getRepeatedSingleCardDetailsMap() {
		return repeatedSingleCardDetailsMap;
	}

	/**
	 * @param repeatedSingleCardDetailsMap the repeatedSingleCardDetailsMap to set
	 */
	public void setRepeatedSingleCardDetailsMap(Map<String, String> repeatedSingleCardDetailsMap) {
		this.repeatedSingleCardDetailsMap = repeatedSingleCardDetailsMap;
	}

	/**
	 * @return the repeatedCardDetailsMap
	 */
	public Map<String, String> getRepeatedCardDetailsMap() {
		return repeatedCardDetailsMap;
	}

	/**
	 * @param repeatedCardDetailsMap the repeatedCardDetailsMap to set
	 */
	public void setRepeatedCardDetailsMap(Map<String, String> repeatedCardDetailsMap) {
		this.repeatedCardDetailsMap = repeatedCardDetailsMap;
	}

	/**
	 * @return the horizontalMenuDetailsMap
	 */
	public Map<String, String> getHorizontalMenuDetailsMap() {
		return horizontalMenuDetailsMap;
	}

	/**
	 * @param horizontalMenuDetailsMap the horizontalMenuDetailsMap to set
	 */
	public void setHorizontalMenuDetailsMap(Map<String, String> horizontalMenuDetailsMap) {
		this.horizontalMenuDetailsMap = horizontalMenuDetailsMap;
	}

	/**
	 * @return the verticalMenuDetailsMap
	 */
	public Map<String, String> getVerticalMenuDetailsMap() {
		return verticalMenuDetailsMap;
	}

	/**
	 * @param verticalMenuDetailsMap the verticalMenuDetailsMap to set
	 */
	public void setVerticalMenuDetailsMap(Map<String, String> verticalMenuDetailsMap) {
		this.verticalMenuDetailsMap = verticalMenuDetailsMap;
	}

	/**
	 * @return the carouselDetailsMap
	 */
	public Map<String, String> getCarouselDetailsMap() {
		return carouselDetailsMap;
	}

	/**
	 * @param carouselDetailsMap the carouselDetailsMap to set
	 */
	public void setCarouselDetailsMap(Map<String, String> carouselDetailsMap) {
		this.carouselDetailsMap = carouselDetailsMap;
	}

	/**
	 * @return the hoverableMenuDetailsMap
	 */
	public Map<String, String> getHoverableMenuDetailsMap() {
		return hoverableMenuDetailsMap;
	}

	/**
	 * @param hoverableMenuDetailsMap the hoverableMenuDetailsMap to set
	 */
	public void setHoverableMenuDetailsMap(Map<String, String> hoverableMenuDetailsMap) {
		this.hoverableMenuDetailsMap = hoverableMenuDetailsMap;
	}

	
	/**
	 * @return the hoverableMenuChildXpathDetailsMap
	 */
	public Map<String, String> getHoverableMenuChildXpathDetailsMap() {
		return hoverableMenuChildXpathDetailsMap;
	}

	/**
	 * @param hoverableMenuChildXpathDetailsMap the hoverableMenuChildXpathDetailsMap to set
	 */
	public void setHoverableMenuChildXpathDetailsMap(Map<String, String> hoverableMenuChildXpathDetailsMap) {
		this.hoverableMenuChildXpathDetailsMap = hoverableMenuChildXpathDetailsMap;
	}

	/**
	 * @return the carouselPreviousNextDotDetailsMap
	 */
	public Map<String, Map<String, String>> getCarouselPreviousNextDotDetailsMap() {
		return carouselPreviousNextDotDetailsMap;
	}

	/**
	 * @param carouselPreviousNextDotDetailsMap the carouselPreviousNextDotDetailsMap to set
	 */
	public void setCarouselPreviousNextDotDetailsMap(Map<String, Map<String, String>> carouselPreviousNextDotDetailsMap) {
		this.carouselPreviousNextDotDetailsMap = carouselPreviousNextDotDetailsMap;
	}

	/**
	 * @return the otherDetailsMap
	 */
	public Map<String, String> getOtherDetailsMap() {
		return otherDetailsMap;
	}

	/**
	 * @param otherDetailsMap the otherDetailsMap to set
	 */
	public void setOtherDetailsMap(Map<String, String> otherDetailsMap) {
		this.otherDetailsMap = otherDetailsMap;
	}
	
	/**
	 * @return the repeatedSingleCardKeyDetailsMap
	 */
	public Map<String, String> getRepeatedSingleCardKeyDetailsMap() {
		return repeatedSingleCardKeyDetailsMap;
	}

	/**
	 * @param repeatedSingleCardKeyDetailsMap the repeatedSingleCardKeyDetailsMap to set
	 */
	public void setRepeatedSingleCardKeyDetailsMap(Map<String, String> repeatedSingleCardKeyDetailsMap) {
		this.repeatedSingleCardKeyDetailsMap = repeatedSingleCardKeyDetailsMap;
	}

	/**
	 * @return the carouselDotsXpathDetails
	 */
	public String getCarouselDotsXpathDetails() {
		return carouselDotsXpathDetails;
	}

	/**
	 * @param carouselDotsXpathDetails the carouselDotsXpathDetails to set
	 */
	public void setCarouselDotsXpathDetails(String carouselDotsXpathDetails) {
		this.carouselDotsXpathDetails = carouselDotsXpathDetails;
	}

	/**
	 * @return the createdDate
	 */
	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}
	
}
