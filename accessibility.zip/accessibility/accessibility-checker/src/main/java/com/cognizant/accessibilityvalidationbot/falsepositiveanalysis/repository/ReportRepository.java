package com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.model.Report;

/**
 * Mongo Repository for report
 * @author Sundar
 *
 */
@Transactional
public interface ReportRepository extends MongoRepository<Report,String>{

	public Report findByRunIdentifier(String runIdentifier);
	
}
