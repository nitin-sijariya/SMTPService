package com.cognizant.accessibilityvalidationbot.centralizedservice.model;

/**
 * Enum for status 
 * @author 578086
 *
 */
public enum Status {

	INITIATED,
	STARTED,
	COMPLETED,
	FAILED
}
