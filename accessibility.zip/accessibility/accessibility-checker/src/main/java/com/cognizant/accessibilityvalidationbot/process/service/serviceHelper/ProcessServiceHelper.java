package com.cognizant.accessibilityvalidationbot.process.service.serviceHelper;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import javax.imageio.ImageIO;

import org.apache.http.client.utils.HttpClientUtils;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;

import com.assertthat.selenium_shutterbug.core.Capture;
import com.assertthat.selenium_shutterbug.core.Shutterbug;
import com.cognizant.accessibilityvalidationbot.process.factory.ChromeDriverEx;
import com.cognizant.accessibilityvalidationbot.process.factory.WebDriverFactory;
import com.cognizant.accessibilityvalidationbot.process.model.Driver;
import com.cognizant.accessibilityvalidationbot.process.utils.Browser;
import com.cognizant.accessibilityvalidationbot.process.utils.CONSTANTS;
import com.cognizant.accessibilityvalidationbot.process.utils.Util;
import com.github.axet.wget.WGet;
import com.github.axet.wget.info.URLInfo.States;

/**
 * Service helper class for Process Validation Service
 * 
 * @author 578086
 *
 */
@Service
public class ProcessServiceHelper {

	private static final Logger LOGGER = LoggerFactory.getLogger(ProcessServiceHelper.class);
	
	/** Screen shot file dir path */
	@Value("${app.screenshot.path}")
	private String screenShotPath;
	
	/** Splitter for validation category name from issue id*/
	@Value("${app.report.validation.categoryname.splitter}")
	private String validationCategoryNameSplitter;
	
	/**
	 * Get web driver for given browser
	 * @param browser
	 * @param deviceName
	 * @return
	 */
	public WebDriver getWebDriver(String browser, String deviceName) {
		
		String osName = System.getProperty("os.name");
		
		if(osName.equals("Linux")) {
			if(browser.equalsIgnoreCase("CHROME")) {
				return WebDriverFactory.getWebDriver(Browser.CHROME_HEADLESS, deviceName);	
			}
		} else {
			if(browser.equalsIgnoreCase("CHROME")) {
				return WebDriverFactory.getWebDriver(Browser.CHROME, deviceName);	
			}
			else if(browser.equalsIgnoreCase("FIREFOX")) {
				return WebDriverFactory.getWebDriver(Browser.FIREFOX, deviceName);
			}
			else if(browser.equalsIgnoreCase("MOBILE")) {
				return WebDriverFactory.getWebDriver(Browser.MOBILE, deviceName);
			}
			else {
				return WebDriverFactory.getWebDriver(Browser.CHROME, deviceName);	
			}
		}
		
		return null;
		
	}
	
	/**
	 * Method to open new tab in the browser
	 * @param driver
	 * @throws AWTException
	 * @throws InterruptedException
	 */
	public void openNewTab(WebDriver driver) {

		((JavascriptExecutor) driver)
		.executeScript("window.open('','_blank')");
	}
	
	/**
	 * Method used for switching to newly opened tab in the browser for accessing the page URL
	 * 
	 * @param driver
	 * @throws AWTException
	 * @throws InterruptedException
	 */
	public void switchToNewTab(WebDriver driver) throws InterruptedException  {

		ArrayList<String> winHandles = new ArrayList<String> (driver.getWindowHandles());
		Thread.sleep(500);
		int newTabIndex = winHandles.size();
		driver.switchTo().window(winHandles.get(newTabIndex - 1));
	}
	
	/**
	 * Method to inject the required JS in browser
	 * @param driver
	 * @param url
	 * @param isReloadNeeded
	 * @throws InterruptedException
	 */
	public void injectJSToTheBrowser(WebDriver driver, String url, boolean isReloadNeeded) throws InterruptedException {
		
		try {
			((JavascriptExecutor) driver)
			.executeScript("var s=document.createElement('script');"
					+ "s.src='"+url+"';"
					+ "window.document.head.appendChild(s);");
		} catch(Exception e) {
			
			LOGGER.error("Exception happened while injecting js to browser for the URL:" + url + ". Error:" + e.getMessage());
			
			if(isReloadNeeded) {
				Thread.sleep(500);
				
				injectJSToTheBrowser(driver, url, isReloadNeeded);
			}
			
		}
		
		
	}
	
	/**
	 * Method to close pop-ups in the page based on given xpath list 
	 * @param driver
	 * @param xpath
	 */
	public void popUpHandler(WebDriver driver, List<String> listOfXpath, String url, String runIdentifier) {

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
//		WebDriverWait wait = new WebDriverWait(driver, 10);
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		
		if (!Util.isEmpty(listOfXpath)) {
			
			for (int i = 0; i < listOfXpath.size(); i++) {
				try {
						
					WebElement element = wait
							.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(listOfXpath.get(i))));
					element.click();
				} catch (Exception e) {
					
					LOGGER.error("xPath not found for the URL:"+ url + ",RunIdentifier:" + runIdentifier + ",xpath:" + listOfXpath.get(i) + ". Exception is" + e.getMessage() );
					
				}
			}
		} else {
			
			String parent = driver.getWindowHandle();
			
			Set<String> allWindowHandles = driver.getWindowHandles();
			
			Iterator<String> I1 = allWindowHandles.iterator();

			while (I1.hasNext()) {
				String child_window = I1.next();
				if (!parent.equals(child_window)) {
					driver.switchTo().window(child_window);
					driver.close();
				}
			}
		
			driver.switchTo().window(parent);
			
		}
	}
	
	/**
	 * Method to invoke JS function in browser
	 * @param driver
	 * @param functionName
	 */
	public void invokeJSFunction(WebDriver driver, String functionName) {
		
		((JavascriptExecutor) driver).executeScript("var s=document.createElement('script');"
				+ "s.innerHTML= "+ functionName +";"
				+ "window.document.head.appendChild(s);");
		
	}
	
	/**
	 * Method used to send the categorization response to centralized server
	 * @param url
	 * @param json
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public  String sendResponseToMicroService(String url, String json, RequestMethod requestMethod){
		
		String output = null;
		
		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
		
		SSLContextBuilder sslContextBuilder = new SSLContextBuilder();
		
		CloseableHttpClient httpClient = null;
		
		RestTemplate restTemplate;
		
		Map<String,Object> result;
		
		SSLConnectionSocketFactory sslConnectionSocketFactory;
		
		try {
			sslContextBuilder.loadTrustMaterial(null, new TrustStrategy() {
				@Override
				public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException {
					return true;
				}
			});
			
			sslConnectionSocketFactory = new SSLConnectionSocketFactory(sslContextBuilder.build());
			
			httpClient = HttpClients.custom().setSSLSocketFactory(sslConnectionSocketFactory).build();
			
			requestFactory.setHttpClient(httpClient);
			
			HttpHeaders headers = new HttpHeaders();
			
			headers.add("Content-Type", "application/json");
			
			restTemplate = new RestTemplate(requestFactory);
			
			HttpEntity<String> entity = new HttpEntity<String>(json, headers);
			
			if(requestMethod.equals(RequestMethod.POST)) {
				
				result = restTemplate.postForObject(url, entity , Map.class, " ");
				
			} else {
				result = restTemplate.exchange(url, HttpMethod.GET, entity, Map.class).getBody();
			}

			if (!Util.isEmpty(result)) {
				Map<String,Object> response = (Map<String, Object>) result.get("response");
				output =  (String) response.get("param"); 
			} 
			
			if(Util.isEmpty(output)) {
				LOGGER.error("Response is empty for the validation. URL:"+ url + ", request:"+ json);
			}
			
		} catch (NoSuchAlgorithmException | KeyStoreException | KeyManagementException e) {
			
			return null;
			
		}finally {
			try {
				requestFactory.destroy();
				HttpClientUtils.closeQuietly(httpClient);
			} catch (Exception e) {
			}
		}
		
		
		return output;
	}
	
	
	/**
	 * Method for invoking the validation for corresponding category and send the response to False positive analysis
	 * @param seleniumDriver
	 * @param xpath
	 * @param key
	 * @param centralizedServerURL
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public JSONObject invokeValidationAndSendResponse(Driver seleniumDriver, String xpath, String key, String falsePositiveAnalysisURLWithIdentifier, JSONObject validationResultJson) {
		
		try {
			invokeJSFunction(seleniumDriver.getDriver(), "startValidation(\""+xpath+"\",\""+key+"\")");
			
			String result = recurrsiveCheck("checkAndReturnValidationJson()", 100, 0, seleniumDriver.getDriver());
			
			if(!Util.isEmpty(result)) {
				JSONObject resultJson = new JSONObject(result);
				
				for(String objKey: ((Map<String, List<String>>) resultJson).keySet()) {
					
					validationResultJson.put(objKey, resultJson.get(objKey));
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return validationResultJson;
		
	}
	
	/**
	 * Invoke the given method dynamically inside new Thread
	 * @param method
	 * @param classInstance
	 * @param numberOfParameters
	 * @param parameter
	 */
	public void invokeMethodInsideThread(Method method, Object classInstance, int numberOfParameters, List<Object> parameter) {
		
		Thread thread = null;
		
		try {
			thread = new Thread(new Runnable() {

				@Override
				public void run() {
					try {
						
						switch (numberOfParameters) {
						case 1:
							method.invoke(classInstance, parameter.get(0));
							break;
						case 2:
							method.invoke(classInstance, parameter.get(0), parameter.get(1));
							break;
						case 3:
							method.invoke(classInstance, parameter.get(0), parameter.get(1), parameter.get(2));
							break;
						case 4:
							method.invoke(classInstance, parameter.get(0), parameter.get(1), parameter.get(2), parameter.get(3));
							break;
						case 5:
							method.invoke(classInstance, parameter.get(0), parameter.get(1), parameter.get(2), parameter.get(3), parameter.get(4));
							break;
						case 6:
							method.invoke(classInstance, parameter.get(0), parameter.get(1), parameter.get(2), parameter.get(3), parameter.get(4), parameter.get(5));
							break;
						case 7:
							method.invoke(classInstance, parameter.get(0), parameter.get(1), parameter.get(2), parameter.get(3), parameter.get(4), parameter.get(5), parameter.get(6));
							break;
						case 8:
							method.invoke(classInstance, parameter.get(0), parameter.get(1), parameter.get(2), parameter.get(3), parameter.get(4), parameter.get(5), parameter.get(6), parameter.get(7));													   
							break;
						case 9:
							method.invoke(classInstance, parameter.get(0), parameter.get(1), parameter.get(2),
									parameter.get(3), parameter.get(4), parameter.get(5), parameter.get(6),
									parameter.get(7), parameter.get(8));
							break;
						case 10:
							method.invoke(classInstance, parameter.get(0), parameter.get(1), parameter.get(2),
									parameter.get(3), parameter.get(4), parameter.get(5), parameter.get(6),
									parameter.get(7), parameter.get(8), parameter.get(9));
							break;
						default:
							break;
						}
						
					} catch (Exception e) {
						
						e.printStackTrace();
						
						LOGGER.error("Error Occured while invoking the method:" + method.getName() + "with " +  numberOfParameters + " parameters");
					}
					
				}
			});

			thread.start();
			
		} finally {
			
			
		}
	}
	
	/**
	 * Recursive method to get value from java script
	 * @param methodName
	 * @param waitTime
	 * @return
	 */
	public String recurrsive(String methodName, int waitTime, WebDriver driver) {
		String json = null;
		Object categoryJson = null;
		try {
			Thread.sleep(waitTime);
			categoryJson = ((JavascriptExecutor) driver).executeScript("return " + methodName);
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		if(categoryJson.toString().equals("false")) {
			json = recurrsive(methodName, waitTime, driver);
		} else {
			json = categoryJson.toString();
		}
		
		return json;
	}
	
	/**
	 * Recursive method to get value from java script with retry count of 3
	 * @param methodName
	 * @param waitTime
	 * @return
	 */
	public String recurrsiveCheck(String methodName, int waitTime,int counter, WebDriver driver) {
		String json = null;
		Object categoryJson = null;
		try {
			Thread.sleep(waitTime);
			categoryJson = ((JavascriptExecutor) driver).executeScript("return " + methodName);
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		if(counter > 2) {
			return null;
		}
		
		counter ++;
		
		if(categoryJson.toString().equals("{}")) {
			json = recurrsiveCheck(methodName, waitTime, counter, driver);
		} else {
			json = categoryJson.toString();
		}
		
		return json;
	}
	
	
		
	/**
	 * Method to do Http Get Call for the given URL.
	 * 
	 * @param url
	 * @return
	 */
	public ResponseEntity<byte[]> doHttpGetCall(String url){
		
		LOGGER.info("Inside doHttpGetCall method. Current URL" + url);
		
		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
		
		SSLContextBuilder sslContextBuilder = new SSLContextBuilder();
		
		CloseableHttpClient httpClient = null;
		
		RestTemplate restTemplate;
		
		SSLConnectionSocketFactory sslConnectionSocketFactory;
		
		try {
			sslContextBuilder.loadTrustMaterial(null, new TrustStrategy() {
				@Override
				public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException {
					return true;
				}
			});
			
			sslConnectionSocketFactory = new SSLConnectionSocketFactory(sslContextBuilder.build());
			
			httpClient = HttpClients.custom().setSSLSocketFactory(sslConnectionSocketFactory).build();
			
			requestFactory.setHttpClient(httpClient);
			
			restTemplate = new RestTemplate(requestFactory);
			
			HttpHeaders headers = new HttpHeaders();
            
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_OCTET_STREAM));
            
			HttpEntity<String> entity = new HttpEntity<>(headers);
			
			return restTemplate.exchange(url, HttpMethod.GET, entity, byte[].class);
			
		}catch (Exception e) {

			LOGGER.error("Exception occured while fetching the url respone. URL:" + url + ".Error:"+ e.getMessage());
			
		}
		
		return null;
	}
	
	
	/**
	 * Method to get access use access urls
	 * 
	 * @param accessUrlList
	 * @param driver
	 * @throws InterruptedException 
	 */
	public void getAccessUsingAccessUrlList(List<String> accessUrlList, WebDriver driver, Map<String, Object> credentialDataObj) throws InterruptedException {
		
		for(String accessUrl: accessUrlList) {
		
			LOGGER.info("Categorization: Access URL:"+ accessUrl +" performed");
			
			driver.get(accessUrl);
			
			Thread.sleep(500);	
			
		}

	}
	
	/**
	 * Method to get access using login credential
	 * 
	 * @param driver
	 * @param credentialDataObj
	 * @param popupXpathList
	 * @param url
	 * @param runIdentifier
	 */
	public void getAccessUsingLogInCredentials(WebDriver driver, Map<String, Object> credentialDataObj, List<String> popupXpathList, String url, String runIdentifier) {
		
		if (!Util.isEmpty(credentialDataObj) && credentialDataObj.containsKey("loginType") && credentialDataObj.containsKey("loginUrl")) {
			
			String loginUrl = (String) credentialDataObj.get("loginUrl");
			
			try {			
				
				loginUrl = (String) credentialDataObj.get("loginUrl");
				
				LOGGER.info("Categorization: Login URL:"+ loginUrl +" - Trying to login");
													
					String loginIdType = (String) credentialDataObj.get("loginType");
					
					if (loginIdType.equals("alert")) {
						
						String logInId = (String) credentialDataObj.get("loginId");
						
						String password = (String) credentialDataObj.get("password");									
						
						String urlWithCredential = loginUrl.replaceFirst("//", "//"+logInId+":"+password+"@");
						
						driver.get(urlWithCredential);
						
						Thread.sleep(4000);
						
					}else {		
						
						driver.get(loginUrl);
						
						Thread.sleep(1000);
						
						popUpHandler(driver, popupXpathList, url, runIdentifier);
						
						if (loginIdType.equals("popUp")) {
							
							String popUpOpenLocator = (String) credentialDataObj.get("popUpOpenLocator");
							
							if(!Util.isEmpty(popUpOpenLocator)) {
								
								driver.findElement(By.xpath(popUpOpenLocator)).click();
							}
						}
						
						String loginIdLocator = (String) credentialDataObj.get("loginIdLocator");
						
//						WebDriverWait wait = new WebDriverWait(driver, 30);
						WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

		
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loginIdLocator)));
		
						driver.findElement(By.xpath(loginIdLocator)).sendKeys((String) credentialDataObj.get("loginId"));
		
						driver.findElement(By.xpath((String) credentialDataObj.get("passwordLocator")))
								.sendKeys((String) credentialDataObj.get("password"));
		
						String agreeBtn = (String) credentialDataObj.get("agreeLocator");
		
						if (!Util.isEmpty(agreeBtn)) {
		
							driver.findElement(By.xpath(agreeBtn)).click();
						}
		
						driver.findElement(By.xpath((String) credentialDataObj.get("submitLocator"))).click();
						
						Thread.sleep(4000);
						
					}
											
			}catch(Exception e) {
				LOGGER.error("Categorization: Login URL:"+ loginUrl +" - Login failed due to following exception - " + e.getMessage());
			}
			
			LOGGER.info("Categorization: Login URL:"+ loginUrl +" - Login succesfull");
		}
	}
	
	
	/**
	 * Method to send the font details to false positive analysis controller
	 * @param url
	 * @param falsePositiveServiceURL
	 * @param base64Screenshot
	 * @throws InterruptedException 
	 */
	public void updateScreenShotToFalsePositiveAnalysisService(String url, String falsePositiveServiceURL,String base64Screenshot, JSONObject accessibilityObj,String pageTitle) {
		
		
		try {
			
			String requestBody = "{\"param\":{\"accessibilityResultJson\":"+accessibilityObj+",\"url\":\""+ url +"\", \"branch\":\"ACCESSIBILITY\" ,\"base64ScreenShot\":\""+ base64Screenshot+ "\" ,\"pageTitle\":\"" + pageTitle +"\"}}";
			
			LOGGER.info( "Inside updateScreenShotToFalsePositiveAnalysisService function,Screenshot to false positive service. Post URL: " + falsePositiveServiceURL);
			
			sendResponseToMicroService(falsePositiveServiceURL, requestBody, RequestMethod.POST);
			
		} catch (Exception e) {
			
			LOGGER.error("Exception occurred updateScreenShotToFalsePositiveAnalysisService method  " + " Error:" + e.getMessage());
		
		}
		
		
	}
	
	/**
	 * Method for taking screen shot
	 * @param path
	 * @param screenshotName
	 * @param scaledWidth
	 * @param scaledHeight
	 * @param browser
	 * @param driver
	 * @throws Exception
	 */
	public String takeMobileScreenShot(int scaledWidth, int scaledHeight, String browser, WebDriver driver) throws Exception {
		
		final ByteArrayOutputStream os = new ByteArrayOutputStream();
		
		ChromeDriverEx chromedriver = (ChromeDriverEx) driver;
		
		File srcFile = ((ChromeDriverEx) chromedriver).getFullScreenshotChromeDriverAs(OutputType.FILE);
		
		BufferedImage finalImage = ImageIO.read(srcFile);
		
		 BufferedImage outputImage = new BufferedImage(scaledWidth,
	                scaledHeight, finalImage.getType());
	 
        // scales the input image to the output image
        Graphics2D g2d = outputImage.createGraphics();
        g2d.drawImage(finalImage, 0, 0, scaledWidth, scaledHeight, null);
        g2d.dispose();
 
        ImageIO.write(outputImage, "PNG", os);
		
		return Base64.getEncoder().encodeToString(os.toByteArray());
	}
	
	public void takeEachIssueScreenshot(Driver driver, JSONObject accessibilityObj, String runIdentifier) throws InterruptedException {
		
		JSONObject issuesCountObj = null;
		
		if(!Util.isEmpty(accessibilityObj)) {
			
			JSONObject validationReportObj = accessibilityObj.getJSONObject("issues");
				
			issuesCountObj = (JSONObject) accessibilityObj.get("issuesCount");
			
			Thread.sleep(7000);
				
			for(String key: validationReportObj.keySet()) {
				
				JSONArray validationReportArray = validationReportObj.getJSONArray(key);
				
				for (int i = 0; i < validationReportArray.length(); i++) {
					
					try {
						
						JSONObject validationJsonObj = validationReportArray.getJSONObject(i);
						
						if(validationJsonObj.has("locator")) {
							
							String issueXpath = validationJsonObj.getString("locator");
							
							String base64Image = takeElementInViewportScreenshot(issueXpath, driver.getDriver());
							
							if (!Util.isEmpty(base64Image)) {
									
									String issueId = "";
									
									String errorCaption = key;
									
									if(Util.isEmpty(errorCaption))
									{
										
										issueId = key;
										errorCaption="FontValidation";
										
									}
									else
									{
										
										issueId = errorCaption.replaceAll("\\s+","") + validationCategoryNameSplitter + "issues" + validationCategoryNameSplitter + i;
									
									}
									
								
								
								String subFolderName = issueId.split("_")[0];
								
								String folderName = runIdentifier + File.separator + subFolderName + File.separator;
								
								saveBase64ScreenShot(base64Image, folderName, issueId);
								
							}
							
						}
						
					}
					catch(Exception e) {
						System.out.println(e);
					}
					
			}
		  }
		}
		
	}
	
	private String takeElementInViewportScreenshot(String issueXpath, WebDriver driver) {

		final ByteArrayOutputStream os = new ByteArrayOutputStream();

		try {

			WebElement errorElement = driver.findElement(By.ByXPath.xpath(issueXpath));

			((JavascriptExecutor) driver).executeScript(
					"arguments[0].scrollIntoView({behavior: \"auto\", block: \"center\"});",
					errorElement);

			((JavascriptExecutor) driver).executeScript("arguments[0].setAttribute('style','border:5px red dashed !important')",errorElement);

			BufferedImage outputImage = Shutterbug.shootPage(driver, Capture.VIEWPORT, true).getImage();

			((JavascriptExecutor) driver).executeScript(CONSTANTS.BORDER_NONE, errorElement);

			ImageIO.write(outputImage, "PNG", os);

			((JavascriptExecutor) driver).executeScript(CONSTANTS.WINDOWSCROLL);

			return Base64.getEncoder().encodeToString(os.toByteArray());

		} catch (Exception ex) {
			LOGGER.info("Error while taking screenshot in method takeElementInViewportScreenshot()");
		}
		return "";
	}
	
	public void saveBase64ScreenShot(String base64Image, String folderName, String screenShotName) throws IOException {
		
		String finalScreenShotPath = new File(screenShotPath + File.separator + folderName + screenShotName + CONSTANTS.PNG_EXTENSION).getCanonicalPath();
		
		try {					
			
			//if folder with identifier doesnt exist. not throw an exception if dir already there
			Files.createDirectories(Paths.get(finalScreenShotPath).getParent());
			
			BufferedImage image = null;
			
			byte[] imageByte = Base64.getDecoder().decode(base64Image);
			
			ByteArrayInputStream bis = new ByteArrayInputStream(imageByte);
			
			image = ImageIO.read(bis);
			
			bis.close();
	
			File outputfile = new File(finalScreenShotPath);
			
			ImageIO.write(image, "png", outputfile);
			
		} catch (Exception e) {
			
			LOGGER.error("Exception occured while saving the base64 image. Screen Shot Name: "+ screenShotName +",Base64 Image:\n"+ base64Image);
		}
		
		if(new File(finalScreenShotPath).exists()) {
			
			LOGGER.info("Base64 image Successfully saved. Screen " + finalScreenShotPath);
			
		}
		
	}


}
