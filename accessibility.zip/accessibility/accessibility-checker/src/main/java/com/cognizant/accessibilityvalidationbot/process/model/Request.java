package com.cognizant.accessibilityvalidationbot.process.model;

import java.util.Map;

// TODO: Auto-generated Javadoc
/**
 * The Class CrowdRequest.
 */
public class Request{

	/** The param. */
	private Map<String, Object> param;

/**
 * Instantiates a new crowd request.
 */
/*
 * 
 */
	public Request()
	{
	}
	
	/**
	 * Instantiates a new crowd request.
	 *
	 * @param param the param
	 */
	public Request(Map<String, Object> param)
	{
		this.param = param;
	}
	
	/**
	 * Gets the param.
	 *
	 * @return the param
	 */
	public Map<String,Object> getParam(){
		return param;
	}

	/**
	 * Sets the param.
	 *
	 * @param param the param
	 */
	public void setParam(Map<String,Object> param) {
		this.param = param;
	}
}

