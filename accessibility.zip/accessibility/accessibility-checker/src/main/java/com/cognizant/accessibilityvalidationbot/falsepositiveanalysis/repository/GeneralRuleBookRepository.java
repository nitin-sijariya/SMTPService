package com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.accessibilityvalidationbot.falsepositiveanalysis.model.GeneralRuleBook;

/**
 * Mongo repository for General rule book
 * @author 578086
 *
 */
@Transactional
public interface GeneralRuleBookRepository extends MongoRepository<GeneralRuleBook,String>{

}
