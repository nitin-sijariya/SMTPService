export const environment = {
  production: true,
  baseURL:"http://10.120.100.192:9002/pluginManager",
  apiURL: "/api/v1/accessibility",
  startProcess:"/centralizedservice/process",
  report:"/centralizedservice/report",
  ignoreIssue:"/ignore/issue",
  IgnoredKey:"isUserRemoved",
  IgnoredCount:"UserIgnoredErrorCounts",
  corsURL:"http://10.120.100.192:9002/pluginManager"
};
