export class urlForParserOject {

    public url1: string;

    public browser1: string;

    public mobile1: string;

    constructor(url: string, browser: string, mobile: string) {

        this.url1 = url;
        this.browser1 = browser;
        this.mobile1 = mobile;
    }

}