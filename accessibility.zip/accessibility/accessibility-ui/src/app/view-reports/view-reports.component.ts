import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { UrlFetcherService } from '../url-fetcher.service';
import { NgbModal, NgbPopover } from '@ng-bootstrap/ng-bootstrap';
import { KeyValuePipe, NumberFormatStyle } from '@angular/common';
import { NgpSortModule, SortByPipe } from 'ngp-sort-pipe';
import { Variable } from '@angular/compiler/src/render3/r3_ast';
import { PerfectScrollbarConfigInterface, PerfectScrollbarComponent } from 'ngx-perfect-scrollbar';


declare var setSessionStorageOnImageClick;
declare var setInitialParamaters;
declare var setImagePath;
declare var jsonObjForEachCategory;
declare var errorCaption;
declare var drawRectancle;
declare var timeOutFnPrevNext;
declare var getImageRepresentationNew;
declare var onViewIgnore;
declare var drawRectancleForFontValidation;
declare var setInitialParamatersForFontValidation;
declare var onSwitchReport;


@Component({
	selector: 'app-view-reports',
	templateUrl: './view-reports.component.html',
	styleUrls: ['./view-reports.component.css']
})


export class ViewReportsComponent implements OnInit {
	@ViewChild('perfectScroll',{static:false}) perfectScroll : PerfectScrollbarComponent;
	@ViewChild('popoverHook')
	public popoverHook: NgbPopover
	pageError: any;
	countForNxtPrev: any;
	id: String;
	jsonReport: any;
	imagePath: any;
	pageURL: any;
	issueCount_List: any;
	showMoreData: any;
	browser: any;
	falsePositive: any;
	staticInfo: any;
	showMoreInfoCheck: boolean = false;
	isCollapsed: boolean = true;
	subCategories: any;
	ignoredIssue: boolean = false;
	btnDisabled: boolean = false;
	deviceHeight: any;
	deviceWidth: any;
	fontMetaDataDetails :any;
	fontMetaDataDetailsView :any;
	fontFamilyDetailsJson :any;
	fontTextDetailsJson :any;
	showFontValidationMetaData : boolean = false;
	isFontDataLoading: boolean = false;
	firstSubCategoryName: any;
	reportView: boolean = false;
	pin: boolean = true;
	unpin: boolean = false;
	isValidURL: any;
	thumbImgForLeftImage: any;
	thumbImgForRightImage: any;
	thumbnailImgPath: any;
	countForNxtPrevForCollapse: any;
	thumbImg: any;
	thumbnailImages = [];
	PLPImage: any;
	PDPImage: any;
	PDPLinkURL: any;
	isCollapse: boolean = false;
	firstCategoryName: any;

	dynamicColorMaps :any =['#FFFF00','#800080','#00FF00','#000000','#FF00FF','#2193b0','#753a88','#eb3349','#56ab2f','#00cdac','#000428','#dc2430'];
	validationNames: any = ['Image Broken Link', "Image Low Quality", "Broken Link", "OverLap", "OverLap AIML", "Alignment", "Case Sensitive", "PLP-PDP Mismatch", "Aspect Ratio Difference", "Pattern Difference", "Form Spacing", "Image Not Loaded", "OverFlow", "Video", "Carousel", "Menu Hovering", "Download", "Font Validation","Spell Validation"];
	countMap: any = { 'Image Broken Link': 0, "Image Low Quality": 0, "Broken Link": 0, "OverLap": 0, "OverLap AIML": 0, "Alignment": 0, "Case Sensitive": 0, "PLP-PDP Mismatch": 0, "Aspect Ratio Difference": 0, "Pattern Difference": 0, "Form Spacing": 0, "Image Not Loaded": 0, "OverFlow": 0, "Video": 0, "Carousel": 0, "Menu Hovering": 0, "Download": 0,  "Font Validation" : 0,"Spell Validation": 0,"PageTitle" :0,"h1Element" :0,"ImageAlt" :0,"SvgImageAlt" :0,"AreaImgAltCheck" :0,"InputImageCheck" :0,"orientation" :0,"byPassBlock":0,"byPassBlockheader":0,"autoComplete":0,"Emptyheading":0,"PageLang":0,"langPart":0,"landmark":0,"mainlandmark":0,"bannerlandmark":0,"footerlandmark":0,"seversideImagemap":0,"ariaDescribedby":0,"ariaLabelledby":0,"EmptyButton":0,"roleNavigation":0,"RolePresentation":0,"buttonWithTitle":0,"buttonWithAlt":0,"linkwithTitle":0,"linkwithAlt":0,"iframeDuplicate":0,"iframeTitle":0,"rolevalidation":0,"TimingAdjustable":0,"Movingblinkingscrolling":0,"emptyLink":0,"DuplicateID":0,"resize":0,"NovideoDescription":0,"Noaudiocaption":0,"Novideocaption":0,"semanticListDL":0,"semanticListOL":0,"semanticListUL":0,"ULlist":0,"DTList":0,"highertabindex":0,"bodyhidden":0,"Duplicatetablename":0,"tablescopeValidation":0};
	isValidationEnabled: any = {
		"Image Broken Link": false,
		"Image Low Quality": false,
		"Broken Link": false,
		"OverLap": false,
		"Alignment": false,
		"Case Sensitive": false,

		"PLP-PDP Mismatch": false,

		"Aspect Ratio Difference": false,
		"Pattern Difference": false,
		"Form Spacing": false,
		"Image Not Loaded": false,
		"OverFlow": false,
		"OverLap AIML": false,
		"Video": false,
		"Carousel": false,
		"Menu Hovering": false,
		"Download": false,
		"FontValidation":false,
		"Spell Validation":false,
		"PageTitle" :false,
		"h1Element" :false,
		"ImageAlt" :false,
		"SvgImageAlt" :false,
		"AreaImgAltCheck" :false,
		"InputImageCheck" :false,
		"orientation" :false,
		"byPassBlock":false,
		"byPassBlockheader":false,
		"autoComplete":false,
		"Emptyheading":false,
		"PageLang":false,
		"langPart":false,
		"landmark":false,
		"mainlandmark":false,
		"bannerlandmark":false,
		"footerlandmark":false,
		"seversideImagemap":false,
		"ariaDescribedby":false,
		"ariaLabelledby":false,
		"EmptyButton":false,
		"roleNavigation":false,
		"RolePresentation":false,
		"buttonWithTitle":false,
		"buttonWithAlt":false,
		"linkwithTitle":false,
		"linkwithAlt":false,
		"iframeDuplicate":false,
		"iframeTitle":false,
		"rolevalidation":false,
		"TimingAdjustable":false,
		"Movingblinkingscrolling":false,
		"emptyLink":false,
		"DuplicateID":false,
		"resize":false,
		"NovideoDescription":false,
		"Noaudiocaption":false,
		"Novideocaption":false,
		"semanticListDL":false,
		"semanticListOL":false,
		"semanticListUL":false,
		"ULlist":false,
		"DTList":false,
		"highertabindex":false,
		"bodyhidden":false,
		"Duplicatetablename":false,
		"tablescopeValidation":false
	};
	isValidationSelected: any = {
		"Image Broken Link": false,
		"Image Low Quality": false,
		"Broken Link": false,
		"OverLap": false,
		"Alignment": false,
		"Case Sensitive": false,

		"PLP-PDP Mismatch": false,
		
		"Aspect Ratio Difference": false,
		"Pattern Difference": false,
		"Form Spacing": false,
		"Image Not Loaded": false,
		"OverFlow": false,
		"OverLap AIML": false,
		"Video": false,
		"Carousel": false,
		"Menu Hovering": false,
		"Download": false,
		"FontValidation":false,
		"spellValidation":false,
		"PageTitle" :false,
		"h1Element" :false,
		"ImageAlt" :false,
		"SvgImageAlt" :false,
		"AreaImgAltCheck" :false,
		"InputImageCheck" :false,
		"orientation" :false,
		"byPassBlock":false,
		"byPassBlockheader":false,
		"autoComplete":false,
		"Emptyheading":false,
		"PageLang":false,
		"langPart":false,
		"landmark":false,
		"mainlandmark":false,
		"bannerlandmark":false,
		"footerlandmark":false,
		"seversideImagemap":false,
		"ariaDescribedby":false,
		"ariaLabelledby":false,
		"EmptyButton":false,
		"roleNavigation":false,
		"RolePresentation":false,
		"buttonWithTitle":false,
		"buttonWithAlt":false,
		"linkwithTitle":false,
		"linkwithAlt":false,
		"iframeDuplicate":false,
		"iframeTitle":false,
		"rolevalidation":false,
		"TimingAdjustable":false,
		"Movingblinkingscrolling":false,
		"emptyLink":false,
		"DuplicateID":false,
		"resize":false,
		"NovideoDescription":false,
		"Noaudiocaption":false,
		"Novideocaption":false,
		"semanticListDL":false,
		"semanticListOL":false,
		"semanticListUL":false,
		"ULlist":false,
		"DTList":false,
		"highertabindex":false,
		"bodyhidden":false,
		"Duplicatetablename":false,
		"tablescopeValidation":false
	};

	validationNameMap: any = {
		"Image Broken Link": "Image-BrokenLink",
		"Image Low Quality": "Imageisoflowquality",
		"Broken Link": "LinkNotWorking",
		"OverLap": "OverLapError-REPEATEDCARD",
		"Alignment": "PositionAlignmentError",
		"Case Sensitive": "CasesensitiveError",

		"PLP-PDP Mismatch": "PlpToPdpComparison",

		"Aspect Ratio Difference": "AspectRatioaredifferent",
		"Pattern Difference": "SizeDifference",
		"Form Spacing": "SpacingError-FORM",
		"Image Not Loaded": "Image-NotLoaded",
		"OverFlow": "OverFlowError-REPEATEDCARD",
		"OverLap AIML": "OverlapError-REPEATEDCARD-AIML",
		"Video": "Videoplayissue",
		"Carousel": "Carouselissue",
		"Menu Hovering": "InteractiveMenu",
		"Download": "Downloadissue",
		"FontValidation":"Font_",
		"Spell Validation":"spellError",
		"PageTitle" :"PageTitle",
		"h1Element" :"h1Element",
		"ImageAlt" :"ImageAlt",
		"SvgImageAlt" :"SvgImageAlt",
		"AreaImgAltCheck" :"AreaImgAltCheck",
		"InputImageCheck" :"InputImageCheck",
		"orientation" :"orientation",
		"byPassBlock":"byPassBlock",
		"byPassBlockheader":"byPassBlockheader",
		"autoComplete":"autoComplete",
		"Emptyheading":"Emptyheading",
		"PageLang":"PageLang",
		"langPart":"langPart",
		"landmark":"landmark",
		"mainlandmark":"mainlandmark",
		"bannerlandmark":"bannerlandmark",
		"footerlandmark":"footerlandmark",
		"seversideImagemap":"seversideImagemap",
		"ariaDescribedby":"ariaDescribedby",
		"ariaLabelledby":"ariaLabelledby",
		"EmptyButton":"EmptyButton",
		"roleNavigation":"roleNavigation",
		"RolePresentation":"RolePresentation",
		"buttonWithTitle":"buttonWithTitle",
		"buttonWithAlt":"buttonWithAlt",
		"linkwithTitle":"linkwithTitle",
		"linkwithAlt":"linkwithAlt",
		"iframeDuplicate":"iframeDuplicate",
		"iframeTitle":"iframeTitle",
		"rolevalidation":"rolevalidation",
		"TimingAdjustable":"TimingAdjustable",
		"Movingblinkingscrolling":"Movingblinkingscrolling",
		"emptyLink":"emptyLink",
		"DuplicateID":"DuplicateID",
		"resize":"resize",
		"NovideoDescription":"NovideoDescription",
		"Noaudiocaption":"Noaudiocaption",
		"Novideocaption":"Novideocaption",
		"semanticListDL":"semanticListDL",
		"semanticListOL":"semanticListOL",
		"semanticListUL":"semanticListUL",
		"ULlist":"ULlist",
		"DTList":"DTList",
		"highertabindex":"highertabindex",
		"bodyhidden":"bodyhidden",
		"Duplicatetablename":"Duplicatetablename",
		"tablescopeValidation":"tablescopeValidation"
	};

	pointedError = [{ x: '' }];
	categoryDescription: any = {
		'Image-BrokenLink': "The highlighted Image link is not working",
		"Imageisoflowquality": "The displayed image is stretched way beyond the expected quality standard",
		"LinkNotWorking": "The highlighted  link is not working",
		"OverLapError-REPEATEDCARD": "Content overlap is observed between in the highlighted section",
		"OverlapError-REPEATEDCARD-AIML": "Content overlap is observed between in the highlighted section",
		"PositionAlignmentError": "Alignment of the highlighted content is not aligned with its list of items",
		"CasesensitiveError": "The highlighted content is case sensitive",

		"PlpToPdpComparison": "The following mismatch was found in PLP-PDP comparison",

		"AspectRatioaredifferent": "Image highlighted is not rendered with the expected dimensions",
		"SizeDifference": "Difference in pattern is observed in the highlighted section in comparison with the other cards",
		"SpacingError-FORM": "the highlighted content contains spacing",
		"Image-NotLoaded": "The highlighted Image is not loaded",
		"OverFlowError-REPEATEDCARD": "The contents in the highlighted section are not aligned within the boundary of the element",
		"Videoplayissue": "The highlighted video is not playable",
		"Carouselissue": "The highlighted carousel is not working",
		"InteractiveMenu": "Menu is not hoverable OR Menu is not clickable",
		"Downloadissue": `The highlighted download ${this.pointedError[0].x} is not working`,
		"SpellValidation": "This text have spell error",
		"FontValidation":"The Selected Font has been  used by the highlighted text"
	};

	configLabelMap: any = {
		'Image-BrokenLink': "imageBrokenLink",
		"Imageisoflowquality": "imageLowQuality",
		"LinkNotWorking": "linkNotWorking",
		"OverLapError-REPEATEDCARD": "overlap",
		"PositionAlignmentErrorHORIZONTALMENU": "positionAlignmentHorizontal",
		"PositionAlignmentErrorVERTICALMENU": "positionAlignmentVertical",
		"CasesensitiveError": "casesensitive",		
		"AspectRatioaredifferent": "imageAspectRatio",
		"SizeDifference": "patternDifference",
		"Image-NotLoaded": "imageNotLoaded",
		"OverFlowError-REPEATEDCARD": "overflow",
		"Videoplayissue": "video",
		"Carouselissue": "carousel",
		"InteractiveMenu": "menuHovering",
		"spellError": "spellValidation",
		"FontValidation":"FontValidation"
	};
	validationNamePageLoad: any = {
		'Image-BrokenLink': "Image Broken Link",
		"Imageisoflowquality": "Image Low Quality",
		"LinkNotWorking": "Broken Link",
		"OverLapError-REPEATEDCARD": "OverLap",
		"PositionAlignmentError": "Alignment",
		"CasesensitiveError": "Case Sensitive",
		"LanguageError": "Language",
		"CurrencyError": "Currency",
		"AspectRatioaredifferent": "Aspect Ratio Difference",
		"SizeDifference": "Pattern Difference",
		"Image-NotLoaded": "Image Not Loaded",
		"OverFlowError-REPEATEDCARD": "OverFlow",
		"Videoplayissue": "Video",
		"Carouselissue": "Carousel",
		"InteractiveMenu": "InteractiveMenu",
		"Downloadissue": "Download",
		"Accordion": "Accordion",
		//	"Font Validation": "FontValidation",
		"PlpToPdpComparison": "PLP-PDP Mismatch",

		"PageTitle": "PageTitle",
		"h1Element": "h1Element" ,
		"ImageAlt":"ImageAlt" ,
		"SvgImageAlt":"SvgImageAlt" ,
		"AreaImgAltCheck":"AreaImgAltCheck",
		"InputImageCheck":"InputImageCheck",
		"orientation":"orientation" ,
		"byPassBlock":"byPassBlock",
		"byPassBlockheader":"byPassBlockheader",
		"autoComplete":"autoComplete",
		"Emptyheading":"Emptyheading",
		"PageLang":"PageLang",
		"langPart":"langPart",
		"landmark":"landmark",
		"mainlandmark":"mainlandmark",
		"bannerlandmark":"bannerlandmark",
		"footerlandmark":"footerlandmark",
		"seversideImagemap":"seversideImagemap",
		"ariaDescribedby":"ariaDescribedby",
		"ariaLabelledby":"ariaLabelledby",
		"EmptyButton":"EmptyButton",
		"roleNavigation":"roleNavigation",
		"RolePresentation":"RolePresentation",
		"buttonWithTitle":"buttonWithTitle",
		"buttonWithAlt":"buttonWithAlt",
		"linkwithTitle":"linkwithTitle",
		"linkwithAlt":"linkwithAlt",
		"iframeDuplicate":"iframeDuplicate",
		"iframeTitle":"iframeTitle",
		"rolevalidation":"rolevalidation",
		"TimingAdjustable":"TimingAdjustable",
		"Movingblinkingscrolling":"Movingblinkingscrolling",
		"emptyLink":"emptyLink",
		"DuplicateID":"DuplicateID",
		"resize":"resize",
		"NovideoDescription":"NovideoDescription",
		"Noaudiocaption":"Noaudiocaption",
		"Novideocaption":"Novideocaption",
		"semanticListDL":"semanticListDL",
		"semanticListOL":"semanticListOL",
		"semanticListUL":"semanticListUL",
		"ULlist":"ULlist",
		"DTList":"DTList",
		"highertabindex":"highertabindex",
		"bodyhidden":"bodyhidden",
		"Duplicatetablename":"Duplicatetablename",
		"tablescopeValidation":"tablescopeValidation"
	};

	validationCategoriesArr: any = ["UI Validation", "Content Validation", "Interaction Validation","Accessibility"];

	validationCategoriesJson: any = { "UI Validation": false, "Content Validation": false, "Interaction Validation": false, "Accessibility":false };

	validationSubCategoriesJson: any = [{ category: "UI Validation", subCategory: ["OverLap", "Alignment", "OverFlow", "Image Broken Link", "Pattern Difference"], categoryCount: 0 }, { category: "Content Validation", subCategory: ["Case Sensitive", "Broken Link", "Image Low Quality", "Aspect Ratio Difference", "Image Not Loaded","FontValidation","Spell Validation"], categoryCount: 0 }, { category: "Interaction Validation", subCategory: [ "Carousel", "Menu Hovering", "Video", "Download"], categoryCount: 0 }, { category: "Retail Validation", subCategory: [ "Text Missing", "PLP-PDP Mismatch"], categoryCount: 0 },{ category: "Accessibility", subCategory: ["PageTitle" ,"h1Element" ,"ImageAlt" ,"SvgImageAlt" ,"AreaImgAltCheck" ,"InputImageCheck" ,"orientation" ,"byPassBlock","byPassBlockheader","autoComplete","Emptyheading","PageLang","langPart","landmark","mainlandmark","bannerlandmark","footerlandmark","seversideImagemap","ariaDescribedby","ariaLabelledby","EmptyButton","roleNavigation","RolePresentation","buttonWithTitle","buttonWithAlt","linkwithTitle","linkwithAlt","iframeDuplicate","iframeTitle","rolevalidation","TimingAdjustable","Movingblinkingscrolling","emptyLink","DuplicateID","resize","NovideoDescription","Noaudiocaption","Novideocaption","semanticListDL","semanticListOL","semanticListUL","ULlist","DTList","highertabindex","bodyhidden","Duplicatetablename","tablescopeValidation"], categoryCount: 0 }];

	isIgnore: any = { "Image Broken Link": true, "Image Low Quality": true, "Broken Link": true, "OverLap": true, "OverLap AIML": true, "Alignment": true, "Case Sensitive": false, "PLP-PDP Mismatch": false, "Aspect Ratio Difference": true, "Pattern Difference": false, "Form Spacing": true, "Image Not Loaded": true, "OverFlow": true, "Video": true, "Carousel": true, "Menu Hovering": true, "Download": true, "Spell Validation": true, "FontValidation":true};
	isIgnoreAll: any = { "Image Broken Link": false, "Image Low Quality": true, "Broken Link": false, "OverLap": true, "OverLap AIML": true, "Alignment": true, "Case Sensitive": true, "PLP-PDP Mismatch": true, "Aspect Ratio Difference": true, "Pattern Difference": true, "Form Spacing": true, "Image Not Loaded": false, "OverFlow": true, "Video": false, "Carousel": false, "Menu Hovering": false, "Download": false , "Spell Validation": true};


	selectedError: any;
	imgLoading: any = true;
	categorySelected: any = false;
	ignoredType :any = environment.IgnoredCount;
	selectedFontIndex : any;
	jwtToken : any = null;

	
	
	constructor(private activerouter: ActivatedRoute, private service: UrlFetcherService,
		private router: Router, private element: ElementRef, private modalService: NgbModal, private keyValue : KeyValuePipe,private sortByPipe : SortByPipe) {
		this.activerouter.params.subscribe((param) => {
			this.id = param.id;
		});

		this.activerouter.queryParams.subscribe((queryParam) =>{
			this.pageURL = decodeURIComponent(queryParam.url);
			if(queryParam.jwtToken){
				this.jwtToken = decodeURIComponent(queryParam.jwtToken);
			}
		});		
	}

	ngOnInit(): void {
	
	//var url = sessionStorage.getItem("url");

	var param = {"url": this.pageURL};	
    
    this.service.postUrlToParser(param, environment.baseURL + environment.apiURL + environment.report + "/" + this.id).subscribe(async (data: any) => {
			let response = data.response.param;
			//this.deviceHeight = response.customResolutionHeight;
			//this.deviceWidth = response.customResolutionWidth;
			this.jsonReport = response.reportObject;
			this.imagePath = response.screenShotURL;
			this.thumbnailImgPath = this.imagePath.split('.').slice(0, -1).join('.');
			this.pageURL = response.pageURL;
			this.issueCount_List = this.jsonReport["Conf_page" + this.id];
			this.browser = response.browser;
		
			this.removeSessionStorageVariables();
			await setSessionStorageOnImageClick(this.jsonReport, "page" + this.id, this.ignoredIssue, this.ignoredType);
			await setImagePath(this.imagePath);
			this.setValidationEnabled();
			this.toggleValidation();
		});
		if(this.jwtToken !== null){
			window.onpopstate = function(event){
				var parent = window.parent;
				if (parent && parent.postMessage) {
					parent.postMessage("closed","*");
				}
			}
		}
	}

	openPopover() {
		this.popoverHook.open();
	}

	closePopover() {
		this.popoverHook.close();
	}

	backToReports() {
		if(this.jwtToken === null){
			this.router.navigateByUrl('/showReports');
		}
		else if(this.jwtToken !== null){
			var parent = window.parent;
			if (parent && parent.postMessage) {
				parent.postMessage("closed","*");
			}
		}
	}

	setValidationEnabled() {
		// debugger
		var positionKey = (sessionStorage.getItem("PositionAlignmentError") == "true") ? true : false;
		var imageKey = (sessionStorage.getItem("Image-BrokenLink") == "true") ? true : false;
		var caseKey = (sessionStorage.getItem("CasesensitiveError") == "true") ? true : false;

		var retailImageKey = (sessionStorage.getItem("PlpToPdpComparison") == "true") ? true : false;
		
		var aspectRatioKey = (sessionStorage.getItem("AspectRatioaredifferent") == "true") ? true : false;
		var overLapKey = (sessionStorage.getItem("OverLapError-REPEATEDCARD") == "true") ? true : false;
		//var ocrKey = (sessionStorage.getItem("Text Mismatch")  == "true") ? true : false;
		var sizeDiffernceKey = (sessionStorage.getItem("SizeDifference") == "true") ? true : false;
		var sizeBrokenLinkKey = (sessionStorage.getItem("LinkNotWorking") == "true") ? true : false;
		var sizeImageLowQuality = (sessionStorage.getItem("Imageisoflowquality") == "true") ? true : false;
		var sapcingErrorForm = (sessionStorage.getItem("SpacingError-FORM") == "true") ? true : false;
		var keyImageNotLoaded = (sessionStorage.getItem("Image-NotLoaded") == "true") ? true : false;
		var keyOverFlow = (sessionStorage.getItem("OverFlowError-REPEATEDCARD") == "true") ? true : false;
		var overLapAIML = (sessionStorage.getItem("OverlapError-REPEATEDCARD-AIML") == "true") ? true : false;
		var videoKey = (sessionStorage.getItem("Videoplayissue") == "true") ? true : false;
		var carouselBannerKey = (sessionStorage.getItem("Carouselissue") == "true") ? true : false;
		var menuHoveringKey = (sessionStorage.getItem("InteractiveMenu") == "true") ? true : false;
		var downloadKey = (sessionStorage.getItem("Downloadissue") == "true") ? true : false;
		var fontValidationKey = (sessionStorage.getItem("FontValidation") == "true") ? true : false;
		var spellErrorValidationKey = (sessionStorage.getItem("spellError") == "true") ? true : false;
		var PageTitle = (sessionStorage.getItem("PageTitle") == "true") ? true : false;
		var h1Element = (sessionStorage.getItem("h1Element") == "true") ? true : false;
		var ImageAlt = (sessionStorage.getItem("ImageAlt") == "true") ? true : false;
		var SvgImageAlt = (sessionStorage.getItem("SvgImageAlt") == "true") ? true : false;
		var AreaImgAltCheck = (sessionStorage.getItem("AreaImgAltCheck") == "true") ? true : false;
		var InputImageCheck = (sessionStorage.getItem("InputImageCheck") == "true") ? true : false;
		var orientation = (sessionStorage.getItem("orientation") == "true") ? true : false;
		var byPassBlock = (sessionStorage.getItem("byPassBlock") == "true") ? true : false;
		var byPassBlockheader = (sessionStorage.getItem("byPassBlockheader") == "true") ? true : false;
		var autoComplete = (sessionStorage.getItem("autoComplete") == "true") ? true : false;
		var Emptyheading = (sessionStorage.getItem("Emptyheading") == "true") ? true : false;
		var PageLang = (sessionStorage.getItem("PageLang") == "true") ? true : false;
		var langPart = (sessionStorage.getItem("langPart") == "true") ? true : false;
		var landmark = (sessionStorage.getItem("landmark") == "true") ? true : false;
		var mainlandmark = (sessionStorage.getItem("mainlandmark") == "true") ? true : false;
		var bannerlandmark = (sessionStorage.getItem("bannerlandmark") == "true") ? true : false;
		var footerlandmark = (sessionStorage.getItem("footerlandmark") == "true") ? true : false;
		var seversideImagemap = (sessionStorage.getItem("seversideImagemap") == "true") ? true : false;
		var ariaDescribedby = (sessionStorage.getItem("ariaDescribedby") == "true") ? true : false;
		var ariaLabelledby = (sessionStorage.getItem("ariaLabelledby") == "true") ? true : false;
		var EmptyButton = (sessionStorage.getItem("EmptyButton") == "true") ? true : false;
		var roleNavigation = (sessionStorage.getItem("roleNavigation") == "true") ? true : false;
		var RolePresentation = (sessionStorage.getItem("RolePresentation") == "true") ? true : false;
		var buttonWithTitle = (sessionStorage.getItem("buttonWithTitle") == "true") ? true : false;
		var buttonWithAlt = (sessionStorage.getItem("buttonWithAlt") == "true") ? true : false;
		var linkwithTitle = (sessionStorage.getItem("linkwithTitle") == "true") ? true : false;
		var linkwithAlt = (sessionStorage.getItem("linkwithAlt") == "true") ? true : false;
		var iframeDuplicate = (sessionStorage.getItem("iframeDuplicate") == "true") ? true : false;
		var iframeTitle = (sessionStorage.getItem("iframeTitle") == "true") ? true : false;
		var rolevalidation = (sessionStorage.getItem("rolevalidation") == "true") ? true : false;
		var TimingAdjustable = (sessionStorage.getItem("TimingAdjustable") == "true") ? true : false;
		var Movingblinkingscrolling = (sessionStorage.getItem("Movingblinkingscrolling") == "true") ? true : false;
		var emptyLink = (sessionStorage.getItem("emptyLink") == "true") ? true : false;
		var DuplicateID = (sessionStorage.getItem("DuplicateID") == "true") ? true : false;
		var resize = (sessionStorage.getItem("resize") == "true") ? true : false;
		var NovideoDescription = (sessionStorage.getItem("NovideoDescription") == "true") ? true : false;
		var Noaudiocaption = (sessionStorage.getItem("Noaudiocaption") == "true") ? true : false;
		var Novideocaption = (sessionStorage.getItem("Novideocaption") == "true") ? true : false;
		var semanticListDL = (sessionStorage.getItem("semanticListDL") == "true") ? true : false;
		var semanticListOL = (sessionStorage.getItem("semanticListOL") == "true") ? true : false;
		var semanticListUL = (sessionStorage.getItem("semanticListUL") == "true") ? true : false;
		var ULlist = (sessionStorage.getItem("ULlist") == "true") ? true : false;
		var DTList = (sessionStorage.getItem("DTList") == "true") ? true : false;
		var highertabindex = (sessionStorage.getItem("highertabindex") == "true") ? true : false;
		var bodyhidden = (sessionStorage.getItem("bodyhidden") == "true") ? true : false;
		var Duplicatetablename = (sessionStorage.getItem("Duplicatetablename") == "true") ? true : false;
		var tablescopeValidation = (sessionStorage.getItem("tablescopeValidation") == "true") ? true : false;


		var countUpdate = this.ignoredIssue ? this.issueCount_List[this.ignoredType] : this.issueCount_List;
		if (positionKey) {
			this.countMap["Alignment"] = countUpdate[this.validationNameMap["Alignment"]];
			this.isValidationEnabled["Alignment"] = true;

		}

		if (imageKey) {
			this.countMap["Image Broken Link"] = countUpdate[this.validationNameMap["Image Broken Link"]];
			this.isValidationEnabled["Image Broken Link"] = true;

		}

		if (caseKey) {
			this.countMap["Case Sensitive"] = countUpdate[this.validationNameMap["Case Sensitive"]];
			this.isValidationEnabled["Case Sensitive"] = true;
		}

		if (retailImageKey) {
			this.countMap["PLP-PDP Mismatch"] = countUpdate[this.validationNameMap["PLP-PDP Mismatch"]];
			this.isValidationEnabled["PLP-PDP Mismatch"] = true;
		}

		if (aspectRatioKey) {
			this.countMap["Aspect Ratio Difference"] = countUpdate[this.validationNameMap["Aspect Ratio Difference"]];
			this.isValidationEnabled["Aspect Ratio Difference"] = true;

		}
		if (overLapKey) {
			this.countMap["OverLap"] = countUpdate[this.validationNameMap["OverLap"]];
			this.isValidationEnabled["OverLap"] = true;
		}

		if (sizeDiffernceKey) {
			this.countMap["Pattern Difference"] = countUpdate[this.validationNameMap["Pattern Difference"]];
			this.isValidationEnabled["Pattern Difference"] = true;

		}
		if (sizeBrokenLinkKey) {
			this.countMap["Broken Link"] = countUpdate[this.validationNameMap["Broken Link"]];
			this.isValidationEnabled["Broken Link"] = true;
		}
		if (sizeImageLowQuality) {
			this.countMap["Image Low Quality"] = countUpdate[this.validationNameMap["Image Low Quality"]];
			this.isValidationEnabled["Image Low Quality"] = true;
		}
		if (sapcingErrorForm) {
			this.countMap["Form Spacing"] = countUpdate[this.validationNameMap["Form Spacing"]];
			this.isValidationEnabled["Form Spacing"] = true;
		}
		if (keyImageNotLoaded) {
			this.countMap["Image Not Loaded"] = countUpdate[this.validationNameMap["Image Not Loaded"]];
			this.isValidationEnabled["Image Not Loaded"] = true;
		}
		if (keyOverFlow) {
			this.countMap["OverFlow"] = countUpdate[this.validationNameMap["OverFlow"]];
			this.isValidationEnabled["OverFlow"] = true;
		}

		if (overLapAIML) {
			this.countMap["OverLap AIML"] = countUpdate[this.validationNameMap["OverLap AIML"]];
			this.isValidationEnabled["OverLap AIML"] = true;
		}

		if (downloadKey) {
			this.countMap["Download"] = countUpdate[this.validationNameMap["Download"]];
			this.isValidationEnabled["Download"] = true;
		}

		if (videoKey) {
			this.countMap["Video"] = countUpdate[this.validationNameMap["Video"]];
			this.isValidationEnabled["Video"] = true;

		}

		if (carouselBannerKey) {
			this.countMap["Carousel"] = countUpdate[this.validationNameMap["Carousel"]];
			this.isValidationEnabled["Carousel"] = true;

		}

		if (menuHoveringKey) {
			this.countMap["Menu Hovering"] = countUpdate[this.validationNameMap["Menu Hovering"]];
			this.isValidationEnabled["Menu Hovering"] = true;

		} 

		if (fontValidationKey) {			
			this.isValidationEnabled["FontValidation"] = true;
			
			if(countUpdate === undefined || countUpdate)
			{			
				this.countMap["FontValidation"] = 1;				
			}
			
		}

		if (spellErrorValidationKey) {
			this.countMap["Spell Validation"] = countUpdate[this.validationNameMap["Spell Validation"]];
			this.isValidationEnabled["Spell Validation"] = true;

		}

		if (PageTitle) {
			this.countMap["PageTitle"] = countUpdate[this.validationNameMap["PageTitle"]];
			this.isValidationEnabled["PageTitle"] = true;

		}
		if (h1Element) {
			this.countMap["h1Element"] = countUpdate[this.validationNameMap["h1Element"]];
			this.isValidationEnabled["h1Element"] = true;

		}
		if (ImageAlt) {
			this.countMap["ImageAlt"] = countUpdate[this.validationNameMap["ImageAlt"]];
			this.isValidationEnabled["ImageAlt"] = true;

		}
		if (SvgImageAlt) {
			this.countMap["SvgImageAlt"] = countUpdate[this.validationNameMap["SvgImageAlt"]];
			this.isValidationEnabled["SvgImageAlt"] = true;

		}
		if (AreaImgAltCheck) {
			this.countMap["AreaImgAltCheck"] = countUpdate[this.validationNameMap["AreaImgAltCheck"]];
			this.isValidationEnabled["AreaImgAltCheck"] = true;

		}
		if (InputImageCheck) {
			this.countMap["InputImageCheck"] = countUpdate[this.validationNameMap["InputImageCheck"]];
			this.isValidationEnabled["InputImageCheck"] = true;

		}
		if (orientation) {
			this.countMap["orientation"] = countUpdate[this.validationNameMap["orientation"]];
			this.isValidationEnabled["orientation"] = true;

		}

		if (byPassBlock) {
			this.countMap["byPassBlock"] = countUpdate[this.validationNameMap["byPassBlock"]];
			this.isValidationEnabled["byPassBlock"] = true;

		}
		if (byPassBlockheader) {
			this.countMap["byPassBlockheader"] = countUpdate[this.validationNameMap["byPassBlockheader"]];
			this.isValidationEnabled["byPassBlockheader"] = true;

		}
		if (autoComplete) {
			this.countMap["autoComplete"] = countUpdate[this.validationNameMap["autoComplete"]];
			this.isValidationEnabled["autoComplete"] = true;

		}
		if (Emptyheading) {
			this.countMap["Emptyheading"] = countUpdate[this.validationNameMap["Emptyheading"]];
			this.isValidationEnabled["Emptyheading"] = true;

		}
		if (PageLang) {
			this.countMap["PageLang"] = countUpdate[this.validationNameMap["PageLang"]];
			this.isValidationEnabled["PageLang"] = true;

		}
		if (langPart) {
			this.countMap["langPart"] = countUpdate[this.validationNameMap["langPart"]];
			this.isValidationEnabled["langPart"] = true;

		}
		if (landmark) {
			this.countMap["landmark"] = countUpdate[this.validationNameMap["landmark"]];
			this.isValidationEnabled["landmark"] = true;

		}

		if (mainlandmark) {
			this.countMap["mainlandmark"] = countUpdate[this.validationNameMap["mainlandmark"]];
			this.isValidationEnabled["mainlandmark"] = true;

		}
		if (bannerlandmark) {
			this.countMap["bannerlandmark"] = countUpdate[this.validationNameMap["bannerlandmark"]];
			this.isValidationEnabled["bannerlandmark"] = true;

		}
		if (footerlandmark) {
			this.countMap["footerlandmark"] = countUpdate[this.validationNameMap["footerlandmark"]];
			this.isValidationEnabled["footerlandmark"] = true;

		}
		if (seversideImagemap) {
			this.countMap["seversideImagemap"] = countUpdate[this.validationNameMap["seversideImagemap"]];
			this.isValidationEnabled["seversideImagemap"] = true;

		}
		if (ariaDescribedby) {
			this.countMap["ariaDescribedby"] = countUpdate[this.validationNameMap["ariaDescribedby"]];
			this.isValidationEnabled["ariaDescribedby"] = true;

		}
		if (ariaLabelledby) {
			this.countMap["ariaLabelledby"] = countUpdate[this.validationNameMap["ariaLabelledby"]];
			this.isValidationEnabled["ariaLabelledby"] = true;

		}
		if (EmptyButton) {
			this.countMap["EmptyButton"] = countUpdate[this.validationNameMap["EmptyButton"]];
			this.isValidationEnabled["EmptyButton"] = true;

		}

		if (roleNavigation) {
			this.countMap["roleNavigation"] = countUpdate[this.validationNameMap["roleNavigation"]];
			this.isValidationEnabled["roleNavigation"] = true;

		}
		if (RolePresentation) {
			this.countMap["RolePresentation"] = countUpdate[this.validationNameMap["RolePresentation"]];
			this.isValidationEnabled["RolePresentation"] = true;

		}
		if (buttonWithTitle) {
			this.countMap["buttonWithTitle"] = countUpdate[this.validationNameMap["buttonWithTitle"]];
			this.isValidationEnabled["buttonWithTitle"] = true;

		}
		if (buttonWithAlt) {
			this.countMap["buttonWithAlt"] = countUpdate[this.validationNameMap["buttonWithAlt"]];
			this.isValidationEnabled["buttonWithAlt"] = true;

		}
		if (linkwithTitle) {
			this.countMap["linkwithTitle"] = countUpdate[this.validationNameMap["linkwithTitle"]];
			this.isValidationEnabled["linkwithTitle"] = true;

		}
		if (linkwithAlt) {
			this.countMap["linkwithAlt"] = countUpdate[this.validationNameMap["linkwithAlt"]];
			this.isValidationEnabled["linkwithAlt"] = true;

		}
		if (iframeDuplicate) {
			this.countMap["iframeDuplicate"] = countUpdate[this.validationNameMap["iframeDuplicate"]];
			this.isValidationEnabled["iframeDuplicate"] = true;

		}

		if (iframeTitle) {
			this.countMap["iframeTitle"] = countUpdate[this.validationNameMap["iframeTitle"]];
			this.isValidationEnabled["iframeTitle"] = true;

		}
		if (rolevalidation) {
			this.countMap["rolevalidation"] = countUpdate[this.validationNameMap["rolevalidation"]];
			this.isValidationEnabled["rolevalidation"] = true;

		}
		if (TimingAdjustable) {
			this.countMap["TimingAdjustable"] = countUpdate[this.validationNameMap["TimingAdjustable"]];
			this.isValidationEnabled["TimingAdjustable"] = true;

		}
		if (Movingblinkingscrolling) {
			this.countMap["Movingblinkingscrolling"] = countUpdate[this.validationNameMap["Movingblinkingscrolling"]];
			this.isValidationEnabled["Movingblinkingscrolling"] = true;

		}
		if (emptyLink) {
			this.countMap["emptyLink"] = countUpdate[this.validationNameMap["emptyLink"]];
			this.isValidationEnabled["emptyLink"] = true;

		}
		if (DuplicateID) {
			this.countMap["DuplicateID"] = countUpdate[this.validationNameMap["DuplicateID"]];
			this.isValidationEnabled["DuplicateID"] = true;

		}
		if (resize) {
			this.countMap["resize"] = countUpdate[this.validationNameMap["resize"]];
			this.isValidationEnabled["resize"] = true;

		}

		if (NovideoDescription) {
			this.countMap["NovideoDescription"] = countUpdate[this.validationNameMap["NovideoDescription"]];
			this.isValidationEnabled["NovideoDescription"] = true;

		}
		if (Noaudiocaption) {
			this.countMap["Noaudiocaption"] = countUpdate[this.validationNameMap["Noaudiocaption"]];
			this.isValidationEnabled["Noaudiocaption"] = true;

		}
		if (Novideocaption) {
			this.countMap["Novideocaption"] = countUpdate[this.validationNameMap["Novideocaption"]];
			this.isValidationEnabled["Novideocaption"] = true;

		}
		if (semanticListDL) {
			this.countMap["semanticListDL"] = countUpdate[this.validationNameMap["semanticListDL"]];
			this.isValidationEnabled["semanticListDL"] = true;

		}
		if (semanticListOL) {
			this.countMap["semanticListOL"] = countUpdate[this.validationNameMap["semanticListOL"]];
			this.isValidationEnabled["semanticListOL"] = true;

		}
		if (semanticListUL) {
			this.countMap["semanticListUL"] = countUpdate[this.validationNameMap["semanticListUL"]];
			this.isValidationEnabled["semanticListUL"] = true;

		}
		if (ULlist) {
			this.countMap["ULlist"] = countUpdate[this.validationNameMap["ULlist"]];
			this.isValidationEnabled["ULlist"] = true;

		}

		if (DTList) {
			this.countMap["DTList"] = countUpdate[this.validationNameMap["DTList"]];
			this.isValidationEnabled["DTList"] = true;

		}
		if (highertabindex) {
			this.countMap["highertabindex"] = countUpdate[this.validationNameMap["highertabindex"]];
			this.isValidationEnabled["highertabindex"] = true;

		}
		if (bodyhidden) {
			this.countMap["bodyhidden"] = countUpdate[this.validationNameMap["bodyhidden"]];
			this.isValidationEnabled["bodyhidden"] = true;

		}
		if (Duplicatetablename) {
			this.countMap["Duplicatetablename"] = countUpdate[this.validationNameMap["Duplicatetablename"]];
			this.isValidationEnabled["Duplicatetablename"] = true;

		}
		if (tablescopeValidation) {
			this.countMap["tablescopeValidation"] = countUpdate[this.validationNameMap["tablescopeValidation"]];
			this.isValidationEnabled["tablescopeValidation"] = true;

		}

		this.setValidationCategories();
	}

	async isSelected(validationName) {

		if (!this.reportView) {
			this.popoverHook.close();
			var canvasClass = document.getElementById("imageCanvas");
			canvasClass.classList.add("imageConatainer")

		}
		// debugger
		this.popoverHook.close();
		var canvasClass = document.getElementById("imageCanvas");
		canvasClass.classList.add("imageConatainer")
		this.selectedError = validationName;
		this.categorySelected = true;
		this.isValidationSelected = {
			"Image Broken Link": false,
			"Image Low Quality": false,
			"Broken Link": false,
			"OverLap": false,
			"Alignment": false,
			"Case Sensitive": false,

			"PLP-PDP Mismatch": false,

			"Aspect Ratio Difference": false,
			"Pattern Difference": false,
			"Form Spacing": false,
			"Image Not Loaded": false,
			"OverFlow": false,
			"OverLap AIML": false,
			"Video": false,
			"Carousel": false,
			"Menu Hovering": false,
			"Download": false,
			"FontValidation":false,
			"SpellError": false,
			"PageTitle" :false,
			"h1Element" :false,
			"ImageAlt" :false,
			"SvgImageAlt" :false,
			"AreaImgAltCheck" :false,
			"InputImageCheck" :false,
			"orientation" :false,
			"byPassBlock":false,
			"byPassBlockheader":false,
			"autoComplete":false,
			"Emptyheading":false,
			"PageLang":false,
			"langPart":false,
			"landmark":false,
			"mainlandmark":false,
			"bannerlandmark":false,
			"footerlandmark":false,
			"seversideImagemap":false,
			"ariaDescribedby":false,
			"ariaLabelledby":false,
			"EmptyButton":false,
			"roleNavigation":false,
			"RolePresentation":false,
			"buttonWithTitle":false,
			"buttonWithAlt":false,
			"linkwithTitle":false,
			"linkwithAlt":false,
			"iframeDuplicate":false,
			"iframeTitle":false,
			"rolevalidation":false,
			"TimingAdjustable":false,
			"Movingblinkingscrolling":false,
			"emptyLink":false,
			"DuplicateID":false,
			"resize":false,
			"NovideoDescription":false,
			"Noaudiocaption":false,
			"Novideocaption":false,
			"semanticListDL":false,
			"semanticListOL":false,
			"semanticListUL":false,
			"ULlist":false,
			"DTList":false,
			"highertabindex":false,
			"bodyhidden":false,
			"Duplicatetablename":false,
			"tablescopeValidation":false
		};

		this.isValidationSelected[validationName] = true;
		this.showFontValidationMetaData=false;

		if(validationName == "FontValidation")
		{
			this.showFontValidationMetaData=true;
			this.fontMetaDataDetailsView= this.fontMetaDataDetails;				
			this.showMoreData = "";
			this.countForNxtPrev = -1
			this.isFontFamilySelected(this.fontMetaDataDetails[0].key, 0);
			
			
		}
		else{					
			this.showMoreData = "";
			if (!this.reportView) {
				this.countForNxtPrev = -1
			}
			else {
				await getImageRepresentationNew(this.validationNameMap[validationName], "page" + this.id, this.jsonReport, this.ignoredIssue, environment.IgnoredKey).then(function (jsonObject) {
					jsonObjForEachCategory = jsonObject;
				})
			}					
		}

		this.isValidationSelected[validationName] = true;
		if (!this.reportView) {
			await setInitialParamaters(this.jsonReport, "page" + this.id, this.imagePath, this.validationNameMap[validationName], this.ignoredIssue,environment.IgnoredKey);
		}
	}
	
	async isFontFamilySelected(fontFamilyName,colorIndex){
		
		this.closePopover();
		this.isFontDataLoading = true;		
		console.log(fontFamilyName);
			
		setInitialParamatersForFontValidation(this.fontFamilyDetailsJson[fontFamilyName], "page" + this.id, this.ignoredIssue,environment.IgnoredKey, this.jsonReport,this.dynamicColorMaps[colorIndex],fontFamilyName);
		this.isFontDataLoading = false;				
		this.selectedFontIndex = colorIndex;
		
	}

	async nextClick() {
	    
		if (!this.reportView) {
			this.openPopover();
		}
		if (this.countForNxtPrev !== jsonObjForEachCategory.length) {
			var x; var y; var width; var height;
			var errorDetails;
			this.countForNxtPrev = (this.countForNxtPrev + 1) % jsonObjForEachCategory.length;
			// increment your counter	// the modulus (%) operator resets the counter to 0
			// this.countForNxtPrev >= 1 ? document.getElementById("prev").style.display = "block" : document.getElementById("prev").style.display = "none";

			x=jsonObjForEachCategory[this.countForNxtPrev].x== undefined ? jsonObjForEachCategory[this.countForNxtPrev].X:jsonObjForEachCategory[this.countForNxtPrev].x;
			y=jsonObjForEachCategory[this.countForNxtPrev].y== undefined ? jsonObjForEachCategory[this.countForNxtPrev].Y:jsonObjForEachCategory[this.countForNxtPrev].y;
			width=jsonObjForEachCategory[this.countForNxtPrev].width== undefined? jsonObjForEachCategory[this.countForNxtPrev].Width:jsonObjForEachCategory[this.countForNxtPrev].width;
			height=jsonObjForEachCategory[this.countForNxtPrev].height== undefined ? jsonObjForEachCategory[this.countForNxtPrev].Height:jsonObjForEachCategory[this.countForNxtPrev].height;
			
			errorDetails =
				[
					{ x: parseInt(x), y: parseInt(y), width: parseInt(width), height: parseInt(height) }

				];
			this.falsePositive = jsonObjForEachCategory[this.countForNxtPrev];
			console.log(jsonObjForEachCategory[this.countForNxtPrev].uniqueCategoryKey, "selected key")
			let categoryIssueName = jsonObjForEachCategory[this.countForNxtPrev].uniqueCategoryKey.split('____');
			if (categoryIssueName[0].includes("PositionAlignmentError")) {
				categoryIssueName[0] = "PositionAlignmentError";
			}
			this.staticInfo = this.categoryDescription[categoryIssueName[0]];
			if (categoryIssueName[0].includes("FontValidation")) {
				
				var text= jsonObjForEachCategory[this.countForNxtPrev].fontFamilyName;
				this.staticInfo = "The Selected Font Family "+text.bold()+" has been  used by the highlighted text"

				setTimeout(() => {
					this.perfectScroll.directiveRef.scrollTo(this.falsePositive.x, this.falsePositive.y);
					this.perfectScroll.directiveRef.update();
				}, 100);
				
			}
			this.setMoreInfo(jsonObjForEachCategory[this.countForNxtPrev], this.validationNameMap[this.selectedError]);
			if (this.reportView) {
				this.thumbImg = this.thumbnailImages[this.countForNxtPrev];
				var myElement = document.getElementById(this.selectedError);

				myElement.scrollLeft += 50;
				if (this.countForNxtPrev == 0) {
					myElement.scrollTo(0, 0);

				}
			}
			var colorCode = this.selectedError;
			await drawRectancle(errorDetails, errorCaption, colorCode);
			await timeOutFnPrevNext(errorDetails);
			setTimeout(()=>{
				this.perfectScroll.directiveRef.scrollToElement('.boxe');
				this.perfectScroll.directiveRef.update();
			},100);
		}
		else {
			document.getElementById("next").style.display = "none";
			this.closePopover();
		}
	}

	async prevClick() {
		if (!this.reportView) {
			this.openPopover();
		}
		// let jsonObjFilterList = jsonObjForEachCategory.filter(obj => obj.isFalsePositive === false);
		if (this.countForNxtPrev > 0 && jsonObjForEachCategory.length > 0) {

			// $('.overlaye').show();
			// $('.boxe').show();
			var x; var y; var width; var height;
			var errorDetails;
			//console.log(this.countForNxtPrev,"counter in prev ")
			this.countForNxtPrev = (this.countForNxtPrev - 1) % jsonObjForEachCategory.length; // increment your counter	// the modulus (%) operator resets the counter to 0
			//console.log(this.countForNxtPrev,"counter in prev reduce")
			if (!(jsonObjForEachCategory[this.countForNxtPrev].isFalsePositive)) {

				x=jsonObjForEachCategory[this.countForNxtPrev].x== undefined ? jsonObjForEachCategory[this.countForNxtPrev].X:jsonObjForEachCategory[this.countForNxtPrev].x;
				y=jsonObjForEachCategory[this.countForNxtPrev].y== undefined ? jsonObjForEachCategory[this.countForNxtPrev].Y:jsonObjForEachCategory[this.countForNxtPrev].y;
				width=jsonObjForEachCategory[this.countForNxtPrev].width== undefined? jsonObjForEachCategory[this.countForNxtPrev].Width:jsonObjForEachCategory[this.countForNxtPrev].width;
				height=jsonObjForEachCategory[this.countForNxtPrev].height== undefined ? jsonObjForEachCategory[this.countForNxtPrev].Height:jsonObjForEachCategory[this.countForNxtPrev].height;
				
				errorDetails =
					[
						{ x: parseInt(x), y: parseInt(y), width: parseInt(width), height: parseInt(height) }

					];
				
				this.falsePositive = jsonObjForEachCategory[this.countForNxtPrev];
				let categoryIssueName = jsonObjForEachCategory[this.countForNxtPrev].uniqueCategoryKey.split('____');
				if (categoryIssueName[0].includes("PositionAlignmentError")) {
					categoryIssueName[0] = "PositionAlignmentError";
				}
				this.staticInfo = this.categoryDescription[categoryIssueName[0]];
				if (categoryIssueName[0].includes("FontValidation")) {
				
					var text= jsonObjForEachCategory[this.countForNxtPrev].fontFamilyName;
					this.staticInfo = "The Selected Font Family "+text.bold()+" has been  used by the highlighted text"
					
				}
				this.setMoreInfo(jsonObjForEachCategory[this.countForNxtPrev], this.validationNameMap[this.selectedError]);
				if (this.reportView) {
					this.thumbImg = this.thumbnailImages[this.countForNxtPrev];
					var myElement = document.getElementById(this.selectedError);
					myElement.scrollLeft -= 50;
				}

				//console.log(this.countForNxtPrev,"counter in prev reduce err",errorDetails)
				var colorCode = this.selectedError;
				await drawRectancle(errorDetails, errorCaption, colorCode);
				await timeOutFnPrevNext(errorDetails);
				setTimeout(()=>{
					this.perfectScroll.directiveRef.scrollToElement('.boxe');
					this.perfectScroll.directiveRef.update();
				},100);
				this.countForNxtPrev >= 1 ? document.getElementById("prev").style.display = "block" : document.getElementById("prev").style.display = "none";
			}

		}
		else {
			document.getElementById("prev").style.display = "none";
		}
	}

	showInfo(Infomodel: any) {
		this.closePopover();
		this.modalService.open(Infomodel, { size: 'lg', centered: true }).result.then((result) => {
			if (result) {
				this.modalService.dismissAll();
			}
			else {
				this.openPopover();
			}

		}).catch(err => {
			this.openPopover();
		})
	}
	markIssue() {
		console.log("inside### mark issue");
	}
	//toggle removed Issue Page 

	toggleValidation() {
		this.showFontValidationMetaData=this.showFontValidationMetaData;
		if (this.jsonReport["Conf_page" + this.id][this.ignoredType]) {
			this.btnDisabled = false;
		}

		else {
			this.btnDisabled = true;

		}

	}



	async ignoredIssuesToggle() {
		
		
		this.ignoredIssue = !this.ignoredIssue;
		
		this.countMap = { 'Image Broken Link': 0, "Image Low Quality": 0, "Broken Link": 0, "OverLap": 0, "OverLap AIML": 0, "Alignment": 0, "Case Sensitive": 0, "PLP-PDP Mismatch": 0, "Aspect Ratio Difference": 0, "Pattern Difference": 0, "Form Spacing": 0, "Image Not Loaded": 0, "OverFlow": 0, "Video": 0, "Carousel": 0, "Menu Hovering": 0, "Download": 0 };
		this.isValidationEnabled = {
			"Image Broken Link": false,
			"Image Low Quality": false,
			"Broken Link": false,
			"OverLap": false,
			"Alignment": false,
			"Case Sensitive": false,

			"PLP-PDP Mismatch": false,
			
			"Aspect Ratio Difference": false,
			"Pattern Difference": false,
			"Form Spacing": false,
			"Image Not Loaded": false,
			"OverFlow": false,
			"OverLap AIML": false,
			"Video": false,
			"Carousel": false,
			"Menu Hovering": false,
			"Download": false,
			"FontValidation":false,
			"Spell Validation": false,
			"Accessibility": false
		};

		if (!this.reportView) {
			this.closePopover();
		}
		this.removeSessionStorageVariables();

		await setSessionStorageOnImageClick(this.jsonReport, "page" + this.id, this.ignoredIssue, this.ignoredType);
		await setSessionStorageOnImageClick(this.fontMetaDataDetails, "page" + this.id, this.ignoredIssue,"fontFlag");
		await setImagePath(this.imagePath);

		this.isValidationSelected[this.selectedError] = false;

		this.setValidationEnabled();

		if (this.reportView) {
			await this.setCategoryImg(this.firstSubCategoryName);

			await onViewIgnore(this.ignoredIssue);
		}



	}
	removeIssue(jsonIssue: any, model: any, multi: boolean) {
		this.closePopover();
		console.log("inside### remove issue");
		let categoryName = jsonIssue.uniqueCategoryKey.split('____');
		let configLabel = this.configLabelMap[categoryName[0]];
		if(categoryName[0] === "FontValidation")
		{
			jsonIssue.uniqueCategoryKey = categoryName[1]
		}

		console.log(configLabel, "configLabel", this.configLabelMap[categoryName])
		this.modalService.open(model, { size: 'sm', centered: true }).result.then((result) => {
			if (result) {
				let params = { 'url': this.pageURL};

				let URL = environment.baseURL + environment.apiURL + environment.report + environment.ignoreIssue + "/" + this.id + "/" + jsonIssue.uniqueCategoryKey + "/" + multi + "/" + configLabel;

				this.service.postUrlToParser(params, URL).subscribe(async (data: any) => {

					if (data.response.status) {
						this.jsonReport = data.response.param.reportObject;
						console.log("Json Report " + this.jsonReport);
						await getImageRepresentationNew(categoryName[0], "page" + this.id, this.jsonReport, this.ignoredIssue,environment.IgnoredKey);

						if (jsonObjForEachCategory.length > 0) {
							this.countForNxtPrev = this.countForNxtPrev - 1;
							this.issueCount_List = this.jsonReport["Conf_page" + this.id];
							this.setValidationEnabled();
							if (this.reportView) {
								await this.setCategoryImg(this.validationNamePageLoad[categoryName[0]]);
							}
							this.nextClick();
						}
						else {

							if (!this.reportView) {
								await setInitialParamaters(this.jsonReport, "page" + this.id, this.imagePath, categoryName[0], this.ignoredIssue,environment.IgnoredKey);
							}
							this.issueCount_List = this.jsonReport["Conf_page" + this.id];
							await setSessionStorageOnImageClick(this.jsonReport, "page" + this.id, this.ignoredIssue, this.ignoredType);
							await setImagePath(this.imagePath);
							this.setValidationEnabled();
							sessionStorage.removeItem(categoryName[0]);

							if (this.reportView) {
								await this.setCategoryImg(this.validationNamePageLoad[categoryName[0]]);
								await this.setonLoadImg();
							}
							else {
								await setImagePath(this.imagePath);
							}

						}
						this.toggleValidation();
					}

				})
				this.modalService.dismissAll();

			}
			else {
				if (!this.reportView) {
					this.openPopover();
				}
			}


		}).catch(err => {
			if (!this.reportView) {
				this.openPopover();
			}
		})
	}

	showMoreInfo() {
		this.showMoreInfoCheck = true;
	}

	showLessInfo() {
		this.showMoreInfoCheck = false;
	}


	setMoreInfo(highlightedJson: any, categoryIssueName: any) {


		switch (categoryIssueName) {

			case ("CasesensitiveError"):

				//this.showMoreData = "The text " + highlightedJson.Text.bold() + " is of " + highlightedJson.CaseType.bold() + " and is not matching with the immediate group of text";
				this.showMoreData = "The text " + highlightedJson.Text.bold()  + " is not matching with the immediate group of text case "+ highlightedJson.CaseType.bold();
				break;


			case ("PlpToPdpComparison"):

				this.showMoreData = "";
				if(highlightedJson.PdpImageUrl !== ""){
					this.showMoreData += "The image url missing in the Product Description Page are<br>"
					this.showMoreData += highlightedJson.PdpImageUrl.bold();
				}	
				if(highlightedJson.PdpErrorText !== ""){
					this.showMoreData += "<br><br>The text missing in the Product Description Page are<br>"
					this.showMoreData += highlightedJson.PdpErrorText.bold();
				}			
				//this.showMoreData = "The image url missing in the Product Description Page are<br>"  + " are " + "<br>The text " + highlightedJson.PdpErrorText.bold()  + " is missing in the Product Description Page";
				break;

			case "Downloadissue":
				let innerText = highlightedJson.Text ? highlightedJson.Text : ''
				this.showMoreData = `The highlighted element ${innerText.bold()} is not working`;
				break;

			case ("OverLapError-REPEATEDCARD"):

				if (highlightedJson.Element1Text.length > 0 && highlightedJson.Element2Text.length > 0) {

					this.showMoreData = `Type of Overlap : ` + highlightedJson.ElementCategory + `<div><span>Text 1 : </span>` + `<span>` + highlightedJson.Element1Text + `</span></div>` + `<div><span>Text 2 : </span>` + `<span>` + highlightedJson.Element2Text + `</span></div>`
					sessionStorage.removeItem("Downloadissue");
				}
				else {
					console.log(highlightedJson.Element1Text.length, "highlightedJson.Element1Text.length", highlightedJson.Element1Text, highlightedJson.Element2Text)
					let text = highlightedJson.Element1Text.length > 0 ? highlightedJson.Element1Text : highlightedJson.Element2Text;
					this.showMoreData = `Type of Overlap : ` + highlightedJson.ElementCategory + `<div><span>Text : </span>` + `<span>` + text + `</span></div>`
				}


				break;

			case ("LinkNotWorking"):
				//if (highlightedJson.LinkError) {
					this.showMoreData = `Response Code : ` + highlightedJson.Status + `<div><div><span>Link URL : </span>` + `<span>` + highlightedJson.url + `</span></div>`
				//}
				break;
			case ("Imageisoflowquality"):

				this.showMoreData = `Displayed Image H : W =  ` + Math.round(highlightedJson.height) + ' : ' + Math.round(highlightedJson.width) + '</span></div>'
					+ '<div><span> Actual Image H : W =</span>' + '<span>' + Math.round(highlightedJson.ActualHeight) + ' : ' + Math.round(highlightedJson.ActualWidth) + '</span></div>'
					+ '<div><span> Image URL : </span>' + '<span>' + highlightedJson.ImageURL + '</span></div>'
					+ '<div><span> Width Ratio Difference : </span>' + '<span>' + highlightedJson.WidthRatioDifference + '</span></div>'
					+ '<div><span> Height Ratio Difference : </span>' + '<span>' + highlightedJson.HeightRatioDifference + '</span></div>'
				break;
			case ("Videoplayissue"):

				this.showMoreData = `Video URL : ` + '<span>' + highlightedJson.url + '</span>'
				break;


			case ("Image-BrokenLink"):

				this.showMoreData = `Response Code : ` + highlightedJson.Status
					+ '<div><span>Image URL : </span>' + '<span>' + highlightedJson.url + '</span></div>'

				break;

			case ("Carouselissue"):

				this.showMoreData = `Locator : ` + highlightedJson.Locator + '<div><span> Locator CSS Selector :</span>' + '<span>' + highlightedJson.Locator_CSS + '</span></div>'
				break;
			case ("SizeDifference"):

				this.showMoreData = `Parent Locator :` + highlightedJson.parentLocator
					+ '<div><span>Pattern (H : W) of Issue Element : </span>' + '<span>' + Math.round(highlightedJson.height) + '</span> <b>:</b>' + '<span>' + Math.round(highlightedJson.width) + '</span></div>'

				break;
			case ("AspectRatioaredifferent"):

				this.showMoreData = `Image Rendered H : W= ` + Math.round(highlightedJson.RenderedHeight) + ' : ' + Math.round(highlightedJson.RenderedWidth)
					+ '<div><span> Image Original H : W = </span>' + '<span>' + Math.round(highlightedJson.ActualHeight) + ' : ' + Math.round(highlightedJson.ActualWidth) + '</span></div>'
					+ '<div><span> Image URL : </span>' + '<span>' + highlightedJson.ImageURL + '</span></div>'
					+ '<div><span> Image Aspect Ratio : </span>' + '<span>' + highlightedJson.ImageAspectRatio + '</span></div>'
					+ '<div><span> Image Actual Aspect Ratio : </span>' + '<span>' + highlightedJson.ImageActualAspectRatio + '</span></div>'


				break;
			case ("PositionAlignmentError"):
				if (highlightedJson.PositionType == "VERTICALMENU") {
					this.showMoreData = `Issue Text : ` + '<span>' + highlightedJson.ElementText + '</span>'
						+ '<div><span>Classified As : </span>' + '<span>' + highlightedJson.PositionType + '</span></div>'
						+ '<div><span>Issue Text Position X <b>:</b> Y = ' + Math.round(highlightedJson.x) + ' <b>: </b>' + Math.round(highlightedJson.y) + '</span></div>'
						+ '<div><span>Reference Value X : ' + highlightedJson.ReferenceValue + '</span></div>'
				}
				else {
					this.showMoreData = `Issue Text : ` + '<span>' + highlightedJson.ElementText + '</span>'
						+ '<div><span>Classified As : </span>' + '<span>' + highlightedJson.PositionType + '</span></div>'
						+ '<div><span>Issue Text Position X <b>:</b> Y = ' + Math.round(highlightedJson.x) + ' <b>: </b>' + Math.round(highlightedJson.y) + '</span></div>'
						+ '<div><span>Reference Value Y : ' + highlightedJson.ReferenceValue + '</span></div>'
				}

				break;
			case ("OverFlowError-REPEATEDCARD"):

				this.showMoreData = `<div  class="over text col col-lg-7 pl-0" > Element Text : ` + highlightedJson.ElementText
					+ '<div><span>Offset Height : </span>' + '<span>' + highlightedJson.offsetHeight + '</span></div>'
					+ '<div><span>Offset width : </span>' + '<span>' + highlightedJson.offsetWidth + '</span></div>'
					+ '<div><span>Scroll width : </span>' + '<span>' + highlightedJson.scrollWidth + '</span></div>'
					+ '<div><span>Scroll Height : </span>' + '<span>' + highlightedJson.scrollHeight + '</span></div></div><div class="overImg col col-lg-5 pl-0"><img src="assets/images/overflow_Img.png" class="img-rounded"  ></div>'

				break;
			case ("Image-NotLoaded"):

				this.showMoreData = `Image URL : ` + '<span>' + highlightedJson.ImageURL + '</span>'
					+ '<div><span> Actual Width : </span>' + '<span>' + highlightedJson.ActualWidth + '</span></div>'
					+ '<div><span> Actual Height : </span>' + '<span>' + highlightedJson.ActualHeight + '</span></div>'
				break;
			case ("InteractiveMenu"):

				this.showMoreData = `Height : ` + '<span>' + highlightedJson.height + '</span>'
					+ '<div><span> Width : </span>' + '<span>' + highlightedJson.width + '</span></div>'
					+ '<div><span>X : </span>' + '<span>' + highlightedJson.x + '</span></div>'
					+ '<div><span>Y : </span>' + '<span>' + highlightedJson.y + '</span></div>'
				break;
			
			case "spellError":
				
					let wrongText = highlightedJson.text ? highlightedJson.text : ''
					let correctedText = highlightedJson.CorrectedText ? highlightedJson.CorrectedText : ''

					this.showMoreData = `The highlighted element ${wrongText.bold()} is spelled  wrongly.The Actual text is   ${correctedText.bold()}`;
					break;
			case "FontValidation":

				let fontText = highlightedJson.text ? highlightedJson.text : ''
				this.showMoreData = `The  Font family has been used by  ${fontText.bold()} `;
				break;

			case ("PageTitle" || "h1Element" || "ImageAlt" || "SvgImageAlt" || "AreaImgAltCheck" || "InputImageCheck" || "orientation" ||"byPassBlock" || "byPassBlockheader" || "autoComplete" || "Emptyheading" || "PageLang" || "langPart" || "landmark" || "mainlandmark" || "bannerlandmark" || "footerlandmark" || "seversideImagemap" || "ariaDescribedby" || "ariaLabelledby" || "EmptyButton" || "roleNavigation" || "RolePresentation" || "buttonWithTitle" || "buttonWithAlt" || "linkwithTitle" || "linkwithAlt" || "iframeDuplicate" || "iframeTitle" || "rolevalidation" || "TimingAdjustable" || "Movingblinkingscrolling" || "emptyLink" || "DuplicateID" || "resize" || "NovideoDescription" || "Noaudiocaption" || "Novideocaption" || "semanticListDL" || "semanticListOL" || "semanticListUL" || "ULlist" || "DTList" || "highertabindex" || "bodyhidden" || "Duplicatetablename" || "tablescopeValidation"):

				this.showMoreData = "";
				
				this.showMoreData = `Impact : ` + '<span>' + highlightedJson.Impact + '</span>'
					+ '<div><span> Violation : </span>' + '<span>' + highlightedJson.Violation + '</span></div>'
					+ '<div><span> IssueDescription : </span>' + '<span>' + highlightedJson.IssueDescription + '</span></div>'
					+ '<div><span> Standard : </span>' + '<span>' + highlightedJson.Standard + '</span></div>'
					+ '<div><span> TagName : </span>' + '<span>' + highlightedJson.tagName + '</span></div>'
					+ '<div><span> GuidelineNo : </span>' + '<span>' + highlightedJson.GuidelineNo + '</span></div>'
					+ '<div><span> Suggestion : </span>' + '<span>' + highlightedJson.Suggestion + '</span></div>'
					+ '<div><span> AffectedUsers : </span>' + '<span>' + highlightedJson.AffectedUsers + '</span></div>'
				
				break;
			default :

			this.showMoreData = "";
				
				this.showMoreData = `Impact : ` + '<span>' + highlightedJson.Impact + '</span>'
					+ '<div><span> Violation : </span>' + '<span>' + highlightedJson.Violation + '</span></div>'
					+ '<div><span> IssueDescription : </span>' + '<span>' + highlightedJson.IssueDescription + '</span></div>'
					+ '<div><span> Standard : </span>' + '<span>' + highlightedJson.Standard + '</span></div>'
					+ '<div><span> TagName : </span>' + '<span>' + highlightedJson.tagName + '</span></div>'
					+ '<div><span> GuidelineNo : </span>' + '<span>' + highlightedJson.GuidelineNo + '</span></div>'
					+ '<div><span> Suggestion : </span>' + '<span>' + highlightedJson.Suggestion + '</span></div>'
					+ '<div><span> AffectedUsers : </span>' + '<span>' + highlightedJson.AffectedUsers + '</span></div>'
				
				break;

		}

	}

	imageLoad(event) {
		if (event.composedPath()) {
			this.imgLoading = false;
		}
	}

	removeSessionStorageVariables() {
		sessionStorage.removeItem("PositionAlignmentError");
		sessionStorage.removeItem("Image-BrokenLink");
		sessionStorage.removeItem("CasesensitiveError");

		sessionStorage.removeItem("PlpToPdpComparison");

		sessionStorage.removeItem("AspectRatioaredifferent");
		sessionStorage.removeItem("OverLapError-REPEATEDCARD");
		sessionStorage.removeItem("OverlapError-REPEATEDCARD-AIML");
		sessionStorage.removeItem("TextMismatch-OCRValidation");
		sessionStorage.removeItem("SizeDifference");
		sessionStorage.removeItem("LinkNotWorking");
		sessionStorage.removeItem("Imageisoflowquality");
		sessionStorage.removeItem("SpacingError-FORM");
		sessionStorage.removeItem("Image-NotLoaded");
		sessionStorage.removeItem("OverFlowError-REPEATEDCARD");
		sessionStorage.removeItem("Videoplayissue");
		sessionStorage.removeItem("Carouselissue");
		sessionStorage.removeItem("InteractiveMenu");
		sessionStorage.removeItem("FontValidation");
		sessionStorage.removeItem("spellError");
	}

	CopyToClipboard(id)
    {
	var copyUrl = document.createRange();
	copyUrl.selectNode(document.getElementById(id));
	window.getSelection().removeAllRanges();
	window.getSelection().addRange(copyUrl);
	document.execCommand('copy');
	window.getSelection().removeAllRanges();
	}

	setValidationCategories() {

		var countUpdate = this.ignoredIssue ? this.issueCount_List[this.ignoredType] : this.issueCount_List;
		let firstCategory = 0;
		this.validationSubCategoriesJson.forEach(element => {
			this.subCategories = element.subCategory;
			let count = 0;
			for (let subcategory of this.subCategories) {
				try{

				if ((this.validationNameMap[subcategory] === "Font_") && (this.isValidationEnabled[subcategory])) {	
				    
					this.validationCategoriesJson[element.category] = true;
					count = count + 1;
				}
				else if (subcategory && this.validationNameMap[subcategory] && (countUpdate[this.validationNameMap[subcategory]] > 0) && (this.isValidationEnabled[subcategory])) {

					count = count + countUpdate[this.validationNameMap[subcategory]];
					//break;
				}
				else {
					element.categoryCount = 0;
					this.validationCategoriesJson[element.category] = false;
				}
				if (count > 0 && firstCategory == 0) {
					this.firstCategoryName = element.category;
					this.firstSubCategoryName = subcategory;
					firstCategory++;
				}
				}catch(e){
					console.log("error in for loop - ",e)
				}
			}
			if (count > 0) {
				element.categoryCount = count;
				this.validationCategoriesJson[element.category] = true;
			}
		});
	}

	async switchIssueView() {

		var btn = <HTMLButtonElement>document.getElementById('viewBtn');
		if (btn.innerText === "Each Issue") {
			btn.innerText = "Single View";
		} else {
			btn.innerText = "Each Issue";
		}
		// this.setonLoadImg();
		this.setCategoryImg(this.firstSubCategoryName);
		this.reportView = !this.reportView;
		await onSwitchReport(this.reportView);
	}

	async setonLoadImg() {
		var isFontSpellFound = false;
		this.thumbnailImages = [];
		for (let page in this.jsonReport["page" + this.id]) {
			if (!page.includes('FONT') && !page.includes('spell')) {
				//check false postive
				var isFalsePositiveErr = this.jsonReport["page" + this.id][page]["isFalsePositive"];
				if (isFalsePositiveErr === this.ignoredIssue) {
					page = this.thumbnailImgPath + "/" + page.split("_")[0] + "/" + page + ".png";

					this.thumbnailImages.push(page);
				}
			}
			else {
				isFontSpellFound = true;
			}
		}

		if (this.thumbnailImages.length <= 0 && !isFontSpellFound) {
			var toggleBtn = document.getElementById("customSwitches");
			toggleBtn.click();
			this.btnDisabled = true;
		}
		else {
			this.thumbImg = this.thumbnailImages[0];
			var errorLengthArr = this.thumbImg.split("/").length - 1;

			var errorDetail = this.thumbImg.split("/")[errorLengthArr].split(".")[0].split("__")[0];

			await getImageRepresentationNew(errorDetail, "page" + this.id, this.jsonReport, this.ignoredIssue, environment.IgnoredKey).then(function (jsonObject) {
				jsonObjForEachCategory = jsonObject;
			})

			//	await setInitialParamaters(this.jsonReport, "page" + this.id, this.thumbImg, errorDetail, this.ignoredIssue, environment.IgnoredKey);
			this.selectedError = this.validationNamePageLoad[errorDetail];

			if (errorDetail.includes("PositionAlignmentError")) {
				errorDetail = "PositionAlignmentError";
			}
			// document.getElementById("next").style.display = "none";
			this.staticInfo = this.categoryDescription[errorDetail];
			this.setMoreInfo(jsonObjForEachCategory[0], errorDetail);
			this.falsePositive = jsonObjForEachCategory[0];

			this.countForNxtPrev = 0;
			this.countForNxtPrevForCollapse = 0;
		}
	}

	// sets thumbnails in accordion - accordding category 
	async setCategoryImg(categoryName: any) {
		this.thumbnailImages = [];
		this.thumbImg = [];
		this.countForNxtPrev = [];

		for (let page in this.jsonReport["page" + this.id]) {
			if (!page.includes('FONT') && !page.includes('spell')) {
				var isFalsePositiveErr;
				if (this.ignoredIssue) {
					isFalsePositiveErr = this.jsonReport["page" + this.id][page][environment.IgnoredKey];
				}
				else {
					isFalsePositiveErr = this.jsonReport["page" + this.id][page]["isFalsePositive"];
				}
				if (categoryName.includes("PositionAlignmentError")) {
					categoryName = "PositionAlignmentError";
				}
				if (page.includes(this.validationNameMap[categoryName]) && isFalsePositiveErr === this.ignoredIssue) {
					if(page.split("_")[0]==this.validationNameMap[categoryName]) {
						page = this.thumbnailImgPath + "/" + page.split("_")[0] + "/" + page + ".png";
						this.thumbnailImages.push(page);
					}	
				}
			}
		}

		this.thumbImg = this.thumbnailImages[0];

		var errorLengthArr = this.thumbImg.split("/").length - 1;

		var errorDetail = this.thumbImg.split("/")[errorLengthArr].split(".")[0].split("__")[0];
		await getImageRepresentationNew(errorDetail, "page" + this.id, this.jsonReport, this.ignoredIssue, environment.IgnoredKey).then(function (jsonObject) {
			jsonObjForEachCategory = jsonObject;
		})

		this.selectedError = this.validationNamePageLoad[errorDetail];
		this.falsePositive = jsonObjForEachCategory[0];
		let categoryIssueName = jsonObjForEachCategory[0].uniqueCategoryKey.split('____');

		this.staticInfo = this.categoryDescription[categoryIssueName[0]];
		this.setMoreInfo(jsonObjForEachCategory[0], categoryIssueName[0]);


	}

	// sets Image and error details on right after clicking thumbnail 		
	loadImage(imgElement: any) {
		var index = this.thumbnailImages.indexOf(imgElement);
		var imgSrc = <HTMLImageElement>document.getElementById("inputImage");

		imgSrc.src = imgElement;


		this.countForNxtPrev = index;
		this.countForNxtPrevForCollapse = index;

		let categoryIssueName = jsonObjForEachCategory[index].uniqueCategoryKey.split('____');
		if (categoryIssueName[0].includes("PositionAlignmentError")) {
			categoryIssueName[0] = "PositionAlignmentError";
		}
		this.falsePositive = jsonObjForEachCategory[this.countForNxtPrev];

		this.selectedError = this.validationNamePageLoad[categoryIssueName[0]];

		this.staticInfo = this.categoryDescription[categoryIssueName[0]];
		this.setMoreInfo(jsonObjForEachCategory[index], categoryIssueName[0]);

	}

	collapse() {
		if (this.showFontValidationMetaData !== true) {
			this.isCollapse = !this.isCollapse;
			this.thumbImgForLeftImage = this.thumbnailImages[0];
			if (this.thumbnailImages.length >= 2) {
				this.thumbImgForRightImage = this.thumbnailImages[1];
			}
		}
	}

	//pin unpin sidebar
	pinUnpin() {
		this.unpin = !this.unpin;
	}
	
	showPDPImage(objDetails: any,model: any){


		let errorKey = objDetails.uniqueCategoryKey;

		var isFalsePositiveErr = this.jsonReport["page" + this.id][errorKey]["isFalsePositive"];

		if (isFalsePositiveErr === this.ignoredIssue) {
			let PLPImageURL = this.thumbnailImgPath + "/" + errorKey.split("_")[0] + "/" + errorKey + ".png";

			let PDPImageURL = this.thumbnailImgPath + "/" + errorKey.split("_")[0] + "/" + errorKey + "_PDP" + ".png";

			this.PLPImage = PLPImageURL;

			this.PDPImage = PDPImageURL;

			this.PDPLinkURL = objDetails.PDPURL;

			this.setMoreInfo(objDetails, "PlpToPdpComparison");
		}
		this.modalService.open(model, { size: 'lg', centered: true })
	}	
	
	/**
	 * Sanitize and encode all HTML in a user-submitted string
	 * https://portswigger.net/web-security/cross-site-scripting/preventing
	 * @param  {String} str  The user-submitted string
	 * @return {String} str  The sanitized string
	 */
	 sanitizeHTML(str) {
		if(typeof str === "string"){
			return str.replace(/[^\w. ]/gi, function (c) {
				return '&#' + c.charCodeAt(0) + ';';
			});
		}
		else{
			return str;
		}
	};

	getFontMetaData(fontMetaDataDetails: any){
		return typeof fontMetaDataDetails ? fontMetaDataDetails : [];
	}

}
