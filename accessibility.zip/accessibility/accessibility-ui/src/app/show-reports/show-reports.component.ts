import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { UrlFetcherService } from '../url-fetcher.service';

@Component({
  selector: 'app-show-reports',
  templateUrl: './show-reports.component.html',
  styleUrls: ['./show-reports.component.css']
})
export class ShowReportsComponent implements OnInit {

  reports:any;

  reportsToken : string = null;

  constructor(private router: Router, private service:UrlFetcherService, private activeRouter : ActivatedRoute) {
    this.activeRouter.queryParams.subscribe((queryParam) =>{
      if(queryParam.jwtToken){
        this.reportsToken = queryParam.jwtToken;
      }
		});
   }

  ngOnInit(): void {
    var param = {};
    if(this.reportsToken != null){
      param = {'reportsToken' : this.reportsToken};
    }
    this.service.postUrlToParser(param,environment.baseURL + environment.apiURL + environment.report + "/all" ).subscribe((data: any) => {
      this.reports = data.response.param;
    });
  }

  goToReport(id, url){
    //sessionStorage.setItem("url",url);
 	if(this.reportsToken === null){
	
   		 this.router.navigate(['/viewReports/'+id],{queryParams:{url:url}});

	}
	else if(this.reportsToken !== null){

      this.router.navigate(['/viewReports/'+id],{queryParams:{url:url,jwtToken : this.reportsToken}})

    }
  }

  backToHome(){
    this.router.navigateByUrl('/home');
  }

}
