import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UrlFetcherService {

  constructor(private http: HttpClient) { }

  public postUrlToParser(UrlToParserObject, url) {
    var param = {};
    param["param"] = {};
    param["param"] = UrlToParserObject;

    let headers = new HttpHeaders({
      'Content-Type': 'application/json'
    })

    return this.http.post(url, JSON.stringify(param), { headers });
  };


  public doGet(url) {


    let headers = new HttpHeaders({
      'Content-Type': 'application/json'
    })

    return this.http.get(url, { headers });
  };
}
