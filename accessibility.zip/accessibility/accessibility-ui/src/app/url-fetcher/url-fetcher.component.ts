import { ElementRef } from '@angular/core';
import { ViewChild } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms'
import { environment } from 'src/environments/environment';
import { CommonService } from '../service/common.service';
import { UrlFetcherService } from '../url-fetcher.service';
import { urlForParserOject } from '../UrlFetcherObject';
import { ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import Stepper from 'bs-stepper';
import { ToastrService } from 'ngx-toastr';

declare var SockJS;
declare var Stomp;

@Component({
	selector: 'app-url-fetcher',
	templateUrl: './url-fetcher.component.html',
	styleUrls: ['./url-fetcher.component.css']
})
export class UrlFetcherComponent implements OnInit {

	constructor(private service: UrlFetcherService, private router: Router, 
		private fb: FormBuilder, private toastr : ToastrService, private activatedRoute : ActivatedRoute) {

			this.activatedRoute.queryParams.subscribe((queryParam:any)=>{
				if(queryParam.jwtToken){
					this.jwtToken = queryParam.jwtToken;
					//this.showRunType = true;
					this.runType = 'multi';
				}
				if(queryParam.hostName){
					this.hostName = queryParam.hostName;
				}
			})
	 }

	UrlToParserObject: urlForParserOject;

	showViewReportBtn: boolean = true;

	disableStartRtn: boolean = false;

	message: any;

	isSubmitted: boolean = false;

	wssSetTimeOut: any;

	initializationStarted: boolean = false;

	initializationCompleted: boolean = false;

	categorizationStarted: boolean = false;

	categorizationCompleted: boolean = false;

	validationStarted: boolean = false;

	validationCompleted: boolean = false;

	reportGenerationStarted: boolean = false;

	reportGenerationCompleted: boolean = false;

	showProgress: boolean = false;

	stompClient: any;

	mobileDevices: string[];

	browsers: string[];

	inputForm: FormGroup;

	resolutions: string[];

	isCustomResolution: boolean = false;

	selectedvalue: any;

	show = false;

	ele: any[];

	startBtn : boolean = false;

	loginTypeSelected: String = "newPage";
	
	multiURLJSON = [];

	showRunType : boolean = true;

	runType : string = 'multi';

	private stepper: Stepper;

	@ViewChild('closebutton') closebutton;

	@ViewChild('accessUrl') accessUrlInputField: ElementRef;
	
	jwtToken: string = null;

	hostName : string;

	success : boolean = false;

	csv : boolean = false;

	ngOnInit(): void {

		this.browsers = ['CHROME', 'FIREFOX', 'MOBILE'];

		this.resolutions = ['1366 X 768', '1920 X 1080', '1440 X 900', '1536 X 864', 'Custom Resolution'];


		this.mobileDevices = ["BlackBerry Z30", "Blackberry PlayBook", "Galaxy Note 3", "Galaxy Note II", "Galaxy S III", "Kindle Fire HDX", "LG Optimus L70",
			"Microsoft Lumia 550", "Microsoft Lumia 950", "Moto G4", "Nexus 10", "Nexus 4", "Nexus 5", "Nexus 5X", "Nexus 6", "Nexus 6P",
			"Nexus 7", "Nokia Lumia 520", "Nokia N9", "iPad Mini", "JioPhone 2", "Galaxy S5", "Pixel 2", "Pixel 2 XL",
			"iPhone 4", "iPhone 5/SE", "iPhone 6/7/8", "iPhone 6/7/8 Plus", "iPhone X", "iPad", "iPad Pro", "Surface Duo", "Galaxy Fold"];

		this.inputForm = this.fb.group({
			runType : this.fb.control(this.runType,Validators.required),
			url: this.fb.control('', Validators.required),
			browser: this.fb.control(this.browsers[0], Validators.required),
			xpathUrl: this.fb.control(''),
			accessUrl: this.fb.control(''),
			credentialCheckbox: this.fb.control(''),
			credentialData: this.fb.group({
				loginUrl: this.fb.control(''),
				loginType: this.fb.control('newPage', Validators.required),
				loginId: this.fb.control(''),
				loginIdLocator: this.fb.control(''),
				password: this.fb.control(''),
				passwordLocator: this.fb.control(''),
				agreeLocator: this.fb.control(''),
				submitLocator: this.fb.control(''),
				popUpOpenLocator: this.fb.control(''),
			}),
			customHeight: this.fb.control(''),
			customWidth: this.fb.control(''),
			customResolution: this.fb.control(''),
			isCustomResolution: this.fb.control(this.isCustomResolution, Validators.required)
		});
		this.createEntityFormControl();
		if(this.jwtToken){
			const urlEntity = this.inputForm.get('url');
			urlEntity.clearValidators();
			urlEntity.setValue('');
		}
		const urlEntity = this.inputForm.get('url');
		
			if(this.runType === 'single'){
				urlEntity.setValidators([Validators.required]);
				this.multiURLJSON = [];
			}
			else if(this.runType === 'multi'){
				urlEntity.clearValidators();
				urlEntity.setValue('');
			}
	
		
	}



	showDevice = false;
	browserEmit(event: any) {
		this.isSubmitted = false;
		const mobileControl = this.fb.control("", Validators.required);
		this.showDevice = event == 'MOBILE' ? true : false;
		event == "MOBILE" ? this.inputForm.addControl("mobile", mobileControl) : this.inputForm.removeControl("mobile")
	}
	checkOptions() {
		var customResolution = <HTMLSelectElement>document.getElementById("customResolutionSel");
		this.selectedvalue = customResolution.options[customResolution.selectedIndex].value;

		document.getElementById("userCustomResol").style.display = this.selectedvalue == "Custom Resolution" ? 'inline-flex' : 'none';

	}

	onClickURL(formValue: any) {

		this.add('start');
		this.isSubmitted = true;

		if (this.inputForm.valid) {

			console.log("credential dat \n", formValue.credentialData)

			this.disableStartRtn = true;

			this.showViewReportBtn = false;

			let ingName = formValue.url;
			let browser = formValue.browser;
			let mobile = formValue.mobile;
			let xpathUrl = formValue.xpathUrl;
			let accessUrl = formValue.accessUrl;
			let credentialData = formValue.credentialData;
			let customHeight = formValue.customHeight;
			let customWidth = formValue.customWidth;
			let runType = formValue.runType;

			var xpathUrlList = [];
			var accessUrlList = [];
			let customResolution;

			console.log(accessUrl);
			if (this.selectedvalue === "Custom Resolution") {

				customResolution = customWidth + "X" + customHeight;
				this.isCustomResolution = true;

			}
			else {
				customResolution = this.selectedvalue;
			}

			console.log("xpathUrl", xpathUrl)
			if (xpathUrl.includes("|")) {
				xpathUrlList = xpathUrl.split("|");
			}
			else {
				xpathUrlList.push(xpathUrl);
			}

			//this.showProgress = true;
			this.startBtn = true;

			if (accessUrl.includes("|")) {
				accessUrlList = accessUrl.split("|");
			}
			else {
				accessUrlList.push(accessUrl);
			}

			this.UrlToParserObject = new urlForParserOject(ingName, browser, mobile);

			let params = {}

			if (!this.show) {
				params = {
					'url': this.UrlToParserObject.url1,
					'browser': this.UrlToParserObject.browser1,
					'mobile': this.UrlToParserObject.mobile1,
					'validationsRequired': this.ele.toString(),
					'popUpXpath': xpathUrlList,
					'accessUrlList': accessUrlList,
				};
				
				
				if(runType === 'multi'){
					params['multiURLArray'] = this.multiURLJSON;
					params['credentialData'] =  credentialData;
					params['credentialData']['loginType'] = "";
				}

				if (runType === 'single') {
					if (this.jwtToken) {
						this.multiURLJSON.push(ingName);
						params['multiURLArray'] = this.multiURLJSON;
						params['credentialData'] =  credentialData;
						params['credentialData']['loginType'] = "";
					}
				}

				if(this.jwtToken){
					params['jwtToken'] = this.jwtToken;
				}

				if(this.hostName){
					params['hostName'] = this.hostName;
				}
			}

			else {
				params = {
					'url': this.UrlToParserObject.url1,
					'browser': this.UrlToParserObject.browser1,
					'mobile': this.UrlToParserObject.mobile1,
					'validationsRequired': this.ele.toString(),
					'popUpXpath': xpathUrlList,
					'accessUrlList': accessUrlList,
					'credentialData': credentialData
				};

				if(runType === 'multi'){
					params['multiURLArray'] = this.multiURLJSON;
				}

				if (runType === 'single') {
					if (this.jwtToken) {
						this.multiURLJSON.push(ingName);
						params['multiURLArray'] = this.multiURLJSON;
					}
				}

				if(this.jwtToken){
					params['jwtToken'] = this.jwtToken;
				}

				if(this.hostName){
					params['hostName'] = this.hostName;
				}
			}

			/* let url = { 'url': this.UrlToParserObject.url1,
			'browser': this.UrlToParserObject.browser1,
			'mobile': this.UrlToParserObject.mobile1}; */

			//this.connect();

			this.initializationStarted = true;

			this.service.postUrlToParser(params, environment.baseURL + environment.apiURL + environment.startProcess).subscribe((data: any) => {
				this.message = data.response.param;
				this.showViewReportBtn = true;
				/*this.disConnect();
				this.showProgress = false;*/
				//this.startBtn = false;
				this.success = true;
			});

		}

	}

	viewReport() {
		this.router.navigateByUrl('/showReports');
	}


	connect() {
		const serverUrl = environment.baseURL + "/socket";
		const ws = new SockJS(serverUrl);
		this.stompClient = Stomp.over(ws);
		const that = this;

		var headers = {
			'Content-Type': undefined,
		}

		this.stompClient.connect({ headers }, function (frame) {
			that.stompClient.subscribe('/topic/greetings', (msg) => {
				if (msg.body) {

					let message = msg.body;

					if (message === "Categorization Started") {
						that.initializationStarted = false;
						that.initializationCompleted = true;
						that.categorizationStarted = true;
					}

					if (message === "Validation Started") {
						that.categorizationStarted = false;
						that.categorizationCompleted = true;
						that.validationStarted = true;
					}

					if (message === "Report Generation Started") {
						that.validationStarted = false;
						that.validationCompleted = true;
						that.reportGenerationStarted = true;
					}

					if (message === "Report Generation Completed") {
						that.reportGenerationStarted = false;
						that.reportGenerationCompleted = true;
					}
				}
			});
		});
	}

	disConnect() {
		if (this.stompClient !== null) {
			this.stompClient.disconnect();
		}
	}

	toggle() {
		this.show = !this.show;
	}

	allUI = [
		{
			name: 'Accessibility',
			checked: true,
			disabled: false
		}
	]

	allContents = [
		{
			name: 'Case Sensitive',
			checked: false,
			disabled: false
		},
		{
			name: 'Broken Link',
			checked: false,
			disabled: false
		},
		{
			name: `Image Validation`,
			checked: false
		},
		{
			name: 'Font',
			checked: false,
			disabled: false
		},
		{
			name: 'Spell',
			checked: false,
			disabled: true
		}
	];
	allInteraction = [

		{
			name: 'Carousel',
			checked: false,
			disabled: false
		},
		{
			name: 'Menu Hover',
			checked: false,
			disabled: false
		},
		{
			name: 'Video',
			checked: false,
			disabled: false
		},
		{
			name: 'Download',
			checked: false,
			disabled: false
		},
		{
			name: 'Accordion',
			checked: false,
			disabled: true
		}

	];



	add(addFlag: string) {

		var credentialStatus = this.inputForm.controls.credentialData.valid;

		console.log(this.accessUrlInputField.nativeElement.value)
		if (this.show) {
			//if (!this.accessUrlInputField.nativeElement.value.includes("|")) {
				if (credentialStatus) {
					this.ele =
						this.allUI
							.filter(opt => opt.checked)
							.map(opt => opt.name).concat(this.allContents
								.filter(opt => opt.checked)
								.map(opt => opt.name)).concat(this.allInteraction
									.filter(opt => opt.checked)
									.map(opt => opt.name));
					console.log(this.ele);
					this.show;
					this.closebutton.nativeElement.click();
				}
				else {
					alert("PLEASE FILL REQUIRED FIELDS");
				}
			// }else{
			// 	alert("Please only provide 1 login url");
			// }
			
		}
		else {
			this.ele =
				this.allUI
					.filter(opt => opt.checked)
					.map(opt => opt.name).concat(this.allContents
						.filter(opt => opt.checked)
						.map(opt => opt.name)).concat(this.allInteraction
							.filter(opt => opt.checked)
							.map(opt => opt.name));
			console.log(this.ele);
			this.show;
			this.closebutton.nativeElement.click();
		}
	}

	createEntityFormControl() {
		const loginUrlEntity = this.inputForm.get('credentialData.loginUrl');
		const loginIdEntity = this.inputForm.get('credentialData.loginId');
		const loginIdLocatorEntity = this.inputForm.get('credentialData.loginIdLocator');
		const passwordEntity = this.inputForm.get('credentialData.password');
		const passwordLocatorEntity = this.inputForm.get('credentialData.passwordLocator');
		const agreeLocatorEntity = this.inputForm.get('credentialData.agreeLocator');
		const submitLocatorEntity = this.inputForm.get('credentialData.submitLocator');
		const urlEntity = this.inputForm.get('url');

		this.inputForm.get('credentialCheckbox').valueChanges.subscribe(credentialCheckbox => {
			if (credentialCheckbox === true) {				

				loginUrlEntity.setValidators([Validators.required]);
				loginUrlEntity.updateValueAndValidity();

				loginIdEntity.setValidators([Validators.required]);
				loginIdEntity.updateValueAndValidity();

				loginIdLocatorEntity.setValidators([Validators.required]);
				loginIdLocatorEntity.updateValueAndValidity();

				passwordEntity.setValidators([Validators.required]);
				passwordEntity.updateValueAndValidity();

				passwordLocatorEntity.setValidators([Validators.required]);
				passwordLocatorEntity.updateValueAndValidity();

				submitLocatorEntity.setValidators([Validators.required]);
				submitLocatorEntity.updateValueAndValidity();

				this.stepper = new Stepper(document.querySelector('#stepper1'), {
					linear: false,
					animation: true
				  });
			}
			else {
				loginIdEntity.setValue('');
				loginIdEntity.clearValidators();
				loginIdEntity.updateValueAndValidity();
				// console.log(loginIdEntity, "check");

				loginUrlEntity.setValue('');
				loginUrlEntity.clearValidators();
				loginUrlEntity.updateValueAndValidity();

				loginIdLocatorEntity.setValue('');
				loginIdLocatorEntity.clearValidators();
				loginIdLocatorEntity.updateValueAndValidity();

				passwordEntity.setValue('');
				passwordEntity.clearValidators();
				passwordEntity.updateValueAndValidity();

				passwordLocatorEntity.setValue('');
				passwordLocatorEntity.clearValidators();
				passwordLocatorEntity.updateValueAndValidity();

				agreeLocatorEntity.setValue('');
				agreeLocatorEntity.clearValidators();
				agreeLocatorEntity.updateValueAndValidity();

				submitLocatorEntity.setValue('');
				submitLocatorEntity.clearValidators();
				submitLocatorEntity.updateValueAndValidity();				
			}
		});
		
		this.inputForm.get('runType').valueChanges.subscribe(runType => {
			if(runType === 'single'){
				urlEntity.setValidators([Validators.required]);
				this.multiURLJSON = [];
			}
			else if(runType === 'multi'){
				urlEntity.clearValidators();
				urlEntity.setValue('');
			}
		});
	

	}

	changeLoginType(event){
		this.loginTypeSelected = event.target.value;

		const loginUrlEntity = this.inputForm.get('credentialData.loginUrl');
		const loginIdEntity = this.inputForm.get('credentialData.loginId');
		const loginIdLocatorEntity = this.inputForm.get('credentialData.loginIdLocator');
		const passwordEntity = this.inputForm.get('credentialData.password');
		const passwordLocatorEntity = this.inputForm.get('credentialData.passwordLocator');
		const agreeLocatorEntity = this.inputForm.get('credentialData.agreeLocator');
		const submitLocatorEntity = this.inputForm.get('credentialData.submitLocator');
		const popUpOpenLocatorEntity = this.inputForm.get('credentialData.popUpOpenLocator');

		loginUrlEntity.setValidators([]);
		loginUrlEntity.updateValueAndValidity();

		loginIdEntity.setValidators([]);
		loginIdEntity.updateValueAndValidity();

		loginIdLocatorEntity.setValidators([]);
		loginIdLocatorEntity.updateValueAndValidity();

		passwordEntity.setValidators([]);
		passwordEntity.updateValueAndValidity();

		passwordLocatorEntity.setValidators([]);
		passwordLocatorEntity.updateValueAndValidity();

		submitLocatorEntity.setValidators([]);
		submitLocatorEntity.updateValueAndValidity();

		loginIdEntity.setValidators([]);
		loginIdEntity.updateValueAndValidity();

		passwordEntity.setValidators([]);
		passwordEntity.updateValueAndValidity();

		if(this.loginTypeSelected === "newPage" || this.loginTypeSelected === "popUp"){
			loginIdEntity.setValidators([Validators.required]);
			loginIdEntity.updateValueAndValidity();

			loginIdLocatorEntity.setValidators([Validators.required]);
			loginIdLocatorEntity.updateValueAndValidity();

			passwordEntity.setValidators([Validators.required]);
			passwordEntity.updateValueAndValidity();

			passwordLocatorEntity.setValidators([Validators.required]);
			passwordLocatorEntity.updateValueAndValidity();

			submitLocatorEntity.setValidators([Validators.required]);
			submitLocatorEntity.updateValueAndValidity();

			// if(this.loginTypeSelected === "popUp"){
			// 	popUpOpenLocatorEntity.setValidators([Validators.required]);
			// 	popUpOpenLocatorEntity.updateValueAndValidity();
			// }
		}else{
			loginIdEntity.setValidators([Validators.required]);
			loginIdEntity.updateValueAndValidity();

			passwordEntity.setValidators([Validators.required]);
			passwordEntity.updateValueAndValidity();					
		}	

		loginUrlEntity.setValidators([Validators.required]);
		loginUrlEntity.updateValueAndValidity();
	}

	stepperNext() {
		
		if(this.loginTypeSelected === "alert"){
			this.stepper.to(3);
		}else{
			this.stepper.next();
		}
		
	}

	onStepperSubmit() {
		return false;
	}
	
		importCSV(event) {
		const file = event.target.files[0];
		if (file.name.endsWith('csv')) {
		  const reader = new FileReader();
		  reader.readAsText(file);
		  reader.onload = (fevent: any) => {
			try {
			  const data: string = fevent.target.result;
			  //const tests = [];
			  let lines = data.split('\n');
			  const hasHeader = lines[0].startsWith('URL');
			  const start = hasHeader ? 1 : 0;
			  let headers = hasHeader ? this.parseCSV(lines[0]).reduce((m, h, i) => ({ ...m, [h.toLowerCase()]: i }), {})
				: { URL: 0};
	
			  for (let i = start; i < lines.length; i++) {
				const parsed = this.parseCSV(lines[i]);
				
				if (parsed && parsed !== null && parsed[0]) {
					
					if(parsed[0].includes("&")){
						parsed[0] = parsed[0].replace(/&/g, "^&");
					}

				  this.multiURLJSON.push('"'+parsed[0]+'"');
				}
			  }
			  //this.updateTasks([...this.tasks, ...tests]);
			  //this.toastr.success(file.name + ' uploaded successfuly');
			    this.csv=true;
			} catch (e) {
			  this.toastr.error('error reading file');
			  console.error(e);
			}
		  };
		} else {
		  this.csv=false;	
		  this.toastr.error('invalid file imported');
		}
	  }

	 parseCSV(text) {
		var re_valid = /^\s*(?:'[^'\\]*(?:\\[\S\s][^'\\]*)*'|"[^"\\]*(?:\\[\S\s][^"\\]*)*"|[^,'"\s\\]*(?:\s+[^,'"\s\\]+)*)\s*(?:,\s*(?:'[^'\\]*(?:\\[\S\s][^'\\]*)*'|"[^"\\]*(?:\\[\S\s][^"\\]*)*"|[^,'"\s\\]*(?:\s+[^,'"\s\\]+)*)\s*)*$/;
		var re_value = /(?!\s*$)\s*(?:'([^'\\]*(?:\\[\S\s][^'\\]*)*)'|"([^"\\]*(?:\\[\S\s][^"\\]*)*)"|([^,'"\s\\]*(?:\s+[^,'"\s\\]+)*))\s*(?:,|$)/g;
		// Return NULL if input string is not well formed CSV string.
		if (!re_valid.test(text)) return null;
		var a = [];                     // Initialize array to receive values.
		text.replace(re_value, // "Walk" the string using replace with callback.
			function (m0, m1, m2, m3) {
				// Remove backslash from \' in single quoted values.
				if (m1 !== undefined) a.push(m1.replace(/\\'/g, "'"));
				// Remove backslash from \" in double quoted values.
				else if (m2 !== undefined) a.push(m2.replace(/\\"/g, '"'));
				else if (m3 !== undefined) a.push(m3);
				return ''; // Return empty string.
			});
		// Handle special case of empty last value.
		if (/,\s*$/.test(text)) a.push('');
		return a;
	};

	  resetFileInput(event) {
        event.target.value = '';
      }
	
}