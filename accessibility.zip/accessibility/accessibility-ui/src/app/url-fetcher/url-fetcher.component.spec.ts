import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UrlFetcherComponent } from './url-fetcher.component';

describe('UrlFetcherComponent', () => {
  let component: UrlFetcherComponent;
  let fixture: ComponentFixture<UrlFetcherComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UrlFetcherComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UrlFetcherComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
