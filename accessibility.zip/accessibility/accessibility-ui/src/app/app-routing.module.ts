import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShowReportsComponent } from './show-reports/show-reports.component';
import { UrlFetcherComponent } from './url-fetcher/url-fetcher.component';
import { ViewReportsComponent } from './view-reports/view-reports.component';

const routes: Routes = [
  {path:'', redirectTo:'home',pathMatch:'full'},
  {path:'home', component: UrlFetcherComponent},
  {path:'viewReports/:id', component: ViewReportsComponent},
  {path:'showReports', component: ShowReportsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes,{useHash: true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
