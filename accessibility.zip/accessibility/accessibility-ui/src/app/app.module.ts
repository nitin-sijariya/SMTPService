import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CommonModule, KeyValuePipe } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UrlFetcherComponent } from './url-fetcher/url-fetcher.component';
import { HeaderComponent } from './header/header.component';
import { UrlFetcherService } from './url-fetcher.service';
import { HttpClientModule } from '@angular/common/http';
import { ViewReportsComponent } from './view-reports/view-reports.component';
import { ShowReportsComponent } from './show-reports/show-reports.component';
import { NgbCollapseModule, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgpSortModule, SortByPipe } from 'ngp-sort-pipe';
import { ToastContainerModule, ToastrModule } from 'ngx-toastr';
import { PerfectScrollbarConfigInterface, PerfectScrollbarModule, PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true
};

@NgModule({
  declarations: [
    AppComponent,
    UrlFetcherComponent,
    HeaderComponent,
    ViewReportsComponent,
    ShowReportsComponent
  ],
  imports: [
    BrowserModule,
    CommonModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
	ToastrModule.forRoot({
      timeOut: 3000,
      positionClass: 'toast-bottom-right',
      preventDuplicates: true,
    }),
    ToastContainerModule,
	NgbModule,
    NgbModule.forRoot(),
    NgbCollapseModule,BrowserAnimationsModule,
    NgpSortModule,
	PerfectScrollbarModule
  ],
  providers: [UrlFetcherService,KeyValuePipe,SortByPipe,{
    provide: PERFECT_SCROLLBAR_CONFIG,
    useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
