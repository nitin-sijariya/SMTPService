import { Injectable } from "@angular/core";
import { environment } from "src/environments/environment";

declare var SockJS;
declare var Stomp;

@Injectable({
    providedIn: 'root'
})

export class CommonService{

    public stompClient;

    connect() {
        const serverUrl = environment.baseURL + "/socket";
        const ws = new SockJS(serverUrl);
        this.stompClient = Stomp.over(ws);
        const that = this;

        var headers = {
            'Content-Type' : undefined,
        }

        this.stompClient.connect({headers}, function(frame) {
          that.stompClient.subscribe('/topic/greetings', (message) => {
            if (message.body) {
              sessionStorage.setItem("stompMessage",message.body);
            }
          });
        });
    }

    disConnect(){
        if(this.stompClient !== null){
            this.stompClient.disconnect();
        }
    }
}